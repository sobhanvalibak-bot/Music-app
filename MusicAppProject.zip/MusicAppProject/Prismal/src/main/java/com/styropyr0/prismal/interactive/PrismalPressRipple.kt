package com.styropyr0.prismal.interactive

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.core.spring
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.util.fastCoerceIn
import com.styropyr0.prismal.PrismalShader
import com.styropyr0.prismal.asComposeShader
import com.styropyr0.prismal.internal.PrismalPressRippleShader
import com.styropyr0.prismal.isAGSLShaderSupported
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Press interaction helper that drives scale, ripple shader, and touch offset
 * for glass buttons and surfaces.
 *
 * Attach [modifier] and [gestureModifier] to the interactive composable, and pass
 * [pressProgress] / [offset] into a [drawPrismalGlass] [layerBlock].
 *
 * @param animationScope Coroutine scope used for spring animations.
 * @param intensity Multiplier for the press glow (flat wash + ripple highlight). `1f` is the
 *   default strength, `0f` disables the glow while keeping press tracking.
 * @param position Maps raw touch offset to ripple center within the surface bounds.
 */
class PrismalPressRipple(
    val animationScope: CoroutineScope,
    val intensity: Float = 1f,
    val position: (size: Size, offset: Offset) -> Offset = { _, offset -> offset }
) {

    private val pressProgressAnimationSpec =
        spring(0.5f, 300f, 0.001f)
    private val positionAnimationSpec =
        spring(0.5f, 300f, Offset.VisibilityThreshold)

    private val pressProgressAnimation =
        Animatable(0f, 0.001f)
    private val positionAnimation =
        Animatable(Offset.Zero, Offset.VectorConverter, Offset.VisibilityThreshold)

    private var startPosition = Offset.Zero

    /** Animated press amount in `[0, 1]` — 1 while pressed. */
    val pressProgress: Float get() = pressProgressAnimation.value

    /** Touch offset relative to press start, for parallax / lens shift effects. */
    val offset: Offset get() = positionAnimation.value - startPosition

    private val shader =
        if (isAGSLShaderSupported()) {
            PrismalShader(PrismalPressRippleShader)
        } else {
            null
        }

    /** Draw modifier that renders the AGSL touch ripple over content. */
    val modifier: Modifier =
        Modifier.drawWithContent {
            val progress = pressProgressAnimation.value * intensity.fastCoerceIn(0f, 1f)
            if (progress > 0f) {
                if (shader != null) {
                    drawRect(
                        Color.White.copy(0.08f * progress),
                        blendMode = BlendMode.Plus
                    )
                    shader.apply {
                        val highlightPosition = position(size, positionAnimation.value)
                        setFloatUniform("size", size.width, size.height)
                        setColorUniform("color", Color.White.copy(0.15f * progress))
                        setFloatUniform("radius", size.minDimension * 1.5f)
                        setFloatUniform(
                            "position",
                            highlightPosition.x.fastCoerceIn(0f, size.width),
                            highlightPosition.y.fastCoerceIn(0f, size.height)
                        )
                    }
                    drawRect(
                        ShaderBrush(shader.asComposeShader()),
                        blendMode = BlendMode.Plus
                    )
                } else {
                    drawRect(
                        Color.White.copy(0.25f * progress),
                        blendMode = BlendMode.Plus
                    )
                }
            }

            drawContent()
        }

    /** Pointer input modifier that tracks press, drag, and release gestures. */
    val gestureModifier: Modifier =
        Modifier.pointerInput(animationScope) {
            inspectPrismalDragGestures(
                onDragStart = { down ->
                    startPosition = down.position
                    animationScope.launch {
                        launch { pressProgressAnimation.animateTo(1f, pressProgressAnimationSpec) }
                        launch { positionAnimation.snapTo(startPosition) }
                    }
                },
                onDragEnd = {
                    animationScope.launch {
                        launch { pressProgressAnimation.animateTo(0f, pressProgressAnimationSpec) }
                        launch { positionAnimation.animateTo(startPosition, positionAnimationSpec) }
                    }
                },
                onDragCancel = {
                    animationScope.launch {
                        launch { pressProgressAnimation.animateTo(0f, pressProgressAnimationSpec) }
                        launch { positionAnimation.animateTo(startPosition, positionAnimationSpec) }
                    }
                }
            ) { change, _ ->
                animationScope.launch { positionAnimation.snapTo(change.position) }
            }
        }
}
