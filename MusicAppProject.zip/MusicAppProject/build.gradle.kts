plugins {
    id("com.android.application") version "8.13.2" apply false
    id("com.android.library") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false
}

// AGP 8.13 / compileSdk 36: keep androidx.core below 1.19 (1.19+ needs AGP 9.1 and compileSdk 37)
subprojects {
    configurations.configureEach {
        resolutionStrategy {
            force("androidx.core:core:1.15.0", "androidx.core:core-ktx:1.15.0")
        }
    }
}
