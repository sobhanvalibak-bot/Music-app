# Prismal tab bar integration

- Added the complete Prismal Android library module under `Prismal/` (all original 75 source/resource files and AGSL assets are retained).
- Replaced the app's bottom navigation UI with `PrismalMusicTabBar`, preserving the existing MusicApp tab IDs and page callbacks.
- Attached Prismal's backdrop capture to the page Crossfade so the glass tab bar can sample the content behind it.
- Added the Prismal MIT license as `PRISMAL-LICENSE`.

## Toolchain alignment

Prismal uses Kotlin context parameters, so the project Kotlin Gradle plugins were upgraded to 2.2.21. AGP was upgraded to 8.13.2 and the CI Gradle version to 8.13. Both app and library compile against SDK 36. Prismal's documented minimum SDK is 25, so the app minSdk was raised from 24 to 25.

The execution environment used for this integration did not contain Gradle or an Android SDK, so a real `assembleDebug` build could not be run here. Run `gradle assembleDebug` in an Android SDK-equipped environment to verify dependency resolution and compilation.
