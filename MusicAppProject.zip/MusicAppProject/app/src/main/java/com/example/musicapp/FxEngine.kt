package com.example.musicapp

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asAndroidBitmap
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

// ───────────────────────── Sound versions (Slowed + Reverb, Dream, ...) ─────────────────────────
//
// A "version" is the whole song run through an effect chain and written to a new audio file:
//   decode (streaming) → speed change (tape style: slower = lower pitch) → filters → reverb → soft limiter → AAC.
// Everything is streamed in small blocks, so even a long song needs very little memory.
// The new file first plays as a preview (cache folder). "Save" copies it into Music/Effects, where it becomes
// a normal song of the library named like "Let it happen (slowed + reverb)".

enum class FxPreset(
    val label: String,
    /** Goes in brackets after the song title, e.g. "Let it happen (slowed + reverb)". */
    val suffix: String,
    val hint: String,
    val speed: Float,
    val dry: Float,
    val wet: Float,
    val room: Float,
    val damp: Float,
    val lowpassHz: Float = 0f,
    val highpassHz: Float = 0f,
    val chorus: Boolean = false,
    val pan8d: Boolean = false,
    val lofi: Boolean = false,
    val tailSec: Float = 0f,
    val gain: Float = 0.95f
) {
    SLOWED_REVERB("Slowed + Reverb", "slowed + reverb", "Slower and deeper, in a big room", 0.85f, 0.80f, 0.32f, 0.88f, 0.40f, tailSec = 3.5f),
    SUPER_SLOWED("Super Slowed", "super slowed", "Much slower, heavy and wide", 0.75f, 0.78f, 0.36f, 0.90f, 0.45f, tailSec = 4f),
    DREAM("Dream", "dream", "Soft, floating and hazy", 0.92f, 0.66f, 0.50f, 0.92f, 0.30f, lowpassHz = 9000f, chorus = true, tailSec = 4.5f, gain = 0.92f),
    SPED_UP("Sped Up", "sped up", "Faster and higher", 1.20f, 1f, 0f, 0f, 0f),
    NIGHTCORE("Nightcore", "nightcore", "Very fast and high-pitched", 1.32f, 1f, 0f, 0f, 0f),
    LOFI("Lo-fi", "lofi", "Warm, dusty and relaxed", 0.95f, 0.90f, 0.12f, 0.70f, 0.60f, lowpassHz = 4200f, highpassHz = 140f, lofi = true, tailSec = 1.5f),
    EIGHT_D("8D Audio", "8D", "The sound circles around your head", 1f, 0.85f, 0.20f, 0.80f, 0.40f, pan8d = true, tailSec = 2.5f)
}

// ───────────────────────── Registry of previews ─────────────────────────

/** Versions that were built in this session and play from the cache folder (they are not in the library until saved). */
object FxPreview {
    private class Entry(val song: Song, val origin: Song, val preset: FxPreset, val file: File)

    private val map = HashMap<Long, Entry>()

    /** Same id every time for the same song + version, below every id used by online songs. */
    fun idFor(songId: Long, preset: FxPreset): Long = -(7_000_000_000_000L + songId * 16L + preset.ordinal)

    @Synchronized
    fun register(origin: Song, preset: FxPreset, file: File, durationMs: Long): Song {
        val id = idFor(origin.id, preset)
        val song = Song(
            id = id,
            title = "${origin.title} (${preset.suffix})",
            artist = origin.artist,
            album = origin.album,
            albumId = origin.albumId,
            durationMs = durationMs,
            dateAdded = origin.dateAdded,
            uri = Uri.fromFile(file),
            track = origin.track,
            sizeBytes = file.length()
        )
        map[id] = Entry(song, origin, preset, file)
        return song
    }

    @Synchronized fun get(id: Long): Song? = if (id < 0) map[id]?.song else null
    @Synchronized fun isPreview(id: Long): Boolean = id < 0 && map.containsKey(id)
    @Synchronized fun originOf(id: Long): Song? = if (id < 0) map[id]?.origin else null
    @Synchronized fun presetOf(id: Long): FxPreset? = if (id < 0) map[id]?.preset else null
    @Synchronized fun fileOf(id: Long): File? = if (id < 0) map[id]?.file else null

    /** The ready preview of this version, if it was built before and its file is still there. */
    @Synchronized
    fun find(originId: Long, preset: FxPreset): Song? {
        val e = map[idFor(originId, preset)] ?: return null
        return if (e.file.exists()) e.song else null
    }

    @Synchronized fun files(): Set<String> = map.values.map { it.file.absolutePath }.toSet()
}

// ───────────────────────── Start tags ─────────────────────────

/**
 * "Start from here": one moment per song. Whenever the song starts (tapped, next, repeat, queue), playback
 * jumps to it. Saved on the device; the playback service reads the same object.
 */
object StartTags {
    private var prefs: SharedPreferences? = null
    private val tags = HashMap<Long, Long>()

    /** Changes whenever a tag changes, so screens that read [get] redraw. */
    var version by mutableIntStateOf(0)
        private set

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("start_tags", Context.MODE_PRIVATE)
        prefs = p
        for ((k, v) in p.all) {
            val id = k.toLongOrNull() ?: continue
            val ms = (v as? Long) ?: continue
            if (ms > 0L) tags[id] = ms
        }
    }

    @Synchronized
    private fun ownTag(id: Long): Long = tags[id] ?: 0L

    @Synchronized
    fun hasOwn(id: Long): Boolean {
        @Suppress("UNUSED_VARIABLE") val v = version
        return tags.containsKey(id)
    }

    /** The start moment in ms (0 = none). A version made from a song follows the speed of the version. */
    fun get(id: Long): Long {
        @Suppress("UNUSED_VARIABLE") val v = version
        val own = ownTag(id)
        if (own > 0L) return own
        val origin = FxPreview.originOf(id) ?: return 0L
        val preset = FxPreview.presetOf(id) ?: return 0L
        val base = ownTag(origin.id)
        return if (base > 0L) (base / preset.speed).toLong() else 0L
    }

    /** Same as [get]; used by the playback service (no screen to redraw). */
    fun startFor(id: Long): Long = get(id)

    @Synchronized
    fun set(id: Long, ms: Long) {
        val v = ms.coerceAtLeast(0L)
        if (v <= 0L) { clear(id); return }
        tags[id] = v
        prefs?.edit()?.putLong(id.toString(), v)?.apply()
        version++
    }

    @Synchronized
    fun clear(id: Long) {
        if (tags.remove(id) != null) prefs?.edit()?.remove(id.toString())?.apply()
        version++
    }
}

// ───────────────────────── Engine ─────────────────────────

object FxEngine {
    const val RATE = 44100

    /** The version being built right now (null = idle), how far it is (0..1) and the last error. */
    var busy by mutableStateOf<FxPreset?>(null)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    fun clearError() { error = null }

    /**
     * Builds the version (or takes it from this session's cache) and calls [onReady] on the main thread with
     * the song to play. It keeps going even if the panel that asked is closed.
     */
    fun start(context: Context, base: Song, preset: FxPreset, onReady: (Song) -> Unit) {
        if (busy != null) return
        val app = context.applicationContext
        FxPreview.find(base.id, preset)?.let { onReady(it); return }
        busy = preset
        progress = 0f
        error = null
        job = scope.launch {
            try {
                val song = render(app, base, preset) { progress = it }
                busy = null
                onReady(song)
            } catch (e: CancellationException) {
                busy = null
                throw e
            } catch (e: Throwable) {
                busy = null
                error = e.message?.takeIf { it.isNotBlank() } ?: "Could not build this version"
            }
        }
    }

    fun cancel() { job?.cancel() }

    private fun cacheDir(context: Context): File = File(context.cacheDir, "fx").apply { mkdirs() }

    /** Keeps the cache small: the newest files stay, previews that are registered are never deleted. */
    private fun trimCache(context: Context) {
        val keep = FxPreview.files()
        val files = cacheDir(context).listFiles()?.filter { it.absolutePath !in keep }?.sortedBy { it.lastModified() } ?: return
        files.take(max(0, files.size - 4)).forEach { try { it.delete() } catch (_: Exception) { } }
    }

    private suspend fun render(context: Context, base: Song, preset: FxPreset, onProgress: (Float) -> Unit): Song =
        withContext(Dispatchers.IO) {
            trimCache(context)
            val dir = cacheDir(context)
            val stamp = System.currentTimeMillis()
            var file = File(dir, "fx_${base.id}_${preset.name}_$stamp.m4a")
            var durationMs = 0L
            try {
                durationMs = runPipeline(context, base, preset, file, true, onProgress)
            } catch (e: CancellationException) {
                try { file.delete() } catch (_: Exception) { }
                throw e
            } catch (e: Exception) {
                // no AAC encoder on this phone: plain WAV always works
                try { file.delete() } catch (_: Exception) { }
                file = File(dir, "fx_${base.id}_${preset.name}_$stamp.wav")
                try {
                    durationMs = runPipeline(context, base, preset, file, false, onProgress)
                } catch (e2: Exception) {
                    try { file.delete() } catch (_: Exception) { }
                    throw if (e2 is CancellationException) e2 else IOException(e2.message ?: "Could not build this version", e2)
                }
            }
            val song = FxPreview.register(base, preset, file, durationMs)
            // the cover of the original, so the player, notification and widget show it
            try {
                val art = loadArt(context, base, 640)
                if (art != null) {
                    File(context.filesDir, "auto_cover_${song.id}.jpg").outputStream().use {
                        art.asAndroidBitmap().compress(Bitmap.CompressFormat.JPEG, 90, it)
                    }
                }
            } catch (_: Exception) { }
            song
        }

    private suspend fun runPipeline(
        context: Context, base: Song, preset: FxPreset, out: File, aac: Boolean, onProgress: (Float) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        var decoder: FxDecoder? = null
        var sink: FxSink? = null
        var ok = false
        try {
            val dec = FxDecoder(context, base.uri)
            decoder = dec
            val snk: FxSink = if (aac) FxAacSink(out, RATE) else FxWavSink(out, RATE)
            sink = snk
            val proc = FxProcessor(preset)
            var outFrames = 0L
            val totalUs = max(base.durationMs * 1000L, 1L)
            while (true) {
                ensureActive()
                val chunk = dec.read() ?: break
                proc.push(chunk, chunk.size, dec.channels)
                val n = proc.drain(preset.speed * dec.rate / RATE.toDouble())
                if (n > 0) {
                    snk.write(proc.out, n)
                    outFrames += n / 2
                }
                onProgress((dec.lastPtsUs.toFloat() / totalUs).coerceIn(0f, 0.97f))
            }
            if (outFrames == 0L) throw IOException("Could not read this song")
            // tail: lets the reverb ring out, then fades to silence
            val tailFrames = (preset.tailSec * RATE).toInt()
            if (tailFrames > 0) {
                val step = preset.speed * dec.rate / RATE.toDouble()
                proc.startFade(tailFrames)
                var produced = 0
                val feed = (RATE * step).toInt().coerceAtLeast(64)
                while (produced < tailFrames) {
                    ensureActive()
                    proc.pushSilence(feed)
                    val n = proc.drain(step)
                    if (n <= 0) continue
                    val frames = min(n / 2, tailFrames - produced)
                    snk.write(proc.out, frames * 2)
                    produced += frames
                    outFrames += frames
                }
            }
            snk.finish()
            ok = true
            onProgress(1f)
            outFrames * 1000L / RATE
        } finally {
            decoder?.close()
            if (!ok) sink?.abort()
        }
    }

    // ───────── save ─────────

    private const val FOLDER = "Effects"

    private fun savedPrefs(context: Context) = context.applicationContext.getSharedPreferences("fx_saved", Context.MODE_PRIVATE)

    private fun savedKey(baseId: Long, preset: FxPreset) = "${baseId}_${preset.name}"

    private fun existsInLibrary(context: Context, id: Long): Boolean = try {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        context.contentResolver.query(uri, arrayOf(MediaStore.Audio.Media._ID), null, null, null)?.use { it.count > 0 } ?: false
    } catch (_: Exception) {
        false
    }

    /** True when this version of this song is already in the library (and was not deleted since). */
    fun isSaved(context: Context, baseId: Long, preset: FxPreset): Boolean {
        val id = savedPrefs(context).getLong(savedKey(baseId, preset), 0L)
        return id > 0L && existsInLibrary(context, id)
    }

    /** Copies the preview into Music/Effects and returns the id of the new library song. */
    suspend fun save(context: Context, previewId: Long): Long = withContext(Dispatchers.IO) {
        val base = FxPreview.originOf(previewId) ?: throw IOException("Build this version first")
        val preset = FxPreview.presetOf(previewId) ?: throw IOException("Build this version first")
        val file = FxPreview.fileOf(previewId)?.takeIf { it.exists() } ?: throw IOException("The preview file is gone, build it again")
        val title = "${base.title} (${preset.suffix})"
        val ext = file.extension.lowercase()
        val mime = if (ext == "wav") "audio/x-wav" else "audio/mp4"
        val name = title.replace(Regex("""[\\/:*?"<>|\u0000-\u001F]"""), "_").trim().take(100).ifBlank { "Version" } + "." + ext

        val newId: Long
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/$FOLDER")
                put(MediaStore.Audio.Media.TITLE, title)
                put(MediaStore.Audio.Media.ARTIST, base.artist)
                put(MediaStore.Audio.Media.ALBUM, base.album)
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
                ?: throw IOException("Cannot create the file in Music")
            try {
                val o = resolver.openOutputStream(uri) ?: throw IOException("Cannot write the file")
                o.use { os -> file.inputStream().use { it.copyTo(os) } }
                val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                try { resolver.delete(uri, null, null) } catch (_: Exception) { }
                throw if (e is IOException) e else IOException(e.message, e)
            }
            newId = ContentUris.parseId(uri)
        } else {
            // Android 9 and older: normal file, then the media scanner adds it
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), FOLDER)
            dir.mkdirs()
            val target = File(dir, name)
            try { file.copyTo(target, overwrite = true) } catch (e: Exception) {
                throw IOException("Cannot write to Music/$FOLDER (storage permission?)", e)
            }
            val uri: Uri? = suspendCancellableCoroutine { cont ->
                MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf(mime)) { _, u -> if (cont.isActive) cont.resume(u) }
            }
            val u = uri ?: throw IOException("Saved, but the library did not see it yet")
            newId = ContentUris.parseId(u)
        }

        // cover of the original, and the same start tag (moved with the speed)
        try {
            val art = loadArt(context, base, 640)
            if (art != null) {
                File(context.filesDir, "auto_cover_$newId.jpg").outputStream().use {
                    art.asAndroidBitmap().compress(Bitmap.CompressFormat.JPEG, 92, it)
                }
                MixStore.register(newId)
            }
        } catch (_: Exception) { }
        val tag = StartTags.get(previewId)
        if (tag > 0L) StartTags.set(newId, tag)
        savedPrefs(context).edit().putLong(savedKey(base.id, preset), newId).apply()
        newId
    }
}

// ───────────────────────── Decoder (streaming) ─────────────────────────

private class FxDecoder(context: Context, uri: Uri) {
    private val ex = MediaExtractor()
    private var codec: MediaCodec? = null
    private val info = MediaCodec.BufferInfo()
    private var inputDone = false
    private var outputDone = false

    var rate = FxEngine.RATE
        private set
    var channels = 2
        private set
    var lastPtsUs = 0L
        private set

    init {
        try {
            ex.setDataSource(context, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) throw IOException("No audio in this file")
            ex.selectTrack(track)
            if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()
        } catch (e: Exception) {
            close()
            throw if (e is IOException) e else IOException(e.message ?: "Could not open this song", e)
        }
    }

    /** The next block of decoded sound (interleaved 16-bit), or null at the end of the song. */
    fun read(): ShortArray? {
        val dec = codec ?: return null
        var lastWork = System.currentTimeMillis()
        while (!outputDone) {
            if (!inputDone) {
                val ii = dec.dequeueInputBuffer(5_000L)
                if (ii >= 0) {
                    val buf = dec.getInputBuffer(ii)!!
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) {
                        dec.queueInputBuffer(ii, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    } else {
                        dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                        ex.advance()
                    }
                    lastWork = System.currentTimeMillis()
                }
            }
            val oi = dec.dequeueOutputBuffer(info, 5_000L)
            if (oi >= 0) {
                lastWork = System.currentTimeMillis()
                var result: ShortArray? = null
                if (info.size > 0) {
                    val ob = dec.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    result = ShortArray(sb.remaining())
                    sb.get(result)
                    lastPtsUs = info.presentationTimeUs
                }
                dec.releaseOutputBuffer(oi, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                if (result != null && result.isNotEmpty()) return result
            } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val nf = dec.outputFormat
                if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
            if (System.currentTimeMillis() - lastWork > 20_000L) throw IOException("The decoder stopped answering")
        }
        return null
    }

    fun close() {
        try { codec?.stop() } catch (_: Exception) { }
        try { codec?.release() } catch (_: Exception) { }
        codec = null
        try { ex.release() } catch (_: Exception) { }
    }
}

// ───────────────────────── Sinks (AAC / WAV) ─────────────────────────

private interface FxSink {
    fun write(pcm: ShortArray, count: Int)
    fun finish()
    fun abort()
}

private class FxAacSink(private val file: File, private val rate: Int) : FxSink {
    private val enc: MediaCodec
    private val muxer: MediaMuxer
    private var track = -1
    private var started = false
    private var fedFrames = 0L
    private var outputDone = false
    private val info = MediaCodec.BufferInfo()

    init {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
        }
        enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        try {
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } catch (e: Exception) {
            try { enc.release() } catch (_: Exception) { }
            throw e
        }
    }

    private fun drain(waitUs: Long) {
        while (true) {
            val oi = enc.dequeueOutputBuffer(info, waitUs)
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(enc.outputFormat)
                muxer.start()
                started = true
            } else if (oi >= 0) {
                val ob = enc.getOutputBuffer(oi)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started) {
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    muxer.writeSampleData(track, ob, info)
                }
                enc.releaseOutputBuffer(oi, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) { outputDone = true; return }
            } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                return
            }
            // INFO_OUTPUT_BUFFERS_CHANGED: just ask again
        }
    }

    override fun write(pcm: ShortArray, count: Int) {
        var off = 0
        val deadline = System.currentTimeMillis() + 60_000L
        while (off < count) {
            val ii = enc.dequeueInputBuffer(10_000L)
            if (ii >= 0) {
                val buf: ByteBuffer = enc.getInputBuffer(ii)!!
                buf.clear()
                var n = min(buf.remaining() / 2, count - off)
                n -= n % 2
                if (n > 0) {
                    buf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm, off, n)
                    enc.queueInputBuffer(ii, 0, n * 2, fedFrames * 1_000_000L / rate, 0)
                    off += n
                    fedFrames += (n / 2).toLong()
                } else {
                    enc.queueInputBuffer(ii, 0, 0, fedFrames * 1_000_000L / rate, 0)
                }
            }
            drain(0L)
            if (System.currentTimeMillis() > deadline) throw IOException("The AAC encoder stopped answering")
        }
    }

    override fun finish() {
        val deadline = System.currentTimeMillis() + 60_000L
        var queued = false
        while (!queued) {
            val ii = enc.dequeueInputBuffer(10_000L)
            if (ii >= 0) {
                enc.queueInputBuffer(ii, 0, 0, fedFrames * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                queued = true
            }
            drain(0L)
            if (System.currentTimeMillis() > deadline) throw IOException("The AAC encoder did not finish")
        }
        while (!outputDone) {
            drain(10_000L)
            if (System.currentTimeMillis() > deadline) throw IOException("The AAC encoder did not finish")
        }
        if (!started) throw IOException("AAC encoder did not finish")
        release(true)
    }

    override fun abort() = release(false)

    private fun release(stopMuxer: Boolean) {
        try { enc.stop() } catch (_: Exception) { }
        try { enc.release() } catch (_: Exception) { }
        if (stopMuxer) { try { muxer.stop() } catch (_: Exception) { } }
        try { muxer.release() } catch (_: Exception) { }
        if (!stopMuxer) { try { file.delete() } catch (_: Exception) { } }
    }
}

private class FxWavSink(private val file: File, private val rate: Int) : FxSink {
    private val raf = RandomAccessFile(file, "rw")
    private var dataLen = 0L
    private val chunk = ByteBuffer.allocate(1 shl 16).order(ByteOrder.LITTLE_ENDIAN)

    init {
        raf.setLength(0)
        raf.write(ByteArray(44))
    }

    override fun write(pcm: ShortArray, count: Int) {
        var i = 0
        while (i < count) {
            chunk.clear()
            val n = min(chunk.capacity() / 2, count - i)
            chunk.asShortBuffer().put(pcm, i, n)
            raf.write(chunk.array(), 0, n * 2)
            i += n
            dataLen += n * 2L
        }
    }

    override fun finish() {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).toInt()); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(2)
        h.putInt(rate); h.putInt(rate * 4); h.putShort(4); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(dataLen.toInt())
        raf.seek(0)
        raf.write(h.array())
        raf.close()
    }

    override fun abort() {
        try { raf.close() } catch (_: Exception) { }
        try { file.delete() } catch (_: Exception) { }
    }
}

// ───────────────────────── DSP ─────────────────────────

/** Speed change (cubic interpolation) + the effect chain of one version, block by block. */
private class FxProcessor(private val preset: FxPreset) {
    // ── resampler: stereo float frames waiting to be read; frame 0 is the "frame before the first one" ──
    private var buf = FloatArray(1 shl 16)
    private var frames = 1
    private var pos = 1.0

    /** Output of the last [drain]: interleaved 16-bit stereo. */
    var out = ShortArray(1 shl 14)
        private set

    private val reverb: FxReverb? = if (preset.wet > 0f) FxReverb(preset.room, preset.damp) else null
    private val lpL = if (preset.lowpassHz > 0f) FxBiquad(true, preset.lowpassHz) else null
    private val lpR = if (preset.lowpassHz > 0f) FxBiquad(true, preset.lowpassHz) else null
    private val hpL = if (preset.highpassHz > 0f) FxBiquad(false, preset.highpassHz) else null
    private val hpR = if (preset.highpassHz > 0f) FxBiquad(false, preset.highpassHz) else null
    private val chorusL = if (preset.chorus) FxChorus(0.0) else null
    private val chorusR = if (preset.chorus) FxChorus(PI * 0.5) else null

    // 8D: the sound walks from ear to ear (one round in 8 seconds)
    private var panPhase = 0.0
    private val panInc = 2.0 * PI / (8.0 * FxEngine.RATE)
    private var panL = 0.7f
    private var panR = 0.7f
    private var panCount = 0

    private var fadeTotal = 0
    private var fadeDone = 0

    fun startFade(totalFrames: Int) { fadeTotal = totalFrames; fadeDone = 0 }

    private fun ensure(needFrames: Int) {
        val need = needFrames * 2
        if (need > buf.size) buf = buf.copyOf(max(need, buf.size * 2))
    }

    fun push(src: ShortArray, n: Int, ch: Int) {
        val c = max(ch, 1)
        val inFrames = n / c
        ensure(frames + inFrames)
        var o = frames * 2
        if (c == 1) {
            for (k in 0 until inFrames) {
                val v = src[k] / 32768f
                buf[o++] = v
                buf[o++] = v
            }
        } else {
            for (k in 0 until inFrames) {
                buf[o++] = src[k * c] / 32768f
                buf[o++] = src[k * c + 1] / 32768f
            }
        }
        frames += inFrames
    }

    fun pushSilence(inFrames: Int) {
        ensure(frames + inFrames)
        java.util.Arrays.fill(buf, frames * 2, (frames + inFrames) * 2, 0f)
        frames += inFrames
    }

    private fun cubic(a: Float, b: Float, c: Float, d: Float, t: Float): Float =
        b + 0.5f * t * (c - a + t * (2f * a - 5f * b + 4f * c - d + t * (3f * (b - c) + d - a)))

    private fun clip(x: Float): Float {
        val a = abs(x)
        if (a < 0.85f) return x
        val y = 0.85f + 0.15f * tanh((a - 0.85f) / 0.15f)
        return if (x < 0f) -y else y
    }

    /** Reads every frame that is ready, runs the chain on it and leaves the result in [out]. Returns the number of shorts. */
    fun drain(step: Double): Int {
        val maxOut = (((frames - pos) / step).toInt() + 4).coerceAtLeast(4)
        if (out.size < maxOut * 2) out = ShortArray(maxOut * 2 + 1024)
        var o = 0
        val dry = preset.dry
        val wet = preset.wet
        val gain = preset.gain
        while (true) {
            val i = pos.toInt()
            if (i + 2 >= frames) break
            val t = (pos - i).toFloat()
            val i0 = (i - 1) * 2
            val i1 = i * 2
            val i2 = (i + 1) * 2
            val i3 = (i + 2) * 2
            var l = cubic(buf[i0], buf[i1], buf[i2], buf[i3], t)
            var r = cubic(buf[i0 + 1], buf[i1 + 1], buf[i2 + 1], buf[i3 + 1], t)
            pos += step

            if (preset.pan8d) {
                if (panCount == 0) {
                    val a = ((sin(panPhase) + 1.0) * 0.5 * (PI / 2.0))
                    panL = cos(a).toFloat()
                    panR = sin(a).toFloat()
                }
                panCount = (panCount + 1) and 15
                panPhase += panInc
                val m = (l + r) * 0.5f
                l = m * panL * 1.35f * 0.8f + l * 0.2f
                r = m * panR * 1.35f * 0.8f + r * 0.2f
            }
            if (hpL != null && hpR != null) { l = hpL.process(l); r = hpR.process(r) }
            if (lpL != null && lpR != null) { l = lpL.process(l); r = lpR.process(r) }
            if (preset.lofi) {
                // a little saturation and a narrower picture, like an old tape
                l = l / (1f + 0.35f * abs(l))
                r = r / (1f + 0.35f * abs(r))
                val m = (l + r) * 0.5f
                l = l * 0.5f + m * 0.5f
                r = r * 0.5f + m * 0.5f
            }
            if (chorusL != null && chorusR != null) {
                l = l * 0.75f + chorusL.process(l) * 0.45f
                r = r * 0.75f + chorusR.process(r) * 0.45f
            }
            if (reverb != null) {
                reverb.process(l, r)
                l = l * dry + reverb.outL * wet
                r = r * dry + reverb.outR * wet
            }
            l *= gain
            r *= gain
            if (fadeTotal > 0) {
                val g = (1f - fadeDone.toFloat() / fadeTotal).coerceAtLeast(0f)
                fadeDone++
                l *= g
                r *= g
            }
            out[o++] = (clip(l) * 32767f).toInt().coerceIn(-32767, 32767).toShort()
            out[o++] = (clip(r) * 32767f).toInt().coerceIn(-32767, 32767).toShort()
        }
        // forget the frames that can never be needed again (keep one before the read position)
        val keepFrom = (pos.toInt() - 1).coerceAtLeast(0)
        if (keepFrom > 0) {
            System.arraycopy(buf, keepFrom * 2, buf, 0, (frames - keepFrom) * 2)
            frames -= keepFrom
            pos -= keepFrom
        }
        return o
    }
}

/** Second-order low-pass / high-pass filter (Butterworth-like). */
private class FxBiquad(lowpass: Boolean, hz: Float) {
    private val b0: Float
    private val b1: Float
    private val b2: Float
    private val a1: Float
    private val a2: Float
    private var z1 = 0f
    private var z2 = 0f

    init {
        val w0 = 2.0 * PI * hz / FxEngine.RATE
        val cw = cos(w0)
        val alpha = sin(w0) / (2.0 * 0.7071)
        val a0 = 1.0 + alpha
        if (lowpass) {
            b0 = (((1.0 - cw) / 2.0) / a0).toFloat()
            b1 = ((1.0 - cw) / a0).toFloat()
            b2 = b0
        } else {
            b0 = (((1.0 + cw) / 2.0) / a0).toFloat()
            b1 = (-(1.0 + cw) / a0).toFloat()
            b2 = b0
        }
        a1 = ((-2.0 * cw) / a0).toFloat()
        a2 = ((1.0 - alpha) / a0).toFloat()
    }

    fun process(x: Float): Float {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }
}

/** Slow, soft wobble of a short delay: the "floating" part of Dream. Returns only the delayed signal. */
private class FxChorus(private var phase: Double) {
    private val size = 4096
    private val line = FloatArray(size)
    private var w = 0
    private val inc = 2.0 * PI * 0.35 / FxEngine.RATE

    fun process(x: Float): Float {
        line[w] = x
        val delay = 530.0 + 220.0 * sin(phase)
        phase += inc
        var rp = w - delay
        if (rp < 0.0) rp += size
        val i0 = rp.toInt() % size
        val i1 = (i0 + 1) % size
        val f = (rp - rp.toInt()).toFloat()
        val y = line[i0] + (line[i1] - line[i0]) * f
        w = (w + 1) % size
        return y
    }
}

/** Freeverb: 8 comb + 4 all-pass filters per side. [outL]/[outR] are about 1.5x as loud as the input at wet = 1. */
private class FxReverb(room: Float, damp: Float) {
    private val combLen = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val apLen = intArrayOf(556, 441, 341, 225)
    private val spread = 23
    private val cbL = Array(8) { FloatArray(combLen[it]) }
    private val cbR = Array(8) { FloatArray(combLen[it] + spread) }
    private val ciL = IntArray(8)
    private val ciR = IntArray(8)
    private val csL = FloatArray(8)
    private val csR = FloatArray(8)
    private val abL = Array(4) { FloatArray(apLen[it]) }
    private val abR = Array(4) { FloatArray(apLen[it] + spread) }
    private val aiL = IntArray(4)
    private val aiR = IntArray(4)
    private val fb = room * 0.28f + 0.7f
    private val d1 = damp * 0.4f
    private val d2 = 1f - d1

    var outL = 0f
        private set
    var outR = 0f
        private set

    fun process(l: Float, r: Float) {
        val inp = (l + r) * 0.015f + 1.0e-20f   // the tiny offset keeps the tail out of denormal numbers
        var a = 0f
        var b = 0f
        for (k in 0 until 8) {
            val bl = cbL[k]
            var i = ciL[k]
            val o = bl[i]
            csL[k] = o * d2 + csL[k] * d1
            bl[i] = inp + csL[k] * fb
            if (++i >= bl.size) i = 0
            ciL[k] = i
            a += o

            val br = cbR[k]
            var j = ciR[k]
            val p = br[j]
            csR[k] = p * d2 + csR[k] * d1
            br[j] = inp + csR[k] * fb
            if (++j >= br.size) j = 0
            ciR[k] = j
            b += p
        }
        for (k in 0 until 4) {
            val bl = abL[k]
            var i = aiL[k]
            val bo = bl[i]
            val oa = -a + bo
            bl[i] = a + bo * 0.5f
            if (++i >= bl.size) i = 0
            aiL[k] = i
            a = oa

            val br = abR[k]
            var j = aiR[k]
            val bp = br[j]
            val ob = -b + bp
            br[j] = b + bp * 0.5f
            if (++j >= br.size) j = 0
            aiR[k] = j
            b = ob
        }
        outL = a
        outR = b
    }
}
