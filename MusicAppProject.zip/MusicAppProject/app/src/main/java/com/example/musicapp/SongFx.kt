package com.example.musicapp

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/**
 * Full player > the wave button: sound versions of the playing song (Slowed + Reverb, Dream, ...) and its start tag.
 *
 *  - Tap a version: the whole song is rebuilt with that effect (progress is shown), then it plays at once.
 *  - Save: the version is copied into the library as "<title> (<version>)".
 *  - Start tag: pick a moment; the song always starts from it.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SongFxPanel(
    song: Song,
    positionMs: Long,
    p: Palette,
    onClose: () -> Unit,
    onSeek: (Long) -> Unit,
    onPlaySong: (Song) -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    // when a version is playing, the versions are made from the song it came from
    val base = FxPreview.originOf(song.id) ?: song
    val activePreset = FxPreview.presetOf(song.id)
    val busy = FxEngine.busy
    val progress = FxEngine.progress
    val error = FxEngine.error
    var savedTick by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    val isSaved = remember(song.id, savedTick) {
        activePreset != null && FxEngine.isSaved(context, base.id, activePreset)
    }
    val canBuild = !song.isOnline

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .pointerInput(Unit) { detectTapGestures { onClose() } }
    ) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .heightIn(max = 680.dp)
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(p.bg)
                .pointerInput(Unit) { detectTapGestures { } }
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Sound versions", Modifier.weight(1f),
                    fontSize = 20.sp, fontWeight = FontWeight.Bold, color = p.text
                )
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) { GlyphIcon(Glyph.ChevronDown, p.text, Modifier.size(22.dp)) }
            }
            Text(
                if (canBuild) "Builds a new version of “${base.title}” and plays it right away"
                else "Versions are only made from songs on your phone",
                fontSize = 13.sp, color = p.secondary
            )
            Spacer(Modifier.height(10.dp))

            if (canBuild) {
                if (activePreset != null) {
                    FxRow("Original", base.title, "Back", false, null, busy == null, p) { onPlaySong(base) }
                }
                FxPreset.values().forEach { preset ->
                    val building = busy == preset
                    val ready = FxPreview.find(base.id, preset) != null
                    FxRow(
                        label = preset.label,
                        hint = preset.hint,
                        status = when {
                            building -> "${(progress * 100).toInt()}%"
                            activePreset == preset -> "Playing"
                            ready -> "Ready"
                            else -> "Build"
                        },
                        active = activePreset == preset,
                        progress = if (building) progress else null,
                        enabled = busy == null,
                        p = p
                    ) {
                        FxEngine.start(context, base, preset) { built -> onPlaySong(built) }
                    }
                }
                if (busy != null) {
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Building ${busy.label}… keep the app open", Modifier.weight(1f),
                            fontSize = 12.sp, color = p.secondary
                        )
                        Text(
                            "Cancel", fontSize = 13.sp, color = p.accent, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { FxEngine.cancel() }.padding(8.dp)
                        )
                    }
                }
                if (error != null && busy == null) {
                    Spacer(Modifier.height(6.dp))
                    Text(error, fontSize = 13.sp, color = Color(0xFFFF453A))
                }

                if (activePreset != null) {
                    Spacer(Modifier.height(14.dp))
                    val title = "${base.title} (${activePreset.suffix})"
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSaved) p.selectedPill else p.accent)
                            .clickable(enabled = !isSaved && !saving) {
                                scope.launch {
                                    saving = true
                                    try {
                                        FxEngine.save(context, song.id)
                                        savedTick++
                                        Toast.makeText(context, "Saved: $title", Toast.LENGTH_SHORT).show()
                                        onSaved()
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        Toast.makeText(context, e.message ?: "Could not save", Toast.LENGTH_LONG).show()
                                    } finally {
                                        saving = false
                                    }
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when {
                                isSaved -> "Saved in your library ✓"
                                saving -> "Saving…"
                                else -> "Save as “$title”"
                            },
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                            color = if (isSaved) p.secondary else Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // ───────── start tag ─────────
            Spacer(Modifier.height(20.dp))
            val tag = StartTags.get(song.id)
            Text(
                if (tag > 0L) "Start tag · ${formatTime(tag)}" else "Start tag",
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = p.secondary
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (tag > 0L) "This song always starts from ${formatTime(tag)}, every time it comes."
                else "Move to the moment you love, open this panel and tag it. The song will start from there every time.",
                fontSize = 13.sp, color = p.secondary
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OptionPill("Tag ${formatTime(positionMs)}", false, p) {
                    if (positionMs < 1000L) {
                        Toast.makeText(context, "Move the song forward first, then tag that moment", Toast.LENGTH_SHORT).show()
                    } else {
                        StartTags.set(song.id, positionMs)
                        Toast.makeText(context, "Starts from ${formatTime(positionMs)} now", Toast.LENGTH_SHORT).show()
                    }
                }
                if (tag > 0L) OptionPill("Play from tag", false, p) { onSeek(tag) }
                if (tag > 0L) OptionPill("−1 s", false, p) { StartTags.set(song.id, (tag - 1000L).coerceAtLeast(1000L)) }
                if (tag > 0L) OptionPill("+1 s", false, p) { StartTags.set(song.id, tag + 1000L) }
                if (StartTags.hasOwn(song.id)) OptionPill("Remove tag", false, p) { StartTags.clear(song.id) }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/** One row of the list of versions: name, short description, state on the right and a thin progress line while building. */
@Composable
private fun FxRow(
    label: String,
    hint: String,
    status: String,
    active: Boolean,
    progress: Float?,
    enabled: Boolean,
    p: Palette,
    onClick: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (active) p.selectedPill else p.card)
            .clickable(enabled = enabled && !active) { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = p.text)
                Text(hint, fontSize = 12.sp, color = p.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                status, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                color = if (active || progress != null) p.accent else p.secondary
            )
        }
        if (progress != null) {
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(p.secondary.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(p.accent)
                )
            }
        }
    }
}
