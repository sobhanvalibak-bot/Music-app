package com.example.musicapp

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import org.jaudiotagger.tag.TagOptionSingleton
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

// ───────────────────────── Edit song info inside the audio file ─────────────────────────

/** The text tags of a song that can be edited. Empty text removes that tag from the file. */
data class TagEdit(
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val year: String,
    val track: String
)

sealed interface SaveResult {
    data object Ok : SaveResult

    /** The file cannot hold tags (its format), so the new info was stored in the phone's library only. */
    data object OkLibraryOnly : SaveResult

    /** Android 10/11+: the user has to allow this app to modify the file (system dialog). */
    class NeedsGrant(val sender: IntentSender) : SaveResult

    /** Android 9 and older: needs the storage write permission. */
    data object NeedsStoragePermission : SaveResult

    /** Android 11+: "All files access" lets the tags be written straight into the song in its own folder. */
    class NeedsAllFilesAccess(val intent: Intent) : SaveResult

    class Error(val message: String) : SaveResult
}

/**
 * Reads and writes the real tags (ID3 for mp3, MP4 atoms for m4a, Vorbis comments for flac/ogg...)
 * with jaudiotagger. The library needs a normal file: whenever Android lets the app write to the song
 * where it lives (storage permission on Android 9-, "All files access" on Android 11+), the song is edited
 * in place in its own folder. Only when that is not allowed, a copy in the app cache is edited and
 * copied back over the original through MediaStore.
 */
object TagEditor {

    /** Length of the file in ms the way a player sees it (0 when it cannot be opened). */
    internal fun durationOf(file: File): Long {
        val r = android.media.MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Throwable) {
            0L
        } finally {
            try { r.release() } catch (_: Throwable) { }
        }
    }

    /** True when the file still opens like a normal song and has (about) the length it had before ([expectedMs], 0 = any). */
    internal fun playable(file: File, expectedMs: Long = 0L): Boolean {
        val d = durationOf(file)
        return d > 0L && (expectedMs <= 0L || kotlin.math.abs(d - expectedMs) <= 2500L)
    }

    /**
     * Copies the AAC samples into a plain (non-fragmented) MPEG-4 audio file: real duration, seekable, and a layout
     * that tag writers understand. Songs downloaded from YouTube/SoundCloud are DASH/HLS pieces (fragmented mp4 with
     * moof atoms) that cannot be tagged at all until they are re-packed like this. No re-encoding, no quality loss.
     * Returns the new file (next to [src]) or null when it cannot be done.
     */
    internal fun repackAac(src: File): File? {
        val out = File(src.parentFile, "rm_${System.nanoTime()}.m4a")
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            ex.setDataSource(src.absolutePath)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null || fmt.getString(MediaFormat.KEY_MIME) != "audio/mp4a-latm") return null
            ex.selectTrack(track)
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val mt = m.addTrack(fmt)
            m.start()
            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            var first = -1L
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val t = ex.sampleTime
                if (first < 0L) first = t
                val flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, n, (t - first).coerceAtLeast(0L), flags)
                m.writeSampleData(mt, buf, info)
                ex.advance()
            }
            m.stop()
            m.release()
            muxer = null
            return if (out.length() > 1024L) out else { out.delete(); null }
        } catch (e: Throwable) {
            try { muxer?.release() } catch (_: Throwable) { }
            out.delete()
            return null
        } finally {
            try { ex.release() } catch (_: Throwable) { }
        }
    }

    /**
     * Writes the tags (and optionally the cover) of an .m4a/.mp4 file with [Mp4Tagger]. A fragmented file is re-packed
     * first. Returns the file that now holds the tags (the same file, or the re-packed one) or null when it did not work.
     * The result is checked: a file that no longer plays like the original is never returned. [file] itself is only
     * changed when the result is good.
     */
    internal fun writeMp4Tags(file: File, text: Map<String, String>, cover: ByteArray?, expectedMs: Long): File? {
        var work = file
        var packed: File? = null
        try {
            if (!Mp4Tagger.isMp4(file)) return null
            if (Mp4Tagger.isFragmented(file)) {
                packed = repackAac(file) ?: return null
                work = packed
            } else {
                // never edit the only copy: write into a sibling copy and swap when it is good
                work = File(file.parentFile, "mp4w_${System.nanoTime()}_${file.name}")
                file.copyTo(work, overwrite = true)
                packed = work
            }
            Mp4Tagger.write(work, text, cover)
            if (!Mp4Tagger.isMp4(work) || (expectedMs > 0L && !playable(work, expectedMs))) {
                packed?.delete()
                return null
            }
            return work
        } catch (t: Throwable) {
            packed?.delete()
            return null
        }
    }

    private fun prepareLibrary() {
        // The Android build of jaudiotagger has a switch that avoids java.awt classes.
        try {
            val instance = TagOptionSingleton.getInstance()
            instance.javaClass
                .getMethod("setAndroid", java.lang.Boolean.TYPE)
                .invoke(instance, true)
        } catch (t: Throwable) {
        }
    }

    /** Display name (for the file extension) and the real path (for re-scanning). */
    private fun fileInfo(context: Context, song: Song): Pair<String, String?> {
        var name = ""
        var path: String? = null
        try {
            context.contentResolver.query(
                song.uri,
                arrayOf(MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATA),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0) ?: ""
                    path = c.getString(1)
                }
            }
        } catch (e: Exception) {
        }
        return name to path
    }

    private fun extensionOf(name: String, path: String?): String {
        val fromName = name.substringAfterLast('.', "")
        if (fromName.isNotEmpty()) return fromName
        val fromPath = path?.substringAfterLast('.', "") ?: ""
        return fromPath.ifEmpty { "mp3" }
    }

    private fun copyToCache(context: Context, song: Song, ext: String): File {
        val file = File(context.cacheDir, "tag_edit_${song.id}.$ext")
        val input = context.contentResolver.openInputStream(song.uri)
            ?: throw IOException("Cannot open the song file")
        input.use { i -> file.outputStream().use { o -> i.copyTo(o) } }
        return file
    }

    /** Current tags of the file. Falls back to what MediaStore knows if the file cannot be read. */
    suspend fun readTags(context: Context, song: Song): TagEdit = withContext(Dispatchers.IO) {
        var cache: File? = null
        try {
            prepareLibrary()
            val (name, path) = fileInfo(context, song)
            val file = copyToCache(context, song, extensionOf(name, path))
            cache = file
            val tag: Tag? = AudioFileIO.read(file).tag
            fun value(key: FieldKey): String =
                try {
                    tag?.getFirst(key) ?: ""
                } catch (e: Exception) {
                    ""
                }
            TagEdit(
                title = value(FieldKey.TITLE).ifBlank { song.title },
                artist = value(FieldKey.ARTIST),
                album = value(FieldKey.ALBUM),
                genre = value(FieldKey.GENRE),
                year = value(FieldKey.YEAR),
                track = value(FieldKey.TRACK)
            )
        } catch (t: Throwable) {
            // jaudiotagger cannot read this file (e.g. fragmented m4a): ask Android's own reader instead
            var genre = ""
            var year = ""
            var track = if (song.track > 0) (song.track % 1000).toString() else ""
            var title = song.title
            var artist = song.artist.takeUnless { it == "Unknown Artist" } ?: ""
            var album = song.album.takeUnless { it == "Unknown Album" } ?: ""
            val r = android.media.MediaMetadataRetriever()
            try {
                r.setDataSource(context, song.uri)
                fun m(k: Int): String = try { r.extractMetadata(k)?.trim() ?: "" } catch (_: Throwable) { "" }
                m(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE).takeIf { it.isNotEmpty() }?.let { title = it }
                m(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST).takeIf { it.isNotEmpty() }?.let { artist = it }
                m(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM).takeIf { it.isNotEmpty() }?.let { album = it }
                genre = m(android.media.MediaMetadataRetriever.METADATA_KEY_GENRE)
                year = m(android.media.MediaMetadataRetriever.METADATA_KEY_YEAR)
                m(android.media.MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER).takeIf { it.isNotEmpty() }?.let { track = it }
            } catch (_: Throwable) {
            } finally {
                try { r.release() } catch (_: Throwable) { }
            }
            TagEdit(title = title, artist = artist, album = album, genre = genre, year = year, track = track)
        } finally {
            cache?.delete()
        }
    }

    /** Lyrics stored inside the audio file (ID3 USLT / Vorbis LYRICS...), or "" when there are none. */
    suspend fun readLyrics(context: Context, song: Song): String = withContext(Dispatchers.IO) {
        var cache: File? = null
        try {
            prepareLibrary()
            val (name, path) = fileInfo(context, song)
            val file = copyToCache(context, song, extensionOf(name, path))
            cache = file
            val tag: Tag? = AudioFileIO.read(file).tag
            try {
                tag?.getFirst(FieldKey.LYRICS) ?: ""
            } catch (e: Exception) {
                ""
            }
        } catch (t: Throwable) {
            ""
        } finally {
            cache?.delete()
        }
    }

    /** The song's real file when this app may write to it directly, else null. */
    private fun directFile(context: Context, path: String?): File? {
        if (path == null) return null
        val f = File(path)
        if (!f.isFile) return null
        val allowed = when {
            Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
            Build.VERSION.SDK_INT >= 29 -> false
            else -> ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
        return if (allowed && f.canWrite()) f else null
    }

    /** Writes [edit] into the audio file itself and refreshes MediaStore. */
    suspend fun save(context: Context, song: Song, edit: TagEdit): SaveResult =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            val (name, path) = fileInfo(context, song)
            val direct = directFile(context, path)

            if (direct == null) {
                // Android 11+: ask once for "All files access", so the song can be edited right in its folder.
                if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                    val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
                    if (!prefs.getBoolean("allfiles_asked", false)) {
                        prefs.edit().putBoolean("allfiles_asked", true).apply()
                        return@withContext SaveResult.NeedsAllFilesAccess(
                            Intent(
                                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    }
                }
                // Not allowed to touch the file directly: ask for permission to modify this one file.
                if (Build.VERSION.SDK_INT >= 30) {
                    val granted = context.checkUriPermission(
                        song.uri, Process.myPid(), Process.myUid(),
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) {
                        return@withContext SaveResult.NeedsGrant(
                            MediaStore.createWriteRequest(resolver, listOf(song.uri)).intentSender
                        )
                    }
                } else if (Build.VERSION.SDK_INT < 29 && ContextCompat.checkSelfPermission(
                        context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return@withContext SaveResult.NeedsStoragePermission
                }
            }

            val temps = mutableListOf<File>()
            try {
                prepareLibrary()
                // Always work on a COPY in the app cache. The song itself is replaced only after the copy was written
                // and checked, so a failed write can never damage it or make it vanish from the library.
                val original = copyToCache(context, song, extensionOf(name, path)).also { temps += it }
                val before = durationOf(original)
                var file = original

                // 1) write the tags into the copy.
                //    m4a / mp4: our own writer first (it also re-packs fragmented YouTube/SoundCloud files, which
                //    jaudiotagger cannot tag at all). Everything else, and any m4a the own writer refuses: jaudiotagger.
                var fileTagged = false
                if (Mp4Tagger.isMp4(original)) {
                    val text = linkedMapOf(
                        "nam" to edit.title.trim(),
                        "ART" to edit.artist.trim(),
                        "alb" to edit.album.trim(),
                        "gen" to edit.genre.trim(),
                        "day" to edit.year.trim(),
                        "trkn" to edit.track.trim()
                    )
                    val done = writeMp4Tags(original, text, null, before)
                    if (done != null) {
                        temps += done
                        file = done
                        fileTagged = true
                    }
                }
                if (!fileTagged) {
                    // fresh copy: the first one may have been touched by a failed attempt
                    val fresh = copyToCache(context, song, extensionOf(name, path)).also { temps += it }
                    file = fresh
                    try {
                        val audio = AudioFileIO.read(fresh)
                        val tag = audio.tagOrCreateAndSetDefault
                        fun put(key: FieldKey, raw: String) {
                            val v = raw.trim()
                            if (v.isEmpty()) {
                                try {
                                    tag.deleteField(key)
                                } catch (e: Exception) {
                                }
                            } else {
                                tag.setField(key, v)
                            }
                        }
                        put(FieldKey.TITLE, edit.title)
                        put(FieldKey.ARTIST, edit.artist)
                        put(FieldKey.ALBUM, edit.album)
                        put(FieldKey.GENRE, edit.genre)
                        put(FieldKey.YEAR, edit.year)
                        put(FieldKey.TRACK, edit.track)
                        audio.commit()
                        // a result that no longer opens like the song is never used: the song stays untouched
                        fileTagged = !(before > 0L && !playable(fresh, before))
                    } catch (e: SecurityException) {
                        throw e
                    } catch (e: Throwable) {
                        fileTagged = false
                    }
                }

                // 2) the edited copy replaces the song only when it was written and checked
                if (fileTagged) {
                    if (direct != null) {
                        direct.outputStream().use { o -> file.inputStream().use { i -> i.copyTo(o) } }
                    } else {
                        // copy the edited file back over the original
                        val out = resolver.openOutputStream(song.uri, "wt")
                            ?: return@withContext SaveResult.Error("Cannot open the file for writing")
                        out.use { o -> file.inputStream().use { i -> i.copyTo(o) } }
                    }
                }

                // 3) update MediaStore (the library), then let the scanner re-read the file
                val values = ContentValues()
                if (edit.title.isNotBlank()) values.put(MediaStore.Audio.Media.TITLE, edit.title.trim())
                if (edit.artist.isNotBlank()) values.put(MediaStore.Audio.Media.ARTIST, edit.artist.trim())
                if (edit.album.isNotBlank()) values.put(MediaStore.Audio.Media.ALBUM, edit.album.trim())
                edit.year.trim().toIntOrNull()?.let { values.put(MediaStore.Audio.Media.YEAR, it) }
                edit.track.trim().toIntOrNull()?.let { values.put(MediaStore.Audio.Media.TRACK, it) }
                if (fileTagged) {
                    try {
                        if (values.size() > 0) resolver.update(song.uri, values, null, null)
                    } catch (e: Exception) {
                    }
                    if (path != null) {
                        val done = CompletableDeferred<Unit>()
                        try {
                            MediaScannerConnection.scanFile(context, arrayOf(path), null) { _, _ ->
                                done.complete(Unit)
                            }
                            withTimeoutOrNull(3000) { done.await() }
                        } catch (e: Exception) {
                        }
                    }
                    SaveResult.Ok
                } else {
                    // the library is the only place left: a refused update (SecurityException) asks for permission
                    if (values.size() == 0) {
                        SaveResult.Error("The tags of this file cannot be written, and there is nothing to store in the library.")
                    } else {
                        resolver.update(song.uri, values, null, null)
                        SaveResult.OkLibraryOnly
                    }
                }
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    SaveResult.NeedsGrant(e.userAction.actionIntent.intentSender)
                } else if (Build.VERSION.SDK_INT < 29) {
                    SaveResult.NeedsStoragePermission
                } else {
                    SaveResult.Error("Android did not allow changing this file")
                }
            } catch (t: Throwable) {
                SaveResult.Error(t.message ?: "Could not write the tags to this file")
            } finally {
                temps.forEach { try { it.delete() } catch (_: Throwable) { } }
            }
        }
}
