package com.example.musicapp;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Small, dependency-free writer for the text tags + cover of .m4a / .mp4 audio files (iTunes "ilst" atoms).
 *
 * jaudiotagger is unreliable on many real-world m4a files (files from YouTube/SoundCloud, files written by
 * MediaMuxer, ...). This class only touches the "moov" atom: it replaces the metadata inside moov/udta/meta/ilst,
 * keeps everything else byte-for-byte, and fixes the chunk offsets (stco/co64) when moov sits in front of the audio.
 *
 * Fragmented files (DASH style: moof atoms) are refused with an IOException("fragmented"): those must be
 * re-packed first (MediaMuxer), then tagged.
 *
 * Keys of the text map (atom names without the leading (c) sign): nam, ART, alb, gen, day, trkn.
 * An empty value removes that tag. Only Java 7 / Android API 24 classes are used.
 */
public final class Mp4Tagger {
    private Mp4Tagger() { }

    private static final Charset UTF8 = Charset.forName("UTF-8");

    private static final class Box {
        final String type;
        final long start;   // offset of the box header in the source
        final long size;    // total size including the header
        final int header;   // 8 or 16
        Box(String type, long start, long size, int header) {
            this.type = type; this.start = start; this.size = size; this.header = header;
        }
        long end() { return start + size; }
    }

    // ───────────────────────────── detection ─────────────────────────────

    /** True when the file starts with an MP4 "ftyp" atom. */
    public static boolean isMp4(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            if (r.length() < 12) return false;
            byte[] b = new byte[8];
            r.readFully(b);
            return b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p';
        } catch (IOException e) {
            return false;
        }
    }

    /** True for DASH / CMAF style files (moof atoms, or an mvex atom inside moov) that tag libraries cannot edit. */
    public static boolean isFragmented(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            List<Box> top = readBoxes(r, 0, r.length());
            for (Box b : top) {
                if (b.type.equals("moof") || b.type.equals("sidx")) return true;
                if (b.type.equals("moov")) {
                    List<Box> kids = readBoxes(r, b.start + b.header, b.end());
                    for (Box k : kids) if (k.type.equals("mvex")) return true;
                }
            }
            return false;
        } catch (IOException e) {
            return false;
        }
    }

    // ───────────────────────────── writing ─────────────────────────────

    /**
     * Writes the tags into [file] (in place, through a temporary file next to it).
     *
     * @param text  atom name -> value ("nam","ART","alb","gen","day","trkn"); "" removes the tag; missing keys stay as they are
     * @param cover JPEG/PNG bytes of the cover, or null to keep the existing cover
     */
    public static void write(File file, Map<String, String> text, byte[] cover) throws IOException {
        File tmp = new File(file.getParentFile(), file.getName() + ".mp4tag");
        try {
            try (RandomAccessFile in = new RandomAccessFile(file, "r")) {
                long len = in.length();
                List<Box> top = readBoxes(in, 0, len);
                Box moov = null;
                Box firstMdat = null;
                for (Box b : top) {
                    if (b.type.equals("moof")) throw new IOException("fragmented");
                    if (b.type.equals("moov") && moov == null) moov = b;
                    if (b.type.equals("mdat") && firstMdat == null) firstMdat = b;
                }
                if (moov == null) throw new IOException("no moov atom");
                if (firstMdat == null) throw new IOException("no mdat atom");

                byte[] oldMoov = readRange(in, moov.start, moov.size);
                byte[] newMoov = rebuildMoov(oldMoov, moov.header, text, cover, moov.start, moov.end(), moov.start < firstMdat.start);

                try (OutputStream out = new java.io.BufferedOutputStream(new FileOutputStream(tmp), 1 << 16)) {
                    copyRange(in, 0, moov.start, out);
                    out.write(newMoov);
                    copyRange(in, moov.end(), len - moov.end(), out);
                }
            }
            replace(tmp, file);
        } finally {
            if (tmp.exists()) //noinspection ResultOfMethodCallIgnored
                tmp.delete();
        }
    }

    private static byte[] rebuildMoov(byte[] oldMoov, int oldHeader, Map<String, String> text, byte[] cover,
                                      long moovStart, long moovEnd, boolean moovBeforeData) throws IOException {
        // children of the old moov
        List<Box> kids = readBoxes(oldMoov, oldHeader, oldMoov.length);
        Box oldUdta = null;
        for (Box k : kids) if (k.type.equals("udta")) { oldUdta = k; break; }

        byte[] newUdta = buildUdta(oldMoov, oldUdta, text, cover);

        long oldUdtaSize = oldUdta == null ? 0 : oldUdta.size;
        long newTotal = oldMoov.length - oldUdtaSize + newUdta.length;
        long delta = newTotal - oldMoov.length;

        ByteArrayOutputStream body = new ByteArrayOutputStream(oldMoov.length + 4096);
        boolean placed = false;
        for (Box k : kids) {
            if (k == oldUdta) {
                body.write(newUdta);
                placed = true;
            } else if (k.type.equals("trak") && moovBeforeData && delta != 0) {
                byte[] trak = new byte[(int) k.size];
                System.arraycopy(oldMoov, (int) k.start, trak, 0, trak.length);
                adjustOffsets(trak, k.header, delta, moovEnd);
                body.write(trak);
            } else {
                body.write(oldMoov, (int) k.start, (int) k.size);
            }
        }
        if (!placed) body.write(newUdta);

        byte[] b = body.toByteArray();
        ByteArrayOutputStream res = new ByteArrayOutputStream(b.length + 8);
        writeInt(res, b.length + 8);
        res.write(new byte[]{'m', 'o', 'o', 'v'});
        res.write(b);
        return res.toByteArray();
    }

    /** Builds the whole new "udta" atom (keeping the old udta's other children and the old meta's other children). */
    private static byte[] buildUdta(byte[] moov, Box oldUdta, Map<String, String> text, byte[] cover) throws IOException {
        List<Box> udtaKids = new ArrayList<Box>();
        if (oldUdta != null) udtaKids = readBoxes(moov, (int) (oldUdta.start + oldUdta.header), (int) oldUdta.end());

        Box oldMeta = null;
        for (Box k : udtaKids) if (k.type.equals("meta")) { oldMeta = k; break; }

        byte[] newMeta = buildMeta(moov, oldMeta, text, cover);

        ByteArrayOutputStream body = new ByteArrayOutputStream();
        boolean placed = false;
        for (Box k : udtaKids) {
            if (k == oldMeta) {
                body.write(newMeta);
                placed = true;
            } else {
                body.write(moov, (int) k.start, (int) k.size);
            }
        }
        if (!placed) body.write(newMeta);

        byte[] b = body.toByteArray();
        ByteArrayOutputStream res = new ByteArrayOutputStream(b.length + 8);
        writeInt(res, b.length + 8);
        res.write(new byte[]{'u', 'd', 't', 'a'});
        res.write(b);
        return res.toByteArray();
    }

    private static byte[] buildMeta(byte[] moov, Box oldMeta, Map<String, String> text, byte[] cover) throws IOException {
        byte[] hdlr = null;
        byte[] oldIlst = null;
        List<byte[]> others = new ArrayList<byte[]>();
        List<Box> items = new ArrayList<Box>();
        byte[] src = moov;

        if (oldMeta != null) {
            int cs = (int) (oldMeta.start + oldMeta.header);
            int ce = (int) oldMeta.end();
            // normal "meta" is a full box (4 bytes version/flags); the old QuickTime one has the children right away
            int kidsStart = cs + 4;
            if (cs + 8 <= ce && moov[cs + 4] == 'h' && moov[cs + 5] == 'd' && moov[cs + 6] == 'l' && moov[cs + 7] == 'r') {
                kidsStart = cs; // QuickTime style
            }
            if (kidsStart <= ce) {
                for (Box k : readBoxes(moov, kidsStart, ce)) {
                    if (k.type.equals("hdlr")) {
                        hdlr = slice(moov, k);
                    } else if (k.type.equals("ilst")) {
                        oldIlst = slice(moov, k);
                        items = readBoxes(moov, (int) (k.start + k.header), (int) k.end());
                    } else if (k.type.equals("free") || k.type.equals("skip")) {
                        // padding is dropped
                    } else {
                        others.add(slice(moov, k));
                    }
                }
            }
        }
        if (hdlr == null) hdlr = newHdlr();

        // which existing items are replaced / removed
        List<String> drop = new ArrayList<String>();
        for (Map.Entry<String, String> e : text.entrySet()) {
            drop.add(atomType(e.getKey()));
            if (e.getKey().equals("gen")) drop.add("gnre");
        }
        if (cover != null) drop.add("covr");

        ByteArrayOutputStream ilstBody = new ByteArrayOutputStream();
        for (Box it : items) {
            if (drop.contains(it.type)) continue;
            ilstBody.write(src, (int) it.start, (int) it.size);
        }
        for (Map.Entry<String, String> e : text.entrySet()) {
            String v = e.getValue() == null ? "" : e.getValue().trim();
            if (v.isEmpty()) continue;
            byte[] item = e.getKey().equals("trkn") ? trackItem(v) : textItem(atomType(e.getKey()), v);
            if (item != null) ilstBody.write(item);
        }
        if (cover != null && cover.length > 0) {
            boolean png = cover.length > 4 && (cover[0] & 0xFF) == 0x89 && cover[1] == 'P' && cover[2] == 'N' && cover[3] == 'G';
            ilstBody.write(dataItem("covr", png ? 14 : 13, cover));
        }

        byte[] ilstB = ilstBody.toByteArray();
        ByteArrayOutputStream ilst = new ByteArrayOutputStream(ilstB.length + 8);
        writeInt(ilst, ilstB.length + 8);
        ilst.write(new byte[]{'i', 'l', 's', 't'});
        ilst.write(ilstB);

        ByteArrayOutputStream metaBody = new ByteArrayOutputStream();
        metaBody.write(new byte[]{0, 0, 0, 0}); // version + flags
        metaBody.write(hdlr);
        metaBody.write(ilst.toByteArray());
        for (byte[] o : others) metaBody.write(o);

        byte[] mb = metaBody.toByteArray();
        ByteArrayOutputStream meta = new ByteArrayOutputStream(mb.length + 8);
        writeInt(meta, mb.length + 8);
        meta.write(new byte[]{'m', 'e', 't', 'a'});
        meta.write(mb);
        return meta.toByteArray();
    }

    // ───────────────────────────── atoms ─────────────────────────────

    private static String atomType(String key) {
        if (key.equals("trkn")) return "trkn";
        return "\u00A9" + key; // nam -> (c)nam
    }

    private static byte[] typeBytes(String type) {
        byte[] t = new byte[4];
        for (int i = 0; i < 4; i++) t[i] = (byte) type.charAt(i); // chars are all <= 0xFF (Latin-1)
        return t;
    }

    private static byte[] newHdlr() throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        writeInt(b, 33);
        b.write(new byte[]{'h', 'd', 'l', 'r'});
        b.write(new byte[]{0, 0, 0, 0});                 // version + flags
        b.write(new byte[]{0, 0, 0, 0});                 // pre_defined
        b.write(new byte[]{'m', 'd', 'i', 'r'});         // handler type
        b.write(new byte[]{'a', 'p', 'p', 'l'});         // reserved (iTunes style)
        b.write(new byte[]{0, 0, 0, 0, 0, 0, 0, 0});     // reserved
        b.write(0);                                      // empty name
        return b.toByteArray();
    }

    private static byte[] textItem(String type, String value) throws IOException {
        return dataItem(type, 1, value.getBytes(UTF8));
    }

    private static byte[] trackItem(String value) throws IOException {
        String[] p = value.split("/");
        int n;
        int total = 0;
        try {
            n = Integer.parseInt(p[0].trim());
            if (p.length > 1) total = Integer.parseInt(p[1].trim());
        } catch (NumberFormatException e) {
            return null; // not a number: the tag is simply left out
        }
        if (n < 0 || n > 65535 || total < 0 || total > 65535) return null;
        byte[] d = new byte[]{0, 0, (byte) (n >> 8), (byte) n, (byte) (total >> 8), (byte) total, 0, 0};
        return dataItem("trkn", 0, d);
    }

    /** item atom: [size][type][ [size]['data'][0][type 3 bytes][locale 4 bytes][payload] ] */
    private static byte[] dataItem(String type, int dataType, byte[] payload) throws IOException {
        int dataSize = 16 + payload.length;
        ByteArrayOutputStream b = new ByteArrayOutputStream(dataSize + 8);
        writeInt(b, dataSize + 8);
        b.write(typeBytes(type));
        writeInt(b, dataSize);
        b.write(new byte[]{'d', 'a', 't', 'a'});
        b.write(0);
        b.write((dataType >> 16) & 0xFF);
        b.write((dataType >> 8) & 0xFF);
        b.write(dataType & 0xFF);
        writeInt(b, 0); // locale
        b.write(payload);
        return b.toByteArray();
    }

    // ───────────────────────────── chunk offsets ─────────────────────────────

    private static boolean isContainer(String t) {
        return t.equals("trak") || t.equals("mdia") || t.equals("minf") || t.equals("stbl") || t.equals("moov");
    }

    /** Adds [delta] to every stco / co64 entry that points behind the old moov atom. */
    private static void adjustOffsets(byte[] a, int headerOfThis, long delta, long oldMoovEnd) throws IOException {
        adjustIn(a, headerOfThis, a.length, delta, oldMoovEnd);
    }

    private static void adjustIn(byte[] a, int from, int to, long delta, long oldMoovEnd) throws IOException {
        for (Box k : readBoxes(a, from, to)) {
            if (k.type.equals("stco")) {
                int p = (int) k.start + k.header + 4;
                int count = readInt(a, p);
                p += 4;
                for (int i = 0; i < count; i++, p += 4) {
                    long v = readInt(a, p) & 0xFFFFFFFFL;
                    if (v >= oldMoovEnd) {
                        long nv = v + delta;
                        if (nv < 0 || nv > 0xFFFFFFFFL) throw new IOException("offset overflow");
                        a[p] = (byte) (nv >> 24); a[p + 1] = (byte) (nv >> 16); a[p + 2] = (byte) (nv >> 8); a[p + 3] = (byte) nv;
                    }
                }
            } else if (k.type.equals("co64")) {
                int p = (int) k.start + k.header + 4;
                int count = readInt(a, p);
                p += 4;
                for (int i = 0; i < count; i++, p += 8) {
                    long v = readLong(a, p);
                    if (v >= oldMoovEnd) {
                        long nv = v + delta;
                        for (int s = 0; s < 8; s++) a[p + s] = (byte) (nv >> (56 - 8 * s));
                    }
                }
            } else if (isContainer(k.type)) {
                adjustIn(a, (int) k.start + k.header, (int) k.end(), delta, oldMoovEnd);
            }
        }
    }

    // ───────────────────────────── low level ─────────────────────────────

    private static List<Box> readBoxes(RandomAccessFile r, long from, long to) throws IOException {
        List<Box> list = new ArrayList<Box>();
        long pos = from;
        byte[] h = new byte[16];
        while (pos + 8 <= to) {
            r.seek(pos);
            r.readFully(h, 0, 8);
            long size = readInt(h, 0) & 0xFFFFFFFFL;
            String type = new String(h, 4, 4, Charset.forName("ISO-8859-1"));
            int header = 8;
            if (size == 1) {
                if (pos + 16 > to) break;
                r.readFully(h, 8, 8);
                size = readLong(h, 8);
                header = 16;
            } else if (size == 0) {
                size = to - pos;
            }
            if (size < header || pos + size > to) {
                if (list.isEmpty()) throw new IOException("broken atom '" + type + "'");
                break;
            }
            list.add(new Box(type, pos, size, header));
            pos += size;
        }
        return list;
    }

    /** Boxes inside an in-memory range; offsets in the returned boxes are positions in [a]. */
    private static List<Box> readBoxes(byte[] a, int from, int to) throws IOException {
        List<Box> list = new ArrayList<Box>();
        int pos = from;
        while (pos + 8 <= to) {
            long size = readInt(a, pos) & 0xFFFFFFFFL;
            String type = new String(a, pos + 4, 4, Charset.forName("ISO-8859-1"));
            int header = 8;
            if (size == 1) {
                if (pos + 16 > to) break;
                size = readLong(a, pos + 8);
                header = 16;
            } else if (size == 0) {
                size = to - pos;
            }
            if (size < header || pos + size > to) break;
            list.add(new Box(type, pos, size, header));
            pos += (int) size;
        }
        return list;
    }

    private static byte[] slice(byte[] a, Box b) {
        byte[] r = new byte[(int) b.size];
        System.arraycopy(a, (int) b.start, r, 0, r.length);
        return r;
    }

    private static byte[] readRange(RandomAccessFile r, long start, long size) throws IOException {
        if (size > 64L * 1024 * 1024) throw new IOException("moov too big");
        byte[] b = new byte[(int) size];
        r.seek(start);
        r.readFully(b);
        return b;
    }

    private static void copyRange(RandomAccessFile in, long start, long count, OutputStream out) throws IOException {
        byte[] buf = new byte[1 << 16];
        in.seek(start);
        long left = count;
        while (left > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
            if (n < 0) throw new IOException("unexpected end of file");
            out.write(buf, 0, n);
            left -= n;
        }
    }

    private static void replace(File from, File to) throws IOException {
        if (to.delete() && from.renameTo(to)) return;
        if (from.renameTo(to)) return;
        // rename can fail on some file systems: copy instead
        try (InputStream i = new FileInputStream(from); OutputStream o = new FileOutputStream(to)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    private static int readInt(byte[] a, int p) {
        return ((a[p] & 0xFF) << 24) | ((a[p + 1] & 0xFF) << 16) | ((a[p + 2] & 0xFF) << 8) | (a[p + 3] & 0xFF);
    }

    private static long readLong(byte[] a, int p) {
        return ((long) (readInt(a, p)) << 32) | (readInt(a, p + 4) & 0xFFFFFFFFL);
    }

    private static void writeInt(ByteArrayOutputStream o, int v) {
        o.write(v >> 24); o.write(v >> 16); o.write(v >> 8); o.write(v);
    }
}
