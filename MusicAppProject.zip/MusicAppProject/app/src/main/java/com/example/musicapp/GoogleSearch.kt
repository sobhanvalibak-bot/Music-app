package com.example.musicapp

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// ───────────────────────── Online search through Google (SoundCloud + Spotify results) ─────────────────────────
//
// The song name is searched on Google twice ("… site:soundcloud.com" and "… site:open.spotify.com/track").
// Only the SoundCloud / Spotify track links found in the Google results are kept, and every one of them is shown as a
// row you tap to download (the download itself is the same as for pasted links: SoundCloud is downloaded directly,
// a Spotify song is matched to a SoundCloud / YouTube file by name and length first).
//
// Google no longer answers plain HTTP requests (its result pages need JavaScript), so the search runs in a hidden
// WebView. When Google refuses (captcha / cookie page / no answer) DuckDuckGo is tried the same way, and as the last
// step the app's own SoundCloud search, so there is always something to show. The line above the results says which
// one answered.

/** Index of the "Google" source in the Online tab (the other four are [OnlineSources]). */
const val GOOGLE_SOURCE = 4

fun onlineSourceLabel(i: Int): String = if (i == GOOGLE_SOURCE) "Google" else OnlineSources[i]

object GoogleMusicSearch {

    class Result(val songs: List<Song>, val note: String?)

    private class Hit(val url: String, val title: String)

    private class Found(val kind: Kind, val url: String, val title: String)

    private enum class Kind { SOUNDCLOUD, SPOTIFY }

    private const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val main = Handler(Looper.getMainLooper())

    // ───────────────────────── public entry ─────────────────────────

    /** Searches [query]; never throws for "Google did not answer" (it falls back), only for a cancelled coroutine. */
    suspend fun find(context: Context, query: String): Result = coroutineScope {
        val q = query.trim()
        val queries = listOf("$q site:soundcloud.com", "$q site:open.spotify.com/track")
        var note: String? = null

        // 1) Google, in a hidden WebView (both searches at the same time)
        var found = collect(
            queries.map { async { attempt { googleHits(context, it) } } }.awaitAll()
        )
        // 2) DuckDuckGo
        if (found.isEmpty()) {
            note = "Google did not answer, so these results come from DuckDuckGo."
            found = collect(queries.map { qq -> attempt { withContext(Dispatchers.IO) { duckHits(qq) } } })
        }
        // 3) the app's own SoundCloud search
        if (found.isEmpty()) {
            val own = try {
                withContext(Dispatchers.IO) { OnlineEngine.search(q, 2) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                emptyList()
            }
            return@coroutineScope Result(
                own.map { it.toSong() },
                if (own.isEmpty()) null else "Google and DuckDuckGo did not answer, so these are SoundCloud search results."
            )
        }

        // 4) read title / artist / length / cover of every link, a few at a time
        val gate = Semaphore(4)
        val songs = found.map { f ->
            async(Dispatchers.IO) { gate.withPermit { songOf(f) } }
        }.awaitAll().filterNotNull()

        // SoundCloud and Spotify results alternate, so both sources show near the top
        val sc = songs.filter { it.remoteId?.contains("soundcloud.com") == true }
        val sp = songs.filter { it.remoteId?.contains("spotify.com") == true }
        val mixed = ArrayList<Song>()
        for (i in 0 until maxOf(sc.size, sp.size)) {
            sc.getOrNull(i)?.let { mixed += it }
            sp.getOrNull(i)?.let { mixed += it }
        }
        Result(mixed.distinctBy { it.id }, note)
    }

    // ───────────────────────── helpers ─────────────────────────

    private suspend fun <T> attempt(block: suspend () -> T): kotlin.Result<T> =
        try {
            kotlin.Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            kotlin.Result.failure(e)
        }

    /** Keeps only SoundCloud / Spotify track links, de-duplicated, at most 8 of each. */
    private fun collect(lists: List<kotlin.Result<List<Hit>>>): List<Found> {
        val all = lists.flatMap { it.getOrNull().orEmpty() }
        val seen = HashSet<String>()
        val out = ArrayList<Found>()
        var sc = 0
        var sp = 0
        for (h in all) {
            val f = normalize(h) ?: continue
            if (!seen.add(f.url)) continue
            if (f.kind == Kind.SOUNDCLOUD) { if (sc++ >= 8) continue } else { if (sp++ >= 8) continue }
            out += f
        }
        return out
    }

    private val scRe = Regex("""^https?://(?:www\.|m\.)?soundcloud\.com/([^/?#]+)/([^/?#]+)/?(?:[?#].*)?$""", RegexOption.IGNORE_CASE)
    private val spRe = Regex("""^https?://open\.spotify\.com/(?:intl-[a-zA-Z-]+/)?track/([A-Za-z0-9]{22})""", RegexOption.IGNORE_CASE)
    private val scReserved = setOf(
        "sets", "tracks", "albums", "likes", "reposts", "popular-tracks", "following", "followers", "comments",
        "you", "discover", "search", "stream", "charts", "upload", "pages", "terms-of-use", "mobile", "feed", "people"
    )

    private fun normalize(h: Hit): Found? {
        val url = h.url.trim()
        spRe.find(url)?.let { return Found(Kind.SPOTIFY, "https://open.spotify.com/track/${it.groupValues[1]}", h.title) }
        scRe.find(url)?.let {
            val artist = it.groupValues[1]
            val track = it.groupValues[2]
            if (artist.lowercase() in scReserved || track.lowercase() in scReserved) return null
            return Found(Kind.SOUNDCLOUD, "https://soundcloud.com/$artist/$track", h.title)
        }
        return null
    }

    /** Link of a result row: Google wraps it as /url?q=REAL, DuckDuckGo as //duckduckgo.com/l/?uddg=REAL. */
    private fun unwrap(href: String): String {
        var h = href.trim().replace("&amp;", "&")
        if (h.startsWith("//")) h = "https:$h"
        try {
            val u = Uri.parse(h)
            val host = u.host.orEmpty()
            if (host.contains("duckduckgo.com")) u.getQueryParameter("uddg")?.let { return it }
            if (host.contains("google.") && (u.path == "/url")) {
                (u.getQueryParameter("q") ?: u.getQueryParameter("url"))?.let { return it }
            }
        } catch (_: Exception) {
        }
        return h
    }

    // ───────────────────────── a link → a Song ─────────────────────────

    private fun songOf(f: Found): Song? {
        try {
            if (f.kind == Kind.SOUNDCLOUD) {
                OnlineEngine.soundCloudList(f.url).second.firstOrNull()?.let { return it.toSong() }
            } else {
                OnlineEngine.spotifyList(f.url).items.firstOrNull()?.let { return it.toSong() }
            }
        } catch (e: Exception) {
            // the link could not be read right now: show it with what the search result said
        }
        val (title, artist) = splitTitle(f.title)
        if (title.isBlank()) return null
        return if (f.kind == Kind.SOUNDCLOUD) {
            OnlineTrack(f.url, title, artist, 0L, null).toSong()
        } else {
            SpotifyItem(f.url.substringAfterLast('/'), title, artist, 0L, null).toSong()
        }
    }

    /** "Song - song and lyrics by Artist | Spotify" / "Song by Artist | Free Listening on SoundCloud" → title, artist. */
    private fun splitTitle(raw: String): Pair<String, String> {
        var t = raw.replace('\u00a0', ' ').trim()
        Regex("""\s+-\s+song and lyrics by\s+(.+?)\s*\|.*$""", RegexOption.IGNORE_CASE).find(t)?.let {
            return t.substring(0, it.range.first).trim() to it.groupValues[1].trim()
        }
        t = t.replace(Regex("""\s*\|\s*(?:Free Listening on SoundCloud|Spotify|SoundCloud).*$""", RegexOption.IGNORE_CASE), "").trim()
        val by = t.lastIndexOf(" by ")
        if (by > 0) return t.substring(0, by).trim() to t.substring(by + 4).trim()
        return t to ""
    }

    // ───────────────────────── Google in a hidden WebView ─────────────────────────

    private const val PAGE_JS = """
        (function(){
          var out=[];
          var as=document.querySelectorAll('a[href]');
          for(var i=0;i<as.length;i++){
            var a=as[i], h=a.href||'';
            if(!h) continue;
            var t='';
            var h3=a.querySelector('h3');
            if(h3) t=h3.innerText; else t=(a.innerText||'');
            out.push([h,(t||'').substring(0,200)]);
          }
          return JSON.stringify({u:location.href,l:out});
        })()
    """

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun googleHits(context: Context, q: String): List<Hit> {
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8") + "&hl=en&num=20&pws=0"
        val app = context.applicationContext
        val result = withContext(Dispatchers.Main) {
            withTimeoutOrNull(18_000L) {
                suspendCancellableCoroutine<List<Hit>> { cont ->
                    val wv = WebView(app)
                    var done = false

                    fun finish(hits: List<Hit>?, error: Throwable?) {
                        if (done) return
                        done = true
                        main.removeCallbacksAndMessages(wv)
                        try { wv.stopLoading(); wv.destroy() } catch (_: Throwable) { }
                        if (!cont.isActive) return
                        if (error != null) cont.resumeWithException(error) else cont.resume(hits.orEmpty())
                    }

                    fun read(attemptNo: Int) {
                        if (done) return
                        wv.evaluateJavascript(PAGE_JS) { raw ->
                            if (done) return@evaluateJavascript
                            try {
                                val text = JSONTokener(raw ?: "null").nextValue() as? String ?: ""
                                val obj = JSONObject(text)
                                val page = obj.optString("u")
                                if (page.contains("/sorry/") || page.contains("consent.google") || page.contains("consent.youtube")) {
                                    finish(null, IOException("Google asked for a check"))
                                    return@evaluateJavascript
                                }
                                val links: JSONArray = obj.optJSONArray("l") ?: JSONArray()
                                val hits = ArrayList<Hit>()
                                for (i in 0 until links.length()) {
                                    val row = links.optJSONArray(i) ?: continue
                                    val real = unwrap(row.optString(0))
                                    if (real.contains("soundcloud.com") || real.contains("open.spotify.com")) {
                                        hits += Hit(real, row.optString(1))
                                    }
                                }
                                if (hits.isNotEmpty() || attemptNo >= 7) finish(hits, null)
                                else main.postAtTime({ read(attemptNo + 1) }, wv, android.os.SystemClock.uptimeMillis() + 700L)
                            } catch (e: Throwable) {
                                if (attemptNo >= 7) finish(null, e)
                                else main.postAtTime({ read(attemptNo + 1) }, wv, android.os.SystemClock.uptimeMillis() + 700L)
                            }
                        }
                    }

                    wv.settings.javaScriptEnabled = true
                    wv.settings.domStorageEnabled = true
                    wv.settings.blockNetworkImage = true
                    wv.settings.userAgentString = MOBILE_UA
                    try {
                        CookieManager.getInstance().setCookie("https://www.google.com", "CONSENT=YES+cb; path=/")
                    } catch (_: Throwable) {
                    }
                    wv.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, u: String?) {
                            // Google fills the results in right after the page loaded: look a few times
                            main.postAtTime({ read(0) }, wv, android.os.SystemClock.uptimeMillis() + 500L)
                        }

                        override fun onReceivedError(
                            view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?
                        ) {
                            if (request?.isForMainFrame == true) finish(null, IOException("Google could not be reached"))
                        }
                    }
                    cont.invokeOnCancellation { main.post { try { wv.stopLoading(); wv.destroy() } catch (_: Throwable) { } } }
                    wv.loadUrl(url)
                }
            }
        }
        return result ?: throw IOException("Google did not answer in time")
    }

    // ───────────────────────── DuckDuckGo (plain HTTP) ─────────────────────────

    private fun duckHits(q: String): List<Hit> {
        val req = Request.Builder()
            .url("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
            .header("User-Agent", OnlineEngine.USER_AGENT)
            .header("Accept-Language", "en")
            .build()
        val html = client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            r.body?.string().orEmpty()
        }
        val re = Regex("""<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        return re.findAll(html).map {
            val title = android.text.Html.fromHtml(it.groupValues[2], android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
            Hit(unwrap(it.groupValues[1]), title)
        }.toList()
    }
}
