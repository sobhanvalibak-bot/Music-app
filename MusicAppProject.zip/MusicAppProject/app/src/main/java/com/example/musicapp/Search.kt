package com.example.musicapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ───────────────────────── Search ─────────────────────────

/** Songs whose title, artist or album contains [query]. Title matches that start with it come first. */
fun searchSongs(songs: List<Song>, query: String): List<Song> {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return emptyList()
    return songs
        .filter {
            it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q)
        }
        .sortedBy { if (it.title.lowercase().startsWith(q)) 0 else 1 }
}

/** filter: 0 = everything, 1 = titles, 2 = artists, 3 = albums. */
fun searchSongsBy(songs: List<Song>, query: String, filter: Int): List<Song> {
    if (filter == 0) return searchSongs(songs, query)
    val q = query.trim().lowercase()
    if (q.isEmpty()) return emptyList()
    return songs
        .filter {
            when (filter) {
                1 -> it.title.lowercase().contains(q)
                2 -> it.artist.lowercase().contains(q)
                else -> it.album.lowercase().contains(q)
            }
        }
        .sortedBy {
            val field = when (filter) { 1 -> it.title; 2 -> it.artist; else -> it.album }.lowercase()
            if (field.startsWith(q)) 0 else 1
        }
}

private const val RECENT_PREFS = "search_history"

fun loadRecentSearches(context: android.content.Context): List<String> =
    context.getSharedPreferences(RECENT_PREFS, android.content.Context.MODE_PRIVATE)
        .getString("items", "").orEmpty()
        .split('\n').filter { it.isNotBlank() }

fun saveRecentSearch(context: android.content.Context, query: String): List<String> {
    val q = query.trim()
    if (q.length < 2) return loadRecentSearches(context)
    val list = (listOf(q) + loadRecentSearches(context).filter { !it.equals(q, ignoreCase = true) }).take(8)
    context.getSharedPreferences(RECENT_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().putString("items", list.joinToString("\n")).apply()
    return list
}

fun clearRecentSearches(context: android.content.Context) {
    context.getSharedPreferences(RECENT_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().remove("items").apply()
}

@Composable
fun SearchScreen(
    songs: List<Song>,
    current: Song?,
    favSet: Set<Long>,
    p: Palette,
    showDuration: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    topPad: Dp,
    bottomPad: Dp,
    onClose: () -> Unit,
    /** Plays just this song with the video (online songs only). */
    onPlay: (Song, Boolean) -> Unit,
    /** Tap on a result: plays it and queues the whole result list it came from, so next / shuffle / repeat stay inside it. */
    onPlayList: (List<Song>, Int) -> Unit = { _, _ -> },
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onEditInfo: (Song) -> Unit,
    onToggleFav: (Song) -> Unit,
    onLong: (Song) -> Unit
) {
    val context = LocalContext.current
    var filter by remember { mutableIntStateOf(0) }
    var source by remember { mutableIntStateOf(0) }
    var recents by remember { mutableStateOf(loadRecentSearches(context)) }
    val results = remember(query, songs, filter) { searchSongsBy(songs, query, filter) }
    // The songs on this device come first. When nothing on the phone matches, the search goes online by itself
    // (a download then takes its info and cover from iTunes). The link below the results does the same by hand.
    var forceOnline by remember { mutableStateOf(false) }
    LaunchedEffect(query) { forceOnline = false }
    val isLink = OnlineEngine.isSpotifyLink(query) || OnlineEngine.isSoundCloudLink(query)
    val online = !isLink && query.trim().length >= 2 && (forceOnline || results.isEmpty())
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current

    // ── online search (YouTube): runs a moment after you stop typing, or at once on the keyboard's search key ──
    var onlineResults by remember { mutableStateOf<List<OnlineTrack>>(emptyList()) }
    var onlineLoading by remember { mutableStateOf(false) }
    var onlineError by remember { mutableStateOf<String?>(null) }
    var submitTick by remember { mutableIntStateOf(0) }
    // set when the text in the box is a Spotify link: what that link is (title and artist)
    var spotifyLabel by remember { mutableStateOf<String?>(null) }
    val handledTick = remember { intArrayOf(0) }
    LaunchedEffect(online, source, query, submitTick) {
        if (!online) return@LaunchedEffect
        val q = query.trim()
        if (q.length < 2) {
            onlineResults = emptyList()
            onlineError = null
            onlineLoading = false
            return@LaunchedEffect
        }
        val spotifyId = OnlineEngine.spotifyTrackId(q)
        if (spotifyId == null && submitTick == handledTick[0]) delay(700) else handledTick[0] = submitTick
        onlineLoading = true
        onlineError = null
        try {
            onlineResults = withContext(Dispatchers.IO) {
                if (spotifyId != null) {
                    // Spotify link: find the song by its name and artist in the chosen source
                    val (title, artist) = OnlineEngine.spotifyInfo(spotifyId)
                    spotifyLabel = if (artist.isBlank()) title else "$title — $artist"
                    OnlineEngine.search("$artist $title".trim(), source)
                } else {
                    spotifyLabel = null
                    OnlineEngine.search(q, source)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            onlineResults = emptyList()
            onlineError = if (spotifyId != null) "Could not read this Spotify link. Check your internet connection."
            else "Online search failed. Check your internet connection."
        }
        onlineLoading = false
    }

    // ── Spotify link in the search box: show the songs inside it, tap one to download it ──
    val isSpotify = OnlineEngine.isSpotifyLink(query)
    var spotify by remember { mutableStateOf<SpotifyList?>(null) }
    var spotifyLoading by remember { mutableStateOf(false) }
    var spotifyError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(query) {
        if (!OnlineEngine.isSpotifyLink(query)) {
            spotify = null
            spotifyError = null
            spotifyLoading = false
            return@LaunchedEffect
        }
        delay(400) // let a paste settle
        spotifyLoading = true
        spotifyError = null
        spotify = null
        try {
            spotify = withContext(Dispatchers.IO) { OnlineEngine.spotifyList(query.trim()) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            spotifyError = "Could not read this Spotify link. Check the link and your internet connection."
        }
        spotifyLoading = false
    }

    // ── SoundCloud link in the search box: a track or a playlist, tap a song to download it ──
    val isSoundCloud = OnlineEngine.isSoundCloudLink(query) && !isSpotify
    var soundCloud by remember { mutableStateOf<Pair<String, List<OnlineTrack>>?>(null) }
    var soundCloudLoading by remember { mutableStateOf(false) }
    var soundCloudError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(query) {
        if (!OnlineEngine.isSoundCloudLink(query) || OnlineEngine.isSpotifyLink(query)) {
            soundCloud = null
            soundCloudError = null
            soundCloudLoading = false
            return@LaunchedEffect
        }
        delay(400) // let a paste settle
        soundCloudLoading = true
        soundCloudError = null
        soundCloud = null
        try {
            soundCloud = withContext(Dispatchers.IO) { OnlineEngine.soundCloudList(query.trim()) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            soundCloudError = e.message?.takeIf { it.isNotBlank() }
                ?: "Could not read this SoundCloud link. Check the link and your internet connection."
        }
        soundCloudLoading = false
    }

    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (e: Exception) {
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(p.bgBrush)
            .pointerInput(Unit) { detectTapGestures { } } // keep touches from reaching the page below
            .imePadding()
    ) {
        Spacer(Modifier.height(topPad))
        Text(
            "Search", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = p.text,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.selectedPill)
                    .padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlyphIcon(Glyph.Search, p.secondary, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = p.text, fontSize = 17.sp),
                    cursorBrush = SolidColor(p.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        recents = saveRecentSearch(context, query)
                        if (online) submitTick++
                        focusManager.clearFocus()
                    }),
                    modifier = Modifier.weight(1f).focusRequester(focusRequester),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) {
                                Text(
                                    if (online) "Search online or paste a Spotify link" else "Songs, artists, albums or a link (online if not found)",
                                    color = p.secondary, fontSize = 17.sp
                                )
                            }
                            inner()
                        }
                    }
                )
                if (query.isNotEmpty()) {
                    Box(
                        Modifier.size(22.dp).clip(CircleShape).clickable { onQuery("") },
                        contentAlignment = Alignment.Center
                    ) { GlyphIcon(Glyph.Close, p.secondary, Modifier.size(14.dp)) }
                }
            }
            Text(
                "Cancel", color = p.accent, fontSize = 16.sp,
                modifier = Modifier
                    .padding(start = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        keyboard?.hide()
                        focusManager.clearFocus()
                        onClose()
                    }
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            )
        }

        if (!online && !isSpotify && !isSoundCloud) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Songs", "Artists", "Albums").forEachIndexed { i, label ->
                    OptionPill(label, filter == i, p) { filter = i }
                }
            }
        } else if (online) {
            // where to search online: YouTube, YT Music, SoundCloud, Bandcamp
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OnlineSources.forEachIndexed { i, label ->
                    OptionPill(label, source == i, p) { source = i }
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(top = 6.dp, bottom = bottomPad)
        ) {
            when {
                query.isBlank() -> {
                    if (recents.isEmpty()) {
                        item {
                            Text(
                                if (online) "Pick a source (YouTube, YT Music, SoundCloud, Bandcamp) and search."
                                else "Search your songs, artists and albums.",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                    } else {
                        item {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Recent searches", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = p.text, modifier = Modifier.weight(1f))
                                Text(
                                    "Clear", fontSize = 14.sp, color = p.accent,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { clearRecentSearches(context); recents = emptyList() }
                                        .padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                        items(recents.size) { i ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onQuery(recents[i]) }
                                    .padding(horizontal = 20.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                GlyphIcon(Glyph.Search, p.secondary, Modifier.size(16.dp))
                                Spacer(Modifier.width(12.dp))
                                Text(recents[i], fontSize = 16.sp, color = p.text, maxLines = 1)
                            }
                        }
                    }
                }

                isSoundCloud -> {
                    val sc = soundCloud
                    when {
                        soundCloudLoading -> item {
                            Text(
                                "Reading the SoundCloud link…",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        soundCloudError != null -> item {
                            Text(
                                soundCloudError.orEmpty(),
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        sc == null || sc.second.isEmpty() -> item {
                            Text(
                                "No songs found in this link.",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        else -> {
                            item {
                                Text(
                                    (if (sc.first.isNotBlank() && sc.second.size > 1) "${sc.first}\n" else "") +
                                        "${sc.second.size} ${if (sc.second.size == 1) "song" else "songs"} · tap a song to download it",
                                    fontSize = 13.sp, color = p.secondary,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                                )
                            }
                            itemsIndexed(sc.second, key = { i, t -> "$i-${t.url}" }) { _, track ->
                                val song = remember(track.url) { track.toSong() }
                                DownloadRow(song, p, showDuration) { OnlineDownloader.start(context, it) }
                            }
                        }
                    }
                }

                isSpotify -> {
                    val list = spotify
                    when {
                        spotifyLoading -> item {
                            Text(
                                "Reading the Spotify link…",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        spotifyError != null -> item {
                            Text(
                                spotifyError.orEmpty(),
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        list == null || list.items.isEmpty() -> item {
                            Text(
                                "No songs found in this link.",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        else -> {
                            item {
                                Text(
                                    (if (list.label.isNotBlank()) "${list.label}\n" else "") +
                                        "${list.items.size} songs · tap a song to download it",
                                    fontSize = 13.sp, color = p.secondary,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                                )
                            }
                            itemsIndexed(list.items, key = { i, t -> "$i-${t.id}" }) { _, track ->
                                SpotifyRow(track, p, showDuration) { OnlineDownloader.start(context, it) }
                            }
                        }
                    }
                }

                online -> {
                    if (results.isNotEmpty()) item {
                        Text(
                            "\u2190 Show the ${results.size} ${if (results.size == 1) "song" else "songs"} on this device",
                            Modifier
                                .padding(horizontal = 20.dp, vertical = 8.dp)
                                .clip(RoundedCornerShape(50))
                                .clickable { forceOnline = false }
                                .padding(horizontal = 4.dp, vertical = 4.dp),
                            color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                    when {
                        onlineLoading && onlineResults.isEmpty() -> item {
                            Text(
                                "Searching online…",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        onlineError != null -> item {
                            Text(
                                onlineError.orEmpty(),
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        onlineResults.isEmpty() -> item {
                            Text(
                                if (query.trim().length < 2) "Type at least 2 letters."
                                else "No online results for \"${query.trim()}\"",
                                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                                color = p.secondary, fontSize = 15.sp
                            )
                        }
                        else -> {
                            item {
                                Text(
                                    (spotifyLabel?.let { "Spotify: $it\n" } ?: "") +
                                        "${onlineResults.size} results from ${OnlineSources[source]} · tap to listen",
                                    fontSize = 13.sp, color = p.secondary,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                                )
                            }
                            itemsIndexed(onlineResults, key = { _, t -> t.url }) { idx, track ->
                                val song = remember(track.url) { track.toSong() }
                                SongRow(
                                    song = song,
                                    playing = current?.id == song.id,
                                    p = p,
                                    showDuration = showDuration,
                                    fav = favSet.contains(song.id),
                                    onClick = {
                                        recents = saveRecentSearch(context, query)
                                        focusManager.clearFocus()
                                        onPlayList(onlineResults.map { it.toSong() }, idx)
                                    },
                                    onFav = { onToggleFav(song) },
                                    onLong = { onLong(song) },
                                    onPlayNext = { onPlayNext(song) },
                                    onAddToQueue = { onAddToQueue(song) },
                                    onDownload = { OnlineDownloader.start(context, song) },
                                    onWatch = if (!song.canWatch) null else ({
                                        recents = saveRecentSearch(context, query)
                                        focusManager.clearFocus()
                                        onPlay(song, true)
                                    })
                                )
                            }
                        }
                    }
                }

                results.isEmpty() -> {
                    item {
                        Text(
                            "No results for \"${query.trim()}\"",
                            Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                            color = p.secondary, fontSize = 15.sp
                        )
                    }
                }

                else -> {
                    item {
                        Text(
                            "${results.size} songs", fontSize = 13.sp, color = p.secondary,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                        )
                    }
                    itemsIndexed(results, key = { _, s -> s.id }) { idx, song ->
                        SongRow(
                            song = song,
                            playing = current?.id == song.id,
                            p = p,
                            showDuration = showDuration,
                            fav = favSet.contains(song.id),
                            onClick = {
                                recents = saveRecentSearch(context, query)
                                focusManager.clearFocus()
                                onPlayList(results, idx)
                            },
                            onFav = { onToggleFav(song) },
                            onLong = { onLong(song) },
                            onPlayNext = { onPlayNext(song) },
                            onAddToQueue = { onAddToQueue(song) },
                            onEditInfo = { onEditInfo(song) }
                        )
                    }
                    if (query.trim().length >= 2) item {
                        Text(
                            "Not here? Search online for \"${query.trim()}\"",
                            Modifier
                                .padding(horizontal = 20.dp, vertical = 14.dp)
                                .clip(RoundedCornerShape(50))
                                .clickable { focusManager.clearFocus(); forceOnline = true }
                                .padding(horizontal = 4.dp, vertical = 4.dp),
                            color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

/**
 * One song of a Spotify link. Tap = download. On the right: the download icon, then the percentage
 * while it downloads, then a check mark and "Done" once it is saved.
 */
@Composable
private fun SpotifyRow(track: SpotifyItem, p: Palette, showDuration: Boolean, onDownload: (Song) -> Unit) {
    val song = remember(track.id) { track.toSong() }
    DownloadRow(song, p, showDuration, onDownload)
}

/** The same row for every link (Spotify, SoundCloud): tap = download, percentage while it runs, "Done" when saved. */
@Composable
private fun DownloadRow(
    song: Song,
    p: Palette,
    showDuration: Boolean,
    onDownload: (Song) -> Unit
) {
    val dl = OnlineDownloader.progress[song.id]
    val err = OnlineDownloader.errors[song.id]
    val stage = OnlineDownloader.stage[song.id]
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val ctx = LocalContext.current
    // tapping a song that is downloading opens its live info; it closes when the song is done
    var infoOpen by remember(song.id) { mutableStateOf(false) }
    val busy = dl != null && dl < 1f
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable {
                    if (busy) infoOpen = !infoOpen else onDownload(song)
                }
                .padding(start = 20.dp, end = 12.dp, top = 7.dp, bottom = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Cover(song, Modifier.size(56.dp), 10.dp, p, 300)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp, fontWeight = FontWeight.Medium, color = p.text
                )
                Text(
                    song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp, color = p.secondary
                )
            }
            if (showDuration && song.durationMs > 0L) {
                Spacer(Modifier.width(8.dp))
                Text(formatTime(song.durationMs), fontSize = 13.sp, color = p.secondary)
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.width(52.dp), contentAlignment = Alignment.Center) {
                when {
                    dl == null -> GlyphIcon(Glyph.Download, p.secondary, Modifier.size(22.dp))
                    dl >= 1f -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("\u2713", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = p.accent)
                        Text("Done", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = p.accent)
                    }
                    else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            progress = { dl.coerceAtLeast(0.04f) },
                            modifier = Modifier.size(20.dp),
                            color = p.accent,
                            strokeWidth = 2.5.dp
                        )
                        Text("${(dl * 100).toInt()}%", fontSize = 11.sp, color = p.secondary)
                    }
                }
            }
        }

        // live info of the running download (read again from the state every time it changes)
        if (busy && infoOpen) {
            androidx.compose.foundation.text.selection.SelectionContainer {
                Text(
                    "${song.artist} - ${song.title}\n" +
                        "Step: ${stage ?: "Starting"}\n" +
                        "Progress: ${((dl ?: 0f) * 100).toInt()}%",
                    Modifier.padding(start = 90.dp, end = 20.dp, bottom = 8.dp),
                    fontSize = 12.sp, color = p.secondary
                )
            }
        }

        // the error stays here (not a toast that disappears): select it, or press Copy
        if (err != null && !busy) {
            androidx.compose.foundation.text.selection.SelectionContainer {
                Text(
                    err,
                    Modifier.padding(start = 90.dp, end = 20.dp, top = 2.dp),
                    fontSize = 12.sp, color = p.accent
                )
            }
            Row(Modifier.padding(start = 90.dp, end = 20.dp, top = 4.dp, bottom = 8.dp)) {
                Text(
                    "Copy",
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(p.accent.copy(alpha = 0.16f))
                        .clickable {
                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(err))
                            android.widget.Toast.makeText(ctx, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = p.accent
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Try again",
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(p.accent.copy(alpha = 0.16f))
                        .clickable { onDownload(song) }
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = p.accent
                )
            }
        }
    }
}
