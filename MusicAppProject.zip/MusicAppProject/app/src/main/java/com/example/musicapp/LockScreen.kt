package com.example.musicapp

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import android.media.AudioManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.MediaStore
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.border
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "Live lock screen" in the style of the system music lock screen. While music plays and you wake a
 * locked phone this opens above the lock screen:
 *  - clock and date on top, a big rounded cover (it shrinks a little while paused) and a glass card
 *    under it with title, artist, seek bar and favorite / previous / play / next / lyrics buttons;
 *  - the background is the cover, blurred, in the cover's colour;
 *  - round flashlight and camera buttons at the bottom;
 *  - the quote button shows the synced lyrics: the cover moves up small next to the title;
 *  - swipe up (or tap the bar) to unlock; the app then opens on its full player.
 * Settings > Live lock screen turns it on. It needs "Display over other apps" so Android lets the app
 * open a screen from the background.
 */
class LockScreenActivity : ComponentActivity() {
    private val closer = object : BroadcastReceiver() {
        // unlocked, or the screen went off again: nothing more to show
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this, closer,
            IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_SCREEN_OFF)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        setContent { LockPlayer(onUnlock = { unlock() }) }
    }

    /** Swipe up: ask Android to unlock, then land on the app's full player. */
    private fun unlock() {
        val open = Intent(this, MainActivity::class.java).apply {
            action = ACTION_OPEN_PLAYER
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    startActivity(open)
                    finish()
                }
            })
        } else {
            startActivity(open)
            finish()
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (_: Exception) { }
        super.onDestroy()
    }
}

/** Lives in PlaybackService: when the screen turns on while locked and music plays, open the lock player. */
class ScreenOnReceiver(
    private val player: () -> Player?,
    private val enabled: () -> Boolean
) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!enabled()) return
        if (player()?.isPlaying != true) return
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) return
        if (!android.provider.Settings.canDrawOverlays(context)) return
        try {
            context.startActivity(
                Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (_: Exception) { }
    }
}

private enum class CoverSlot { Big, Small }

@Composable
private fun LockPlayer(onUnlock: () -> Unit) {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) { controller = null }
        }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future); controller = null }
    }

    // what is playing, refreshed four times a second
    var item by remember { mutableStateOf<MediaItem?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(controller) {
        val c = controller ?: return@LaunchedEffect
        while (true) {
            item = c.currentMediaItem
            playing = c.isPlaying
            pos = c.currentPosition
            dur = c.duration.coerceAtLeast(0L)
            delay(250)
        }
    }

    val mediaId = item?.mediaId.orEmpty()
    val meta = item?.mediaMetadata
    val title = meta?.title?.toString().orEmpty()
    val artist = meta?.artist?.toString().orEmpty()

    // cover (embedded picture / album art) and its average colour
    val cover by produceState<Bitmap?>(null, mediaId) {
        val it2 = item ?: return@produceState
        value = withContext(Dispatchers.IO) {
            try {
                MusicWidget.loadCover(context.applicationContext, it2.mediaId, it2.localConfiguration?.uri, it2.mediaMetadata.artworkUri)
            } catch (_: Exception) { null }
        }
    }
    val tint = remember(cover) {
        cover?.let {
            val px = Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0)
            Color(px)
        } ?: Color(0xFF3A3A3C)
    }
    val top = androidx.compose.ui.graphics.lerp(tint, Color.Black, 0.35f)
    val bottom = androidx.compose.ui.graphics.lerp(tint, Color.Black, 0.65f)

    // the song itself (needed to look up lyrics): found by id in the device library
    val songs by produceState<Map<Long, Song>>(emptyMap()) {
        value = withContext(Dispatchers.IO) {
            OnlineRegistry.init(context.applicationContext)
            try { loadSongs(context).associateBy { it.id } } catch (_: Exception) { emptyMap() }
        }
    }
    val song = mediaId.toLongOrNull()?.let { songs[it] ?: OnlineRegistry.get(it) }
    val lines by produceState<List<LrcLine>>(emptyList(), song?.id) {
        val s = song
        value = if (s == null) emptyList() else try {
            val online = context.getSharedPreferences("settings", 0).getBoolean("auto_lyrics", true)
            LyricsRepo.get(context, s, online)
        } catch (_: Exception) { emptyList() }
    }
    val synced = lines.isNotEmpty() && lines.first().timeMs >= 0L
    val cur = if (synced) lines.indexOfLast { it.timeMs <= pos } else -1

    // favorites (same store the app uses, read again whenever the song changes)
    val profile = remember { ProfileStore(context.applicationContext) }
    var isFav by remember { mutableStateOf(false) }
    LaunchedEffect(mediaId) {
        isFav = mediaId.toLongOrNull()?.let { profile.favorites.contains(it) } ?: false
    }

    val is24 = remember { android.text.format.DateFormat.is24HourFormat(context) }
    val clock by produceState("") {
        val fmt = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(1000) }
    }
    val dateText = remember { SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date()) }

    // flashlight
    val cam = remember { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    val torchId = remember {
        try {
            cam.cameraIdList.firstOrNull {
                val ch = cam.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) { null }
    }
    var torchOn by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                if (cameraId == torchId) torchOn = enabled
            }
        }
        try { cam.registerTorchCallback(cb, null) } catch (_: Exception) { }
        onDispose { try { cam.unregisterTorchCallback(cb) } catch (_: Exception) { } }
    }

    var lyricsOn by remember { mutableStateOf(false) }
    var scrub by remember { mutableStateOf<Float?>(null) }
    BackHandler(enabled = lyricsOn) { lyricsOn = false }

    // the cover shrinks a little while the song is paused (like the system lock screen player)
    val coverScale by animateFloatAsState(
        if (!lyricsOn && !playing) 0.86f else 1f,
        spring(dampingRatio = 0.6f, stiffness = 300f), label = "lockCover"
    )

    var dragY by remember { mutableFloatStateOf(0f) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { dragY = 0f },
                    onDragEnd = {
                        if (dragY < -160f) onUnlock()
                        dragY = 0f
                    },
                    onDragCancel = { dragY = 0f },
                    onVerticalDrag = { _, d -> dragY += d }
                )
            }
    ) {
        // the cover, blurred, as the background (real blur needs Android 12+)
        val bmp = cover
        if (Build.VERSION.SDK_INT >= 31 && bmp != null) {
            Image(
                bmp.asImageBitmap(), null,
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = 1.5f; scaleY = 1.5f }
                    .blur(60.dp, BlurredEdgeTreatment.Unbounded),
                contentScale = ContentScale.Crop
            )
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.22f)))

        BoxWithConstraints(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            val side = 19.dp
            val buttonsH = 60.dp
            val buttonsBottom = 34.dp
            val cardH = 156.dp
            val cardBottom = buttonsBottom + buttonsH + 18.dp
            val cardTop = maxHeight - cardBottom - cardH
            val headerH = 110.dp
            val avail = (cardTop - 18.dp - headerH).coerceAtLeast(120.dp)
            val bigSize = minOf(maxWidth - side * 2, avail)
            val slot = if (lyricsOn) CoverSlot.Small else CoverSlot.Big
            val spec = spring<Dp>(dampingRatio = 0.8f, stiffness = 260f)
            val cx by animateDpAsState(if (slot == CoverSlot.Big) (maxWidth - bigSize) / 2 else side, spec, label = "coverX")
            val cy by animateDpAsState(if (slot == CoverSlot.Big) headerH + (avail - bigSize) / 2 else 18.dp, spec, label = "coverY")
            val cs by animateDpAsState(if (slot == CoverSlot.Big) bigSize else 52.dp, spec, label = "coverSize")
            val cr by animateDpAsState(if (slot == CoverSlot.Big) 30.dp else 9.dp, spec, label = "coverCorner")
            val elev by animateDpAsState(if (slot == CoverSlot.Big) 26.dp else 0.dp, tween(500), label = "coverShadow")

            // 1) clock and date on top
            AnimatedVisibility(visible = !lyricsOn, enter = fadeIn(tween(300)), exit = fadeOut(tween(200))) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 36.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(clock, color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.width(14.dp))
                    Text(
                        dateText, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
            }

            // 2) lyrics (replace the big cover; the cover goes up to the left, small)
            AnimatedVisibility(visible = lyricsOn, enter = fadeIn(tween(350)), exit = fadeOut(tween(200))) {
                Column(Modifier.fillMaxSize().padding(horizontal = side + 5.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp).height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.width(52.dp + 12.dp))
                        Column {
                            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(artist, color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (lines.isEmpty()) {
                            Text(
                                "No lyrics for this song", color = Color.White.copy(alpha = 0.5f), fontSize = 18.sp,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            val state = rememberLazyListState()
                            LaunchedEffect(cur) { if (cur >= 0) state.animateScrollToItem((cur - 1).coerceAtLeast(0)) }
                            LazyColumn(
                                state = state, modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(bottom = 60.dp)
                            ) {
                                itemsIndexed(lines) { i, l ->
                                    val dist = if (!synced) 0 else kotlin.math.abs(i - cur)
                                    val a by animateFloatAsState(
                                        if (!synced) 0.85f else if (dist == 0) 1f else 0.32f, tween(350), label = "lyricAlpha"
                                    )
                                    val b by animateDpAsState(
                                        if (dist <= 1) 0.dp else (dist - 1).coerceAtMost(3).dp, tween(350), label = "lyricBlur"
                                    )
                                    Text(
                                        l.text.ifBlank { "♪" },
                                        color = Color.White.copy(alpha = a),
                                        fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Start,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp)
                                            .then(if (b > 0.dp) Modifier.blur(b) else Modifier)
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(cardBottom + cardH + 8.dp))
                }
            }

            // 3) the cover
            Box(
                Modifier
                    .offset(cx, cy)
                    .size(cs)
                    .graphicsLayer { scaleX = coverScale; scaleY = coverScale }
                    .shadow(elev, RoundedCornerShape(cr), ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(RoundedCornerShape(cr))
                    .background(Color.White.copy(alpha = 0.10f))
                    .clickable { lyricsOn = false },
                contentAlignment = Alignment.Center
            ) {
                if (bmp != null) {
                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    GlyphIcon(Glyph.Note, Color.White.copy(alpha = 0.85f), Modifier.size(cs * 0.4f))
                }
            }

            // 4) the glass card: title, artist, seek bar, controls
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp)
                    .padding(bottom = cardBottom)
                    .fillMaxWidth()
                    .height(cardH)
                    .clip(RoundedCornerShape(36.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(36.dp))
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Box(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(artist, color = Color.White.copy(alpha = 0.6f), fontSize = 21.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    EqBars(playing, Modifier.align(Alignment.TopEnd).padding(top = 4.dp))
                }
                Spacer(Modifier.height(4.dp))

                // elapsed - bar - remaining
                val frac = scrub ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
                val shownPos = if (scrub != null) (frac * dur).toLong() else pos
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(formatTime(shownPos), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                    LockSlider(
                        frac,
                        onChange = { scrub = it },
                        onDone = {
                            scrub?.let { f -> if (dur > 0) controller?.seekTo((f * dur).toLong()) }
                            scrub = null
                        },
                        modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                    )
                    Text("-" + formatTime((dur - shownPos).coerceAtLeast(0L)), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                }

                // favorite - prev - play - next - lyrics
                Row(
                    Modifier.fillMaxWidth().weight(1f),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlainGlyphButton(if (isFav) Glyph.Heart else Glyph.HeartOutline, 44.dp, 24.dp, if (isFav) Color(0xFFFF4D6A) else Color.White.copy(alpha = 0.6f)) {
                        mediaId.toLongOrNull()?.let { profile.toggleFavorite(it); isFav = profile.favorites.contains(it) }
                    }
                    PlainGlyphButton(Glyph.Prev, 56.dp, 30.dp) {
                        controller?.let { if (it.hasPreviousMediaItem()) it.seekToPreviousMediaItem() else it.seekTo(0) }
                    }
                    PlainGlyphButton(if (playing) Glyph.Pause else Glyph.Play, 64.dp, 38.dp) {
                        controller?.let { if (it.isPlaying) it.pause() else it.play() }
                    }
                    PlainGlyphButton(Glyph.Next, 56.dp, 30.dp) {
                        controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() }
                    }
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (lyricsOn) Color.White.copy(alpha = 0.28f) else Color.Transparent)
                            .clickable { lyricsOn = !lyricsOn },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("\u201C\u201D", color = Color.White.copy(alpha = 0.75f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 5) flashlight (left) and camera (right)
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 46.dp)
                    .padding(bottom = buttonsBottom)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                RoundLockButton(active = torchOn, diameter = buttonsH) {
                    val id = torchId ?: return@RoundLockButton
                    try { cam.setTorchMode(id, !torchOn) } catch (_: Exception) { }
                }
                RoundLockButton(active = false, diameter = buttonsH, camera = true) {
                    val ctx = context
                    try {
                        ctx.startActivity(
                            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                        try {
                            ctx.startActivity(
                                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) { }
                    }
                }
            }

            // the bar at the bottom: tap it (or swipe up anywhere) to unlock
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .width(160.dp).height(24.dp)
                    .clickable { onUnlock() },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.width(110.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.85f)))
            }
        }
    }
}

/** Little animated "sound bars" in the corner of the card; they stand still while paused. */
@Composable
private fun EqBars(playing: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    val hs = listOf(0.55f, 0.9f, 0.7f, 1f, 0.6f).mapIndexed { i, base ->
        val v by t.animateFloat(
            0.3f, 1f,
            infiniteRepeatable(tween(420 + i * 90), RepeatMode.Reverse), label = "eq$i"
        )
        if (playing) v * base else 0.35f
    }
    Row(modifier.height(22.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        hs.forEach { h ->
            Box(Modifier.width(3.dp).height(22.dp * h).clip(CircleShape).background(Color.White.copy(alpha = 0.7f)))
        }
    }
}

/** The round flashlight / camera buttons under the card. */
@Composable
private fun RoundLockButton(active: Boolean, diameter: Dp, camera: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(diameter)
            .clip(CircleShape)
            .background(if (active) Color.White.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.16f))
            .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        val fg = if (active) Color.Black.copy(alpha = 0.8f) else Color.White
        androidx.compose.foundation.Canvas(Modifier.size(26.dp)) {
            val w = size.width
            val h = size.height
            if (camera) {
                drawRoundRect(fg, androidx.compose.ui.geometry.Offset(w * 0.04f, h * 0.24f), androidx.compose.ui.geometry.Size(w * 0.92f, h * 0.66f), androidx.compose.ui.geometry.CornerRadius(w * 0.14f))
                drawRoundRect(fg, androidx.compose.ui.geometry.Offset(w * 0.30f, h * 0.10f), androidx.compose.ui.geometry.Size(w * 0.40f, h * 0.2f), androidx.compose.ui.geometry.CornerRadius(w * 0.06f))
                drawCircle(Color.Black.copy(alpha = 0.45f), w * 0.22f, androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.57f))
                drawCircle(fg, w * 0.14f, androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.57f))
            } else {
                // flashlight: head, neck, body with a switch
                drawRoundRect(fg, androidx.compose.ui.geometry.Offset(w * 0.22f, h * 0.02f), androidx.compose.ui.geometry.Size(w * 0.56f, h * 0.2f), androidx.compose.ui.geometry.CornerRadius(w * 0.06f))
                drawRoundRect(fg, androidx.compose.ui.geometry.Offset(w * 0.30f, h * 0.20f), androidx.compose.ui.geometry.Size(w * 0.40f, h * 0.78f), androidx.compose.ui.geometry.CornerRadius(w * 0.1f))
                drawRoundRect(Color.Black.copy(alpha = 0.45f), androidx.compose.ui.geometry.Offset(w * 0.45f, h * 0.38f), androidx.compose.ui.geometry.Size(w * 0.10f, h * 0.2f), androidx.compose.ui.geometry.CornerRadius(w * 0.05f))
            }
        }
    }
}

/** A thin bar you can tap or drag. [fraction] is 0..1; [onChange] fires while touching, [onDone] on release. */
@Composable
private fun LockSlider(fraction: Float, onChange: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier) {
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    Box(
        modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    change((o.x / size.width).coerceIn(0f, 1f))
                    done()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { c, _ -> change((c.position.x / size.width).coerceIn(0f, 1f)) }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f)).background(Color.White.copy(alpha = 0.9f)))
        }
    }
}

@Composable
private fun PlainGlyphButton(glyph: Glyph, size: Dp, icon: Dp, color: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(glyph, color, Modifier.size(icon))
    }
}
