package com.example.musicapp

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "Live lock screen" in the iOS style. While music plays and you wake a locked phone this opens above
 * the lock screen:
 *  - first a calm lock screen: big date and clock, and a glass now-playing card at the bottom;
 *  - tap the cover (or the card): the cover springs from the card to the middle of the screen, the
 *    background becomes the same cover, blurred, and the controls (seek bar, previous / play / next,
 *    volume) fade in under it; the cover shrinks a little while the song is paused;
 *  - the quote button turns it into the lyrics view: the cover moves up next to the title and the
 *    synced lyrics fill the screen in big bold lines, the far ones soft and blurred;
 *  - swipe down (or Back) to go back to the card, swipe up (or tap the bar) to unlock; the app then
 *    opens on its full player.
 * Settings > Live lock screen turns it on. It needs "Display over other apps" so Android lets the app
 * open a screen from the background.
 */
class LockScreenActivity : ComponentActivity() {
    private val closer = object : BroadcastReceiver() {
        // unlocked, or the screen went off again: nothing more to show
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this, closer,
            IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_SCREEN_OFF)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        setContent { LockPlayer(onUnlock = { unlock() }) }
    }

    /** Swipe up: ask Android to unlock, then land on the app's full player. */
    private fun unlock() {
        val open = Intent(this, MainActivity::class.java).apply {
            action = ACTION_OPEN_PLAYER
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    startActivity(open)
                    finish()
                }
            })
        } else {
            startActivity(open)
            finish()
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (_: Exception) { }
        super.onDestroy()
    }
}

/** Lives in PlaybackService: when the screen turns on while locked and music plays, open the lock player. */
class ScreenOnReceiver(
    private val player: () -> Player?,
    private val enabled: () -> Boolean
) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!enabled()) return
        if (player()?.isPlaying != true) return
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) return
        if (!android.provider.Settings.canDrawOverlays(context)) return
        try {
            context.startActivity(
                Intent(context, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (_: Exception) { }
    }
}

private enum class CoverSlot { Mini, Big, Small }

@Composable
private fun LockPlayer(onUnlock: () -> Unit) {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) { controller = null }
        }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future); controller = null }
    }

    // what is playing, refreshed four times a second
    var item by remember { mutableStateOf<MediaItem?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(controller) {
        val c = controller ?: return@LaunchedEffect
        while (true) {
            item = c.currentMediaItem
            playing = c.isPlaying
            pos = c.currentPosition
            dur = c.duration.coerceAtLeast(0L)
            delay(250)
        }
    }

    val mediaId = item?.mediaId.orEmpty()
    val meta = item?.mediaMetadata
    val title = meta?.title?.toString().orEmpty()
    val artist = meta?.artist?.toString().orEmpty()

    // cover (embedded picture / album art) and its average colour
    val cover by produceState<Bitmap?>(null, mediaId) {
        val it2 = item ?: return@produceState
        value = withContext(Dispatchers.IO) {
            try {
                MusicWidget.loadCover(context.applicationContext, it2.mediaId, it2.localConfiguration?.uri, it2.mediaMetadata.artworkUri)
            } catch (_: Exception) { null }
        }
    }
    val tint = remember(cover) {
        cover?.let {
            val px = Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0)
            Color(px)
        } ?: Color(0xFF3A3A3C)
    }
    val top = androidx.compose.ui.graphics.lerp(tint, Color.Black, 0.55f)

    // the song itself (needed to look up lyrics): found by id in the device library
    val songs by produceState<Map<Long, Song>>(emptyMap()) {
        value = withContext(Dispatchers.IO) {
            OnlineRegistry.init(context.applicationContext)
            try { loadSongs(context).associateBy { it.id } } catch (_: Exception) { emptyMap() }
        }
    }
    val song = mediaId.toLongOrNull()?.let { songs[it] ?: OnlineRegistry.get(it) }
    val lines by produceState<List<LrcLine>>(emptyList(), song?.id) {
        val s = song
        value = if (s == null) emptyList() else try {
            val online = context.getSharedPreferences("settings", 0).getBoolean("auto_lyrics", true)
            LyricsRepo.get(context, s, online)
        } catch (_: Exception) { emptyList() }
    }
    val synced = lines.isNotEmpty() && lines.first().timeMs >= 0L
    val cur = if (synced) lines.indexOfLast { it.timeMs <= pos } else -1

    val is24 = remember { android.text.format.DateFormat.is24HourFormat(context) }
    val clock by produceState("") {
        val fmt = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(1000) }
    }
    val dateText = remember { SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date()) }

    // system volume
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }

    var open by remember { mutableStateOf(false) }
    var lyricsOn by remember { mutableStateOf(false) }
    var scrub by remember { mutableStateOf<Float?>(null) }
    BackHandler(enabled = open) { open = false }

    val bgAlpha by animateFloatAsState(if (open) 1f else 0f, tween(600), label = "lockBg")
    val coverScale by animateFloatAsState(
        if (open && !lyricsOn && !playing) 0.86f else 1f,
        spring(dampingRatio = 0.6f, stiffness = 300f), label = "lockCover"
    )

    var dragY by remember { mutableFloatStateOf(0f) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, Color.Black)))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { dragY = 0f },
                    onDragEnd = {
                        if (dragY < -160f) onUnlock() else if (dragY > 160f && open) open = false
                        dragY = 0f
                    },
                    onDragCancel = { dragY = 0f },
                    onVerticalDrag = { _, d -> dragY += d }
                )
            }
    ) {
        // the cover, blurred, as the background once the player is open (real blur needs Android 12+)
        val bmp = cover
        if (Build.VERSION.SDK_INT >= 31 && bmp != null) {
            Image(
                bmp.asImageBitmap(), null,
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = 1.5f; scaleY = 1.5f; alpha = bgAlpha }
                    .blur(50.dp, BlurredEdgeTreatment.Unbounded),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(Modifier.fillMaxSize().background(tint.copy(alpha = 0.35f * bgAlpha)))
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.28f * bgAlpha)))

        BoxWithConstraints(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            val bigSize = minOf(maxWidth - 72.dp, maxHeight * 0.40f, 320.dp)
            val slot = if (!open) CoverSlot.Mini else if (lyricsOn) CoverSlot.Small else CoverSlot.Big
            val spec = spring<Dp>(dampingRatio = 0.78f, stiffness = 260f)
            val cx by animateDpAsState(
                if (slot == CoverSlot.Big) (maxWidth - bigSize) / 2 else 24.dp, spec, label = "coverX"
            )
            val cy by animateDpAsState(
                if (slot == CoverSlot.Mini) maxHeight - 40.dp - 66.dp + 10.dp else 30.dp, spec, label = "coverY"
            )
            val cs by animateDpAsState(
                when (slot) { CoverSlot.Mini -> 46.dp; CoverSlot.Big -> bigSize; CoverSlot.Small -> 48.dp }, spec, label = "coverSize"
            )
            val cr by animateDpAsState(
                when (slot) { CoverSlot.Mini -> 10.dp; CoverSlot.Big -> 14.dp; CoverSlot.Small -> 8.dp }, spec, label = "coverCorner"
            )
            val elev by animateDpAsState(if (slot == CoverSlot.Big) 24.dp else 0.dp, tween(500), label = "coverShadow")

            // 1) the calm lock screen: date, clock, and the now-playing card
            AnimatedVisibility(visible = !open, enter = fadeIn(tween(300)), exit = fadeOut(tween(250))) {
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(dateText, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text(
                            clock, color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Medium,
                            letterSpacing = (-2).sp
                        )
                    }
                    Row(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 14.dp)
                            .padding(bottom = 40.dp)
                            .fillMaxWidth()
                            .height(66.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.16f))
                            .clickable { open = true }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(Modifier.width(56.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(artist, color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        PlainGlyphButton(if (playing) Glyph.Pause else Glyph.Play, 40.dp, 22.dp) {
                            controller?.let { if (it.isPlaying) it.pause() else it.play() }
                        }
                        PlainGlyphButton(Glyph.Next, 40.dp, 20.dp) {
                            controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() }
                        }
                    }
                }
            }

            // 2) the open player: cover in the middle (or small, with lyrics), controls under it
            AnimatedVisibility(visible = open, enter = fadeIn(tween(350)), exit = fadeOut(tween(200))) {
                Column(Modifier.fillMaxSize().padding(horizontal = 24.dp).padding(bottom = 30.dp)) {
                    Box(
                        Modifier.fillMaxWidth().height(30.dp).clickable { open = false },
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Box(
                            Modifier.padding(top = 10.dp).width(38.dp).height(5.dp)
                                .clip(CircleShape).background(Color.White.copy(alpha = 0.45f))
                        )
                    }

                    if (!lyricsOn) {
                        Spacer(Modifier.height(bigSize + 18.dp))
                        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(artist, color = Color.White.copy(alpha = 0.7f), fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.weight(1f))
                    } else {
                        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                            Spacer(Modifier.width(60.dp))
                            Column {
                                Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(artist, color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            if (lines.isEmpty()) {
                                Text(
                                    "No lyrics for this song", color = Color.White.copy(alpha = 0.5f), fontSize = 18.sp,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            } else {
                                val state = rememberLazyListState()
                                LaunchedEffect(cur) { if (cur >= 0) state.animateScrollToItem((cur - 1).coerceAtLeast(0)) }
                                LazyColumn(
                                    state = state, modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(bottom = 200.dp)
                                ) {
                                    itemsIndexed(lines) { i, l ->
                                        val dist = if (!synced) 0 else kotlin.math.abs(i - cur)
                                        val a by animateFloatAsState(
                                            if (!synced) 0.85f else if (dist == 0) 1f else 0.32f, tween(350), label = "lyricAlpha"
                                        )
                                        val b by animateDpAsState(
                                            if (dist <= 1) 0.dp else (dist - 1).coerceAtMost(3).dp, tween(350), label = "lyricBlur"
                                        )
                                        Text(
                                            l.text.ifBlank { "♪" },
                                            color = Color.White.copy(alpha = a),
                                            fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Start,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp)
                                                .then(if (b > 0.dp) Modifier.blur(b) else Modifier)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // seek bar
                    val frac = scrub ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
                    val shownPos = if (scrub != null) (frac * dur).toLong() else pos
                    LockSlider(
                        frac,
                        onChange = { scrub = it },
                        onDone = {
                            scrub?.let { f -> if (dur > 0) controller?.seekTo((f * dur).toLong()) }
                            scrub = null
                        }
                    )
                    Row(Modifier.fillMaxWidth()) {
                        Text(formatTime(shownPos), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("-" + formatTime((dur - shownPos).coerceAtLeast(0L)), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                    }

                    // controls
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlainGlyphButton(Glyph.Prev, 64.dp, 30.dp) {
                            controller?.let { if (it.hasPreviousMediaItem()) it.seekToPreviousMediaItem() else it.seekTo(0) }
                        }
                        PlainGlyphButton(if (playing) Glyph.Pause else Glyph.Play, 84.dp, 42.dp) {
                            controller?.let { if (it.isPlaying) it.pause() else it.play() }
                        }
                        PlainGlyphButton(Glyph.Next, 64.dp, 30.dp) {
                            controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() }
                        }
                    }

                    // volume
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        GlyphIcon(Glyph.Volume, Color.White.copy(alpha = 0.5f), Modifier.size(16.dp))
                        LockSlider(
                            vol,
                            onChange = {
                                vol = it
                                try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVol).toInt().coerceIn(0, maxVol), 0) } catch (_: Exception) { }
                            },
                            onDone = { },
                            modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                        )
                        GlyphIcon(Glyph.Volume, Color.White.copy(alpha = 0.8f), Modifier.size(22.dp))
                    }

                    // lyrics on / off
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (lyricsOn) Color.White.copy(alpha = 0.28f) else Color.Transparent)
                                .clickable { lyricsOn = !lyricsOn },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("\u201C\u201D", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 3) the cover that travels between the card and the middle of the screen
            Box(
                Modifier
                    .offset(cx, cy)
                    .size(cs)
                    .graphicsLayer { scaleX = coverScale; scaleY = coverScale }
                    .shadow(elev, RoundedCornerShape(cr), ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(RoundedCornerShape(cr))
                    .background(Color.White.copy(alpha = 0.10f))
                    .clickable(enabled = !open) { open = true },
                contentAlignment = Alignment.Center
            ) {
                if (bmp != null) {
                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    GlyphIcon(Glyph.Note, Color.White.copy(alpha = 0.85f), Modifier.size(cs * 0.4f))
                }
            }

            // the bar at the bottom: tap it (or swipe up anywhere) to unlock
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .width(160.dp).height(24.dp)
                    .clickable { onUnlock() },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.width(110.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.85f)))
            }
        }
    }
}

/** A thin bar you can tap or drag. [fraction] is 0..1; [onChange] fires while touching, [onDone] on release. */
@Composable
private fun LockSlider(fraction: Float, onChange: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier) {
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    Box(
        modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    change((o.x / size.width).coerceIn(0f, 1f))
                    done()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { c, _ -> change((c.position.x / size.width).coerceIn(0f, 1f)) }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f)).background(Color.White.copy(alpha = 0.9f)))
        }
    }
}

@Composable
private fun PlainGlyphButton(glyph: Glyph, size: Dp, icon: Dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(glyph, Color.White, Modifier.size(icon))
    }
}
