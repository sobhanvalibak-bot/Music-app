package com.example.musicapp

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import org.json.JSONArray
import org.json.JSONObject

// ───────────────────────── Automatic lyrics ─────────────────────────
//
// One source of truth for lyrics: the one-line lyric above the title, the "Lyrics preview" card and the
// full lyrics page all read the same lines from [rememberSongLyrics].
// Order: saved .lrc on the device → tag inside the audio file → online lookup (LRCLIB), which is then
// saved on the device so the next time it works offline.

sealed interface OnlineLyrics {
    class Found(val text: String, val synced: Boolean) : OnlineLyrics
    data object NotFound : OnlineLyrics
    data object Failed : OnlineLyrics   // no network / server error: try again later
}

object LrclibClient {
    private class Reply(val code: Int, val body: String)

    private fun get(url: String): Reply {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.instanceFollowRedirects = true
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", "MusicApp/1.2 (Android; synced lyrics)")
        c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            Reply(code, stream?.bufferedReader()?.use { it.readText() }.orEmpty())
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s.trim(), "UTF-8")

    /** "Song (Official Video) [HD] feat. X - Remastered 2011" → "Song". */
    fun cleanTitle(raw: String): String {
        var t = raw
            .replace(Regex("""\s*[(\[][^)\]]*[)\]]"""), " ")
            .replace(Regex("""(?i)\s+(feat\.?|ft\.?|featuring)\s+.*$"""), " ")
            .replace(Regex("""(?i)\s+-\s+(remaster(ed)?|live|single version|radio edit|official).*$"""), " ")
        t = t.replace(Regex("""\s+"""), " ").trim()
        return t.ifBlank { raw.trim() }
    }

    private fun usable(s: String) = s.isNotBlank() && !s.equals("Unknown Artist", true) && !s.equals("Unknown Album", true) && s != "<unknown>"

    private class Pick(val text: String, val synced: Boolean)

    private fun fromJson(o: JSONObject): Pick? {
        if (o.optBoolean("instrumental", false)) return null
        val synced = o.optString("syncedLyrics", "")
        if (synced.isNotBlank() && synced != "null") return Pick(synced, true)
        val plain = o.optString("plainLyrics", "")
        if (plain.isNotBlank() && plain != "null") return Pick(plain, false)
        return null
    }

    /** Looks the song up: exact match first (with length), then looser searches. Prefers time-synced lyrics. */
    fun find(song: Song): OnlineLyrics {
        val title = cleanTitle(song.title)
        val artist = (song.artists.firstOrNull() ?: song.artist).takeIf { usable(it) }
        val album = song.album.takeIf { usable(it) }
        val seconds = (song.durationMs / 1000L).toInt()
        var plain: Pick? = null
        var network = false

        fun consider(p: Pick?): Pick? {
            if (p == null) return null
            if (p.synced) return p
            if (plain == null) plain = p
            return null
        }

        fun call(url: String): String? {
            return try {
                val r = get(url)
                when {
                    r.code in 200..299 -> r.body
                    r.code == 404 -> null
                    else -> { network = true; null }
                }
            } catch (e: IOException) {
                network = true
                null
            } catch (e: Exception) {
                null
            }
        }

        fun obj(body: String?): JSONObject? = body?.let { runCatching { JSONObject(it) }.getOrNull() }
        fun arr(body: String?): JSONArray? = body?.let { runCatching { JSONArray(it) }.getOrNull() }

        if (artist != null) {
            // 1) exact: title + artist (+ album) + length
            val dur = if (seconds > 0) "&duration=$seconds" else ""
            if (album != null) {
                consider(obj(call("https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}&album_name=${enc(album)}$dur"))?.let { fromJson(it) })
                    ?.let { return OnlineLyrics.Found(it.text, true) }
            }
            if (network) return OnlineLyrics.Failed
            consider(obj(call("https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}$dur"))?.let { fromJson(it) })
                ?.let { return OnlineLyrics.Found(it.text, true) }
            if (network) return OnlineLyrics.Failed
        }

        // 2) search: pick the candidate whose length is closest to the file
        val queries = buildList {
            if (artist != null) add("https://lrclib.net/api/search?track_name=${enc(title)}&artist_name=${enc(artist)}")
            add("https://lrclib.net/api/search?q=${enc(if (artist != null) "$title $artist" else title)}")
        }
        for (q in queries) {
            val list = arr(call(q)) ?: continue
            val candidates = (0 until list.length()).mapNotNull { list.optJSONObject(it) }
                .filter { c ->
                    val d = c.optDouble("duration", -1.0)
                    seconds <= 0 || d < 0 || abs(d - seconds) <= 6.0
                }
                .sortedBy { c ->
                    val d = c.optDouble("duration", -1.0)
                    if (seconds > 0 && d >= 0) abs(d - seconds) else 999.0
                }
            for (c in candidates) {
                consider(fromJson(c))?.let { return OnlineLyrics.Found(it.text, true) }
            }
        }
        if (network) return OnlineLyrics.Failed
        plain?.let { return OnlineLyrics.Found(it.text, false) }
        return OnlineLyrics.NotFound
    }
}

object LyricsRepo {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inflight = HashMap<Long, Deferred<List<LrcLine>>>()

    /**
     * Lyrics of [song]: saved copy → file tag → online (when [online] is on). The same song asked twice
     * at once (the player and the background prefetch) shares one lookup.
     */
    suspend fun get(context: Context, song: Song, online: Boolean): List<LrcLine> {
        val app = context.applicationContext
        val job = synchronized(inflight) {
            inflight.getOrPut(song.id) {
                scope.async(start = CoroutineStart.LAZY) {
                    try {
                        load(app, song, online)
                    } finally {
                        synchronized(inflight) { inflight.remove(song.id) }
                    }
                }
            }
        }
        return job.await()
    }

    /** The original song and the version type when [song] is a slowed / sped-up / ... version of another song. */
    private fun fxSourceOf(app: Context, song: Song): Pair<Song, FxPreset>? {
        val o = FxPreview.originOf(song.id)
        val p = FxPreview.presetOf(song.id)
        if (o != null && p != null) return o to p
        if (song.id > 0L) {
            val (baseId, preset) = FxEngine.savedOrigin(app, song.id) ?: return null
            if (baseId <= 0L) return null
            val origin = loadSongs(app).firstOrNull { it.id == baseId } ?: return null
            return origin to preset
        }
        return null
    }

    private suspend fun load(app: Context, song: Song, online: Boolean): List<LrcLine> {
        // A version made from another song has the lyrics of the ORIGINAL, with every time moved by the speed
        // of the version (slowed = later, sped up = earlier). Own synced lyrics of a saved version are kept.
        val fx = fxSourceOf(app, song)
        if (fx != null) {
            val own = if (song.id > 0L) LyricsStore.load(app, song.id) else emptyList()
            if (own.isEmpty() || own.first().timeMs < 0L) {
                val (origin, preset) = fx
                val src = try { get(app, origin, online) } catch (e: Exception) { emptyList() }
                if (src.isNotEmpty()) {
                    val ready = if (src.first().timeMs >= 0L) scaleLrc(src, preset.speed) else src
                    if (song.id > 0L) LyricsStore.saveText(app, song.id, lrcText(ready))
                    return ready
                }
            }
        }
        var best = LyricsStore.load(app, song.id)
        if (best.isEmpty() && !song.isOnline && LyricsStore.shouldTryEmbedded(song.id)) {
            val text = TagEditor.readLyrics(app, song)
            if (text.isNotBlank()) {
                val parsed = parseLrc(text)
                if (parsed.isNotEmpty()) {
                    LyricsStore.saveText(app, song.id, text)
                    best = parsed
                }
            }
        }
        // already have time-synced lyrics: nothing more to do
        if (best.isNotEmpty() && best.first().timeMs >= 0L) return best
        if (!online || LyricsStore.recentlyMissed(app, song.id)) return best

        when (val r = LrclibClient.find(song)) {
            is OnlineLyrics.Found -> {
                val parsed = parseLrc(r.text)
                if (parsed.isNotEmpty() && (r.synced || best.isEmpty())) {
                    LyricsStore.saveText(app, song.id, r.text)
                    LyricsStore.clearMiss(app, song.id)
                    return parsed
                }
                LyricsStore.markMissed(app, song.id)
            }
            is OnlineLyrics.NotFound -> LyricsStore.markMissed(app, song.id)
            is OnlineLyrics.Failed -> Unit // offline: ask again next time
        }
        return best
    }

    /** "Search again": forget that this song had nothing online. */
    fun forget(context: Context, songId: Long) = LyricsStore.clearMiss(context.applicationContext, songId)
}

/** What every lyrics view of the player shows. [reload] re-reads (retry = true also searches online again). */
class SongLyrics(
    val lines: List<LrcLine>,
    val loading: Boolean,
    val reload: (retry: Boolean) -> Unit
) {
    val synced: Boolean get() = lines.isNotEmpty() && lines.first().timeMs >= 0L
}

@Composable
fun rememberSongLyrics(song: Song, auto: Boolean): SongLyrics {
    val context = LocalContext.current
    var version by remember(song.id) { mutableIntStateOf(0) }
    var lines by remember(song.id) { mutableStateOf<List<LrcLine>>(emptyList()) }
    var loading by remember(song.id) { mutableStateOf(true) }
    val editedTick = LyricsStore.editVersion
    LaunchedEffect(song.id, version, auto, editedTick) {
        loading = true
        lines = LyricsRepo.get(context, song, auto)
        loading = false
    }
    return SongLyrics(lines, loading) { retry ->
        if (retry) LyricsRepo.forget(context, song.id)
        version++
    }
}

// ───────────────────────── Lyrics of a slowed / sped-up version ─────────────────────────

/** Moves every time of the lyrics for a version that plays at [speed] (0.85 = slower: everything comes later). */
fun scaleLrc(lines: List<LrcLine>, speed: Float): List<LrcLine> {
    if (speed <= 0f || abs(speed - 1f) < 0.001f) return lines
    fun t(ms: Long): Long = if (ms < 0L) ms else (ms.toDouble() / speed.toDouble()).toLong()
    return lines.map { l -> l.copy(timeMs = t(l.timeMs), words = l.words.map { w -> w.copy(timeMs = t(w.timeMs)) }) }
}

private fun lrcStamp(ms: Long, open: Char, close: Char): String {
    val v = ms.coerceAtLeast(0L)
    return String.format(java.util.Locale.US, "%c%02d:%02d.%02d%c", open, v / 60_000L, (v % 60_000L) / 1000L, (v % 1000L) / 10L, close)
}

/** Back to .lrc text (line times and word times), so it can be saved and read again by [parseLrc]. */
fun lrcText(lines: List<LrcLine>): String {
    val sb = StringBuilder()
    for (l in lines) {
        if (l.timeMs < 0L) { sb.append(l.text).append('\n'); continue }
        sb.append(lrcStamp(l.timeMs, '[', ']'))
        if (l.words.isNotEmpty()) l.words.forEach { w -> sb.append(lrcStamp(w.timeMs, '<', '>')).append(w.text) }
        else sb.append(l.text)
        sb.append('\n')
    }
    return sb.toString()
}
