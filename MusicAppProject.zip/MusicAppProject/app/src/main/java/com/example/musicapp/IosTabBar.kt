package com.example.musicapp

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.unit.lerp as lerpDp

/*
 * iOS 26 style floating tab bar, built the way the SwiftUI TabView version works:
 *
 *  - The bar does not decide anything by itself. The app tells it
 *      visible    -> SwiftUI  .toolbar(isVisible ? .visible : .hidden, for: .tabBar)
 *                               + .animation(.easeInOut, value: isVisible)
 *      minimized  -> SwiftUI  .tabBarMinimizeBehavior(.onScrollDown)
 *      selected   -> SwiftUI  TabView(selection:)
 *  - Selection is a glass pill that slides between the tabs on a bouncy spring.
 *  - Holding the bar lifts the pill (it grows); dragging moves it; the tab changes when you let go.
 *  - The selected icon does the SF Symbol "bounce" when it becomes selected.
 *  - Minimized: the bar melts into a small pill that shows only the selected icon. Tap it to expand.
 *  - The search button is its own round glass button on the right (like Tab(role: .search)).
 */

private val IosTabs = listOf(
    "Songs" to Glyph.Note,
    "Artist" to Glyph.Artist,
    "Albums" to Glyph.Album,
    "Profile" to Glyph.Artist
)

// The bar shows Songs, Artist, Albums, Profile; the app's own tab numbers are
// 0 = Songs, 1 = Albums, 2 = Artists, 3 = Profile. This maps bar position -> app tab.
private val IosTabOrder = listOf(0, 2, 1, 3)

private val TabBarPad = 6.dp
private val TabBarFullH = 64.dp
private val TabBarMiniH = 52.dp

@Composable
fun IosTabBar(
    modifier: Modifier = Modifier,
    visible: Boolean,
    minimized: Boolean,
    selected: Int,
    onSelect: (Int) -> Unit,
    onReselect: () -> Unit,
    onExpand: () -> Unit,
    searchActive: Boolean,
    onSearch: () -> Unit,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    onHeightChanged: (Int) -> Unit = {}
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    // show / hide: slides down and fades, easeInOut like SwiftUI's default animation
    val show by animateFloatAsState(
        if (visible) 1f else 0f, tween(350, easing = EaseInOut), label = "tabShow"
    )
    // 0 = full bar, 1 = minimized pill
    val m by animateFloatAsState(
        if (minimized) 1f else 0f,
        spring(dampingRatio = 0.85f, stiffness = 380f),
        label = "tabMin"
    )

    val count = IosTabs.size
    val sel = IosTabOrder.indexOf(selected) // -1 when nothing is selected (search is open)

    val currentSel by rememberUpdatedState(sel)
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnReselect by rememberUpdatedState(onReselect)
    val currentOnExpand by rememberUpdatedState(onExpand)
    val currentMin by rememberUpdatedState(minimized)
    val currentVisible by rememberUpdatedState(visible)

    var pressed by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var fingerX by remember { mutableFloatStateOf(0f) }

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .graphicsLayer {
                alpha = show
                translationY = (1f - show) * (size.height + 90.dp.toPx())
            }
    ) {
        val gap = 10.dp
        val fullW = maxWidth - gap - TabBarFullH
        val itemWdp = (fullW - TabBarPad * 2) / count
        val minW = itemWdp + TabBarPad * 2
        val barH = lerpDp(TabBarFullH, TabBarMiniH, m)
        val capsuleW = lerpDp(fullW, minW, m)

        val padPx = with(density) { TabBarPad.toPx() }
        val fullWpx = with(density) { fullW.toPx() }
        val capsuleWpx = with(density) { capsuleW.toPx() }
        val itemW = ((fullWpx - 2f * padPx) / count).coerceAtLeast(1f)
        val itemWState by rememberUpdatedState(itemW)
        val padState by rememberUpdatedState(padPx)

        // where the selection pill is, in "tab units" (0f = first tab, 3f = last tab)
        val targetPos = if (dragging)
            ((fingerX - padPx) / itemW - 0.5f).coerceIn(0f, (count - 1).toFloat())
        else sel.coerceAtLeast(0).toFloat()
        val pos by animateFloatAsState(
            targetPos,
            if (dragging) spring(dampingRatio = 0.8f, stiffness = 900f)
            else spring(dampingRatio = 0.62f, stiffness = 420f),
            label = "tabPos"
        )
        // pressing the bar lifts the pill
        val lift by animateFloatAsState(
            if (pressed && !minimized) 1f else 0f,
            spring(dampingRatio = 0.55f, stiffness = 360f),
            label = "tabLift"
        )
        val pillAlpha by animateFloatAsState(
            if (sel >= 0) 1f else 0f, spring(dampingRatio = 1f, stiffness = 500f), label = "pillAlpha"
        )

        Row(
            Modifier
                .fillMaxWidth()
                .height(TabBarFullH)
                .onSizeChanged { onHeightChanged(it.height) },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ───────── the capsule ─────────
            Box(
                Modifier
                    .width(capsuleW)
                    .height(barH)
                    .graphicsLayer {
                        // the whole bar swells a little under your finger
                        scaleX = 1f + 0.04f * lift
                        scaleY = 1f + 0.05f * lift
                    }
                    .liquidGlass(CircleShape)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            if (!currentVisible) return@awaitEachGesture
                            down.consume()

                            // minimized: a tap anywhere on the pill brings the full bar back
                            if (currentMin) {
                                val up = waitForUpOrCancellation()
                                if (up != null) {
                                    up.consume()
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    currentOnExpand()
                                }
                                return@awaitEachGesture
                            }

                            fun indexAt(x: Float): Int =
                                ((x - padState) / itemWState).toInt().coerceIn(0, count - 1)

                            pressed = true
                            fingerX = down.position.x
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)

                            val wasSel = currentSel
                            var lastIdx = indexAt(down.position.x)
                            var finalX = down.position.x
                            var moved = false
                            var released = false
                            while (true) {
                                val ev = awaitPointerEvent()
                                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                if (!ch.pressed) { released = true; break }
                                ch.consume()
                                finalX = ch.position.x
                                fingerX = finalX
                                if (abs(finalX - down.position.x) > 24f) {
                                    moved = true
                                    dragging = true
                                }
                                val i = indexAt(finalX)
                                if (i != lastIdx) {
                                    lastIdx = i
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                            // let go: the pill drops back into the bar with a bounce
                            pressed = false
                            dragging = false
                            if (released) {
                                val target = indexAt(finalX)
                                if (target != wasSel) currentOnSelect(IosTabOrder[target])
                                else if (!moved) currentOnReselect()
                            }
                        }
                    }
            ) {
                // Everything inside is laid out at full width. When minimized it slides sideways so the
                // selected tab sits in the middle of the shrinking capsule (the rest is clipped away).
                Box(
                    Modifier
                        .wrapContentWidth(Alignment.Start, unbounded = true)
                        .width(fullW)
                        .fillMaxHeight()
                        .graphicsLayer {
                            val cx = padPx + pos * itemW + itemW / 2f
                            translationX = (capsuleWpx / 2f - cx) * m
                        }
                ) {
                    // selection pill
                    Box(
                        Modifier
                            .offset { IntOffset((padPx + pos * itemW).roundToInt(), 0) }
                            .width(itemWdp)
                            .fillMaxHeight()
                            .padding(vertical = 4.dp)
                            .graphicsLayer {
                                alpha = pillAlpha
                                scaleX = 1f + 0.16f * lift
                                scaleY = 1f + 0.10f * lift
                            }
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.10f + 0.08f * lift))
                            .border(
                                1.dp,
                                Brush.linearGradient(
                                    listOf(
                                        Color.White.copy(alpha = 0.50f),
                                        Color.White.copy(alpha = 0.10f),
                                        Color.White.copy(alpha = 0.35f)
                                    )
                                ),
                                CircleShape
                            )
                    )

                    // tabs
                    Row(Modifier.fillMaxSize().padding(horizontal = TabBarPad)) {
                        IosTabs.forEachIndexed { i, (label, glyph) ->
                            val isSel = i == sel
                            // the tab under the pill takes the accent colour as the pill passes it
                            val near = (1f - abs(i - pos)).coerceIn(0f, 1f) * pillAlpha
                            val tint = lerpColor(Color.White.copy(alpha = 0.78f), p.accent, near)

                            // SF Symbol "bounce" when the tab becomes selected
                            val bounce = remember { Animatable(1f) }
                            LaunchedEffect(isSel) {
                                if (isSel) {
                                    bounce.snapTo(0.72f)
                                    bounce.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 420f))
                                }
                            }

                            Column(
                                Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .graphicsLayer { alpha = if (isSel) 1f else 1f - m },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    Modifier
                                        .size(26.dp)
                                        .graphicsLayer {
                                            val s = bounce.value * (1f + 0.18f * lift * near)
                                            scaleX = s
                                            scaleY = s
                                            // labels fade out when minimized, so the icon settles to the centre
                                            translationY = 6.dp.toPx() * m
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (i == IosTabs.lastIndex) {
                                        Avatar(
                                            photo, profileName, p,
                                            Modifier
                                                .fillMaxSize()
                                                .then(
                                                    if (isSel) Modifier.border(1.5.dp, p.accent, CircleShape)
                                                    else Modifier
                                                ),
                                            14.sp
                                        )
                                    } else {
                                        GlyphIcon(glyph, tint, Modifier.size(22.dp))
                                    }
                                }
                                Text(
                                    label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Medium,
                                    color = tint,
                                    maxLines = 1,
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .graphicsLayer { alpha = 1f - m }
                                )
                            }
                        }
                    }
                }
            }

            // ───────── the search button ─────────
            IosSearchButton(
                size = barH,
                active = searchActive,
                accent = p.accent,
                enabled = visible,
                onClick = onSearch
            )
        }
    }
}

@Composable
private fun IosSearchButton(
    size: androidx.compose.ui.unit.Dp,
    active: Boolean,
    accent: Color,
    enabled: Boolean,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.88f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 450f),
        label = "searchScale"
    )
    val tint by animateFloatAsState(if (active) 1f else 0f, tween(200), label = "searchTint")
    val onClickS by rememberUpdatedState(onClick)
    val enabledS by rememberUpdatedState(enabled)
    Box(
        Modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .liquidGlass(CircleShape)
            .background(accent.copy(alpha = 0.20f * tint), CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        if (enabledS) {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        }
                    },
                    onTap = { if (enabledS) onClickS() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(Glyph.Search, lerpColor(Color.White.copy(alpha = 0.85f), accent, tint), Modifier.size(24.dp))
    }
}

/** Dark glass: soft shadow, slightly see-through body, thin light rim. */
private fun Modifier.liquidGlass(shape: Shape): Modifier =
    this
        .shadow(
            18.dp, shape,
            ambientColor = Color.Black.copy(alpha = 0.40f),
            spotColor = Color.Black.copy(alpha = 0.40f)
        )
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(
                    Color(0xFF2B2B30).copy(alpha = 0.90f),
                    Color(0xFF111113).copy(alpha = 0.92f)
                )
            )
        )
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.34f),
                    Color.White.copy(alpha = 0.06f),
                    Color.White.copy(alpha = 0.22f)
                )
            ),
            shape
        )
