package com.example.musicapp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.ln
import kotlin.math.pow
import kotlin.random.Random

/**
 * Songs the user hid from the library ("Hide from library" in a song's menu).
 * Nothing is deleted from the device: they just vanish from lists, search and shuffles.
 * Settings > Hidden songs brings them all back.
 */
object HiddenSongs {
    private var app: Context? = null
    private val set = HashSet<Long>()

    /** Goes up on every change so screens refresh. */
    var version by mutableIntStateOf(0)
        private set

    val count: Int get() { version; return set.size }

    @Synchronized
    fun init(context: Context) {
        if (app != null) return
        app = context.applicationContext
        val saved = app!!.getSharedPreferences("hidden", Context.MODE_PRIVATE).getString("ids", "") ?: ""
        saved.split(",").mapNotNullTo(set) { it.toLongOrNull() }
    }

    fun isHidden(id: Long): Boolean = set.contains(id)

    private fun save() {
        app?.getSharedPreferences("hidden", Context.MODE_PRIVATE)?.edit()
            ?.putString("ids", set.joinToString(","))?.apply()
        version++
    }

    @Synchronized fun hide(id: Long) { if (set.add(id)) save() }
    @Synchronized fun clear() { if (set.isNotEmpty()) { set.clear(); save() } }
}

/**
 * Shuffle that is not blind: songs you play a lot come up a bit more often, songs you keep
 * skipping (switched away in the first 10 seconds) come up less. Still random every time.
 */
fun smartShuffle(list: List<Song>, log: ListenLog): List<Song> {
    val w = log.shuffleWeights()
    return list.sortedByDescending { s ->
        // weighted random order: a bigger weight makes a high key more likely
        Random.nextDouble().coerceAtLeast(1e-9).pow(1.0 / (w[s.id] ?: 1.0))
    }
}

internal fun weightFor(plays: Long, skips: Int): Double =
    ((1.0 + 0.8 * ln(1.0 + plays)) / (1.0 + 0.5 * skips)).coerceIn(0.25, 4.0)
