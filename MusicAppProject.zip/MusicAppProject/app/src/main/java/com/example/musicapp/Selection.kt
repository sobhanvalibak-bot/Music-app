package com.example.musicapp

import android.app.RecoverableSecurityException
import android.content.Context
import android.content.IntentSender
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── Multi-select UI ─────────────────────────

/** The round check mark shown at the start of a row while songs are being selected. */
@Composable
fun SelectCircle(selected: Boolean, p: Palette) {
    Box(
        Modifier
            .size(24.dp)
            .clip(CircleShape)
            .then(
                if (selected) Modifier.background(p.accent)
                else Modifier.border(2.dp, p.secondary.copy(alpha = 0.7f), CircleShape)
            ),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(Icons.Default.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun BarButton(label: String, p: Palette, tint: Color, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = tint, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/**
 * Bar that replaces the tab bar while songs are selected:
 * cancel · "N selected" · play next · add to queue · delete.
 */
@Composable
fun SelectionBar(
    count: Int,
    p: Palette,
    height: Dp,
    onCancel: () -> Unit,
    onSelectAll: (() -> Unit)?,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val red = Color(0xFFFF3B30)
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .heightIn(min = height)
            .clip(RoundedCornerShape(28.dp))
            .background(p.card)
            .border(1.dp, p.secondary.copy(alpha = 0.18f), RoundedCornerShape(28.dp))
            // taps on the bar must not reach the list behind it
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).clickable { onCancel() },
            contentAlignment = Alignment.Center
        ) { GlyphIcon(Glyph.Close, p.text, Modifier.size(18.dp)) }
        Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
            Text(
                if (count == 1) "1 selected" else "$count selected",
                fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = p.text, maxLines = 1
            )
            if (onSelectAll != null) {
                Text(
                    "Select all", fontSize = 12.sp, color = p.accent,
                    modifier = Modifier.clickable { onSelectAll() }
                )
            }
        }
        BarButton("Next", p, p.text, onPlayNext) { GlyphIcon(Glyph.Next, p.text, Modifier.size(22.dp)) }
        BarButton("Queue", p, p.text, onAddToQueue) { GlyphIcon(Glyph.Queue, p.text, Modifier.size(22.dp)) }
        BarButton("Delete", p, red, onDelete) { GlyphIcon(Glyph.Trash, red, Modifier.size(22.dp)) }
    }
}

// ───────────────────────── Deleting songs from the device ─────────────────────────

sealed interface DeleteResult {
    data object Done : DeleteResult
    class NeedsGrant(val sender: IntentSender) : DeleteResult
    class Error(val message: String) : DeleteResult
}

object SongDeleter {
    /**
     * Android 10 and older: delete the songs one by one. On Android 10 the system asks the user once
     * per file that this app does not own ([DeleteResult.NeedsGrant]); call again after the user agreed.
     * (Android 11+ uses MediaStore.createDeleteRequest, one dialog for all songs, see MusicApp.)
     */
    fun deleteDirect(context: Context, songs: List<Song>): DeleteResult {
        val resolver = context.contentResolver
        for (s in songs) {
            try {
                resolver.delete(s.uri, null, null)
            } catch (e: SecurityException) {
                return if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    DeleteResult.NeedsGrant(e.userAction.actionIntent.intentSender)
                } else {
                    DeleteResult.Error("Android did not allow deleting \"${s.title}\"")
                }
            } catch (e: Exception) {
                return DeleteResult.Error(e.message ?: "Could not delete \"${s.title}\"")
            }
        }
        return DeleteResult.Done
    }
}
