package com.example.musicapp

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSourceBitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import java.util.concurrent.Executors

/** Cover address of a song on the phone: musicapp-cover://song/<id>?art=<old address, used as the last try>. */
const val COVER_SCHEME = "musicapp-cover"

fun songCoverUri(id: Long, fallback: Uri?): Uri =
    Uri.Builder().scheme(COVER_SCHEME).authority("song").appendPath(id.toString())
        .apply { if (fallback != null) appendQueryParameter("art", fallback.toString()) }
        .build()

/**
 * Gives the notification, lock screen and Bluetooth / car displays the SAME cover the app shows:
 * the custom cover, the picture inside the file, the system thumbnail, then the old album-art address.
 * (The old content://media/external/audio/albumart address alone is empty for many songs on Android 10+.)
 */
@UnstableApi
class CoverBitmapLoader(private val context: Context) : BitmapLoader {

    private val app = context.applicationContext
    private val delegate = DataSourceBitmapLoader(app)
    private val io = Executors.newFixedThreadPool(2)

    override fun supportsMimeType(mimeType: String): Boolean = delegate.supportsMimeType(mimeType)

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = delegate.decodeBitmap(data)

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        if (uri.scheme != COVER_SCHEME) return delegate.loadBitmap(uri)
        val f = SettableFuture.create<Bitmap>()
        io.execute {
            try {
                val id = uri.lastPathSegment ?: throw IllegalArgumentException("no song id")
                val songUri = id.toLongOrNull()?.takeIf { it > 0L }
                    ?.let { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
                val art = uri.getQueryParameter("art")?.let { Uri.parse(it) }
                val bmp = MusicWidget.loadCover(app, id, songUri, art)
                if (bmp == null) f.setException(IllegalStateException("no cover for $id")) else f.set(shrink(bmp))
            } catch (e: Throwable) {
                f.setException(e)
            }
        }
        return f
    }

    /** A huge picture in a notification can fail to be sent to the system: 512 px is plenty. */
    private fun shrink(b: Bitmap): Bitmap {
        val max = 512
        val big = maxOf(b.width, b.height)
        if (big <= max) return b
        val k = max.toFloat() / big
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }
}
