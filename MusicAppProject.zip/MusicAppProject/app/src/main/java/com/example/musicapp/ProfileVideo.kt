package com.example.musicapp

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.compose.ui.platform.LocalContext
import java.io.File

@Composable
fun LoopingProfileVideo(path: String, modifier: Modifier = Modifier, crop: Boolean = true) {
    val context = LocalContext.current
    val player = androidx.compose.runtime.remember(path) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            volume = 0f
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(modifier = modifier, factory = { ctx ->
        // inflated from XML because the surface type (texture_view) can only be set there;
        // a TextureView follows the circle / rounded clip, the default SurfaceView draws a rectangle
        (android.view.LayoutInflater.from(ctx).inflate(R.layout.profile_video_view, null) as PlayerView).apply {
            useController = false
            resizeMode = if (crop) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            this.player = player
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
        }
    }, update = { it.player = player })
}
