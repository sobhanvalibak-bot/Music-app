@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.musicapp

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.MarqueeSpacing
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.DrawTransform
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.media3.common.Player
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

// ───────────────────────── Glass bars ─────────────────────────

/**
 * iOS style floating tab bar (liquid glass — ported from tabbar.kt).
 *  - Tap or press-and-drag: the pill follows your finger with liquid stretch.
 *  - The selected tab lifts into a glass pill with a bright rim, chromatic ghosts
 *    and a live corner reflection on each of the four edges.
 *  - [selected] = -1 means no tab is selected (the search page is open): the pill fades out.
 */
@Composable
fun GlassTabBar(
    modifier: Modifier = Modifier,
    selected: Int,
    onSelect: (Int) -> Unit,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    navy: Boolean = false,
    onReselect: () -> Unit = {}
) {
    // The bar shows Songs, Artist, Albums, Profile, while the app's own tab numbers stay
    // 0 = Songs, 1 = Albums, 2 = Artists, 3 = Profile. This maps between the two.
    val order = listOf(0, 2, 1, 3)
    GlassTabBarImpl(
        modifier = modifier,
        selected = if (selected < 0) -1 else order.indexOf(selected),
        onSelect = { onSelect(order[it]) },
        p = p, photo = photo, profileName = profileName, navy = navy, onReselect = onReselect
    )
}

// ═══════════════════════════════════════════════════════════════
//  Liquid-glass Tab Bar (ported from tabbar.kt → 4 tabs, adapted)
// ═══════════════════════════════════════════════════════════════

private val TabBarLabels = listOf("Songs", "Artist", "Albums", "Profile")
private val TabBarLabelStyle = TextStyle(
    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White
)

private val TabBlue       = Color(0xFF0A84FF)
private val TabGhostR     = Color(0xFFFF3A3A)
private val TabGhostB     = Color(0xFF2FE0FF)
private val TabEdgeR      = Color(0xFFFF4040)
private val TabEdgeB      = Color(0xFF38DCFF)
private val TabEdgeLR     = Color(225, 235, 255, 77)   // rgba(225,235,255,.30)
private val TabEdgeTB     = Color(170, 205, 255, 41)   // rgba(170,205,255,.16)
private val TabBarIdle    = Color(36, 36, 38, 204)     // rgba(36,36,38,.8)
private val TabBarMoving  = Color(80, 80, 86, 128)     // rgba(80,80,86,.5)
private const val TabCount = 4

private fun parseTabIcon(d: String): Path =
    PathParser().parsePathString(d).toPath().apply { fillType = PathFillType.EvenOdd }

/** Note · Artist · Album · (Profile placeholder) — عکس پروفایل روی Canvas کشیده می‌شه. */
private fun buildTabIcons(): List<Path> = listOf(
    // music note
    parseTabIcon(
        "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 " +
        "4-1.79 4-4V7h4V3h-6z"
    ),
    // person
    parseTabIcon(
        "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4z" +
        "M12 14c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
    ),
    // album (circle + ring + dot)
    parseTabIcon(
        "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" +
        "M12 16.5c-2.49 0-4.5-2.01-4.5-4.5S9.51 7.5 12 7.5s4.5 2.01 4.5 4.5" +
        "-2.01 4.5-4.5 4.5z" +
        "M12 11c-.55 0-1 .45-1 1s.45 1 1 1 1-.45 1-1-.45-1-1-1z"
    ),
    Path() // unused (profile is drawn as a circular photo)
)

@Composable
private fun GlassTabBarImpl(
    modifier: Modifier = Modifier,
    selected: Int,
    onSelect: (Int) -> Unit,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    navy: Boolean = false,
    onReselect: () -> Unit = {}
) {
    @Suppress("UNUSED_PARAMETER") val unused = profileName

    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    val dens = density.density
    val barPadPx = with(density) { BarPad.toPx() }
    val icons = remember { buildTabIcons() }
    val labels = remember(measurer, navy) {
        if (navy) emptyList()
        else TabBarLabels.map { measurer.measure(it, TabBarLabelStyle, softWrap = false, maxLines = 1) }
    }
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnReselect by rememberUpdatedState(onReselect)

    val ctl = remember { BarCtl(if (selected >= 0) selected else 0) }
    val phys = remember { BarPhys() }
    val pillLeft = remember { Animatable(0f) }
    var mv by remember { mutableStateOf(false) }
    var widthPx by remember { mutableIntStateOf(0) }
    var kickKey by remember { mutableIntStateOf(0) }
    var initialPlaced by remember { mutableStateOf(false) }

    val pillAlpha by animateFloatAsState(
        if (selected >= 0 || ctl.held) 1f else 0f,
        tween(220), label = "pillAlpha"
    )

    // CSS easings (یکسان با tabbar.kt)
    val easeBar    = remember { CubicBezierEasing(.3f, 1.4f, .5f, 1f) }
    val easeBarOut = remember { CubicBezierEasing(.3f, 1.1f, .5f, 1f) }
    val easePill   = remember { CubicBezierEasing(.3f, 1.25f, .45f, 1f) }
    val easeIcon   = remember { CubicBezierEasing(.3f, 1.5f, .5f, 1f) }

    val barSx by animateFloatAsState(
        if (mv) 1.05f else 1f,
        if (mv) tween(400, easing = easeBar) else tween(200, easing = easeBarOut), label = "barSx"
    )
    val barSy by animateFloatAsState(
        if (mv) 1.09f else 1f,
        if (mv) tween(400, easing = easeBar) else tween(200, easing = easeBarOut), label = "barSy"
    )
    val pillSx by animateFloatAsState(
        if (mv) 1.17f else 1f,
        if (mv) tween(400, easing = easeBar) else tween(200, easing = easeBarOut), label = "pillSx"
    )
    val pillSy by animateFloatAsState(
        if (mv) 1.22f else 1f,
        if (mv) tween(400, easing = easeBar) else tween(200, easing = easeBarOut), label = "pillSy"
    )
    val barBgColor by animateColorAsState(
        if (mv) TabBarMoving else (if (navy) p.tabBarColor else TabBarIdle),
        tween(if (mv) 300 else 180), label = "barBg"
    )
    val glow   by animateFloatAsState(if (mv) 1f else 0f, tween(300), label = "glow")
    val pillBg by animateFloatAsState(if (mv) 0f else 1f, tween(if (mv) 300 else 180), label = "pillBg")
    val ghostA by animateFloatAsState(if (mv) .9f else 0f, tween(200), label = "ghostA")
    val edgeA  by animateFloatAsState(if (mv) 1f else 0f, tween(120), label = "edgeA")
    val iconS  by animateFloatAsState(if (mv) 1.1f else 1f, tween(400, easing = easeIcon), label = "iconS")

    fun tabW(): Float =
        if (widthPx > 0) (widthPx - 2f * (dens + barPadPx)) / TabCount else 0f
    fun tabLeft(i: Int): Float = dens + barPadPx + i * tabW()

    fun kick(ms: Long = 900L) {
        ctl.until = System.nanoTime() / 1_000_000L + ms
        kickKey++
    }

    fun follow(x: Float) {
        val w = tabW(); if (w <= 0f) return
        val left = (x - w / 2f).coerceIn(dens + barPadPx, widthPx - dens - barPadPx - w)
        val ld = left / dens
        ctl.lastLeft?.let { phys.vs = phys.vs * .6f + (ld - it) * .4f }
        ctl.lastLeft = ld
        if (ctl.drag) scope.launch { pillLeft.snapTo(left) }
        else scope.launch { pillLeft.animateTo(left, tween(450, easing = easePill)) }
        val idx = floor((left + w / 2f - dens - barPadPx) / w).toInt().coerceIn(0, TabCount - 1)
        if (idx != ctl.near) {
            ctl.near = idx
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    // اگر از بیرون selected عوض شد، پیل رو نرم ببر
    LaunchedEffect(selected) {
        if (selected >= 0 && selected != ctl.cur && !ctl.held && initialPlaced) {
            ctl.cur = selected
            ctl.near = selected
            scope.launch { pillLeft.animateTo(tabLeft(selected), tween(450, easing = easePill)) }
        }
    }

    // اولین چیدمان
    LaunchedEffect(widthPx) {
        if (widthPx > 0 && !initialPlaced) {
            initialPlaced = true
            val start = if (selected >= 0) selected else ctl.cur
            ctl.cur = start; ctl.near = start
            pillLeft.snapTo(tabLeft(start))
        }
    }

    // Physics loop (همون JS loop)
    LaunchedEffect(kickKey) {
        var last = 0L
        while (true) {
            val t = withFrameNanos { it }
            val dt = if (last == 0L) 1f / 60f else ((t - last) / 1e9f).coerceIn(.004f, .05f)
            last = t
            phys.step(dt, (t / 1_000_000L).toFloat(), ctl.held)
            val nowMs = System.nanoTime() / 1_000_000L
            if (!(nowMs < ctl.until || ctl.held || phys.active())) break
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(if (navy) 56.dp else BarHeight)
            .onSizeChanged { widthPx = it.width }
            .graphicsLayer {
                scaleX = barSx; scaleY = barSy
                shadowElevation = (10f + 6f * glow) * dens
                shape = RoundedCornerShape(if (navy) 28.dp else 36.dp)
                clip = false
                ambientShadowColor = Color.Black.copy(alpha = .6f)
                spotShadowColor = Color.Black.copy(alpha = .6f)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    // ── down ──
                    ctl.held = true; ctl.lastLeft = null; phys.vs = 0f
                    mv = true
                    follow(down.position.x)
                    kick()
                    ctl.drag = false
                    ctl.dragJob?.cancel()
                    ctl.dragJob = scope.launch { delay(200); if (ctl.held) ctl.drag = true }

                    var wasMoved = false
                    var released = false
                    while (!released) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) { released = true; break }
                        if (abs(ch.position.x - down.position.x) > 24f) wasMoved = true
                        follow(ch.position.x)
                        ch.consume()
                    }
                    // ── release ──
                    ctl.held = false
                    ctl.dragJob?.cancel(); ctl.drag = false
                    val newCur = ctl.near
                    val wasCur = ctl.cur
                    ctl.cur = newCur
                    scope.launch { pillLeft.animateTo(tabLeft(newCur), tween(450, easing = easePill)) }
                    kick()
                    scope.launch { delay(90); if (!ctl.held) mv = false }
                    if (newCur != wasCur) currentOnSelect(newCur)
                    else if (!wasMoved) currentOnReselect()
                }
            }
    ) {
        // داخل DrawScope خودش Density است → toPx() مستقیم مجاز است
        val d = density
        val w = size.width
        val h = size.height
        val b = d
        val pad = BarPad.toPx()
        val tabW = (w - 2f * b - 2f * pad) / TabCount
        val tabH = h - 2f * b - 2f * pad
        val tabTop = b + pad
        val iconSz = 26f * d
        val gap = 3f * d
        val textH = labels.firstOrNull()?.size?.height?.toFloat() ?: 0f
        val blockH = iconSz + (if (labels.isNotEmpty()) gap + textH else 0f)
        val iconTop = (tabH - blockH) / 2f
        val g = TabGeo(d, tabW, tabH, iconSz, gap, iconTop, iconTop + blockH, icons, labels)

        val pl = pillLeft.value
        val ox = b + pad - pl
        val barR = 36f * d
        val barPath = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(barR))) }

        // 1) glass body
        drawRoundRect(barBgColor, cornerRadius = CornerRadius(barR))

        // 2) moving glow
        if (glow > .004f) {
            clipPath(barPath) {
                withTransform({
                    translate(pl + tabW / 2f, h / 2f)
                    scale(1f, 60f / 90f, Offset.Zero)
                }) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            0f to Color(215, 215, 225, 107),
                            .55f to Color(150, 150, 160, 46),
                            1f to Color.Transparent,
                            center = Offset.Zero, radius = 90f * d
                        ),
                        radius = 90f * d, center = Offset.Zero, alpha = glow
                    )
                }
            }
        }

        // 3) border + inset top highlight
        drawRoundRect(
            Color.White.copy(alpha = .2f),
            topLeft = Offset(b / 2f, b / 2f), size = Size(w - b, h - b),
            cornerRadius = CornerRadius(barR - b / 2f), style = Stroke(b)
        )
        val inner = Path().apply { addRoundRect(RoundRect(b, b, w - b, h - b, CornerRadius(barR - b))) }
        val innerDown = Path().apply { addRoundRect(RoundRect(b, b + d, w - b, h - b + d, CornerRadius(barR - b))) }
        clipPath(inner) {
            clipPath(innerDown, ClipOp.Difference) {
                drawRect(Color.White.copy(alpha = .12f + .18f * glow))
            }
        }

        // 4) base (white) tabs + hole where pill sits
        tabLayer(Rect(0f, 0f, w, h)) {
            drawTabRow(g, b + pad, Color.White, 1f, null, photo)
            if (pillAlpha > .01f) {
                val pcx = pl + tabW / 2f
                val pcy = tabTop + tabH / 2f
                val hw = tabW * pillSx
                val hh = tabH * pillSy
                drawRoundRect(
                    Color.Black,
                    topLeft = Offset(pcx - hw / 2f, pcy - hh / 2f), size = Size(hw, hh),
                    cornerRadius = CornerRadius(
                        min(tabH / 2f * pillSx, hw / 2f),
                        min(tabH / 2f * pillSy, hh / 2f)
                    ),
                    blendMode = BlendMode.Clear
                )
            }
        }

        // 5) pill
        if (pillAlpha > .01f) {
            val aL = FloatArray(TabCount); val aR = FloatArray(TabCount)
            for (j in 0 until TabCount) {
                val s = ox + j * tabW + tabW / 2f
                aL[j] = ((.5f * tabW - s) / (.35f * tabW)).coerceIn(0f, 1f)
                aR[j] = ((.5f * tabW - (tabW - s)) / (.35f * tabW)).coerceIn(0f, 1f)
            }
            val ctx = TabCtx(
                g, ox, phys.sl, phys.sr, phys.sh, phys.wob,
                iconS, ghostA, edgeA, pillBg, pillAlpha, aL, aR, photo
            )
            withTransform({
                translate(pl + tabW / 2f, tabTop + tabH / 2f)
                scale(pillSx, pillSy, Offset.Zero)
                translate(-tabW / 2f, -tabH / 2f)
            }) { drawTabPill(ctx) }
        }
    }
}

// ─────────────────────────── State holders ───────────────────────────

private class BarCtl(var cur: Int) {
    var near = cur
    var held = false
    var drag = false
    var lastLeft: Float? = null
    var until = 0L
    var dragJob: Job? = null
}

private class BarPhys {
    var vs = 0f
    var sl by mutableFloatStateOf(0f)
    var sr by mutableFloatStateOf(0f)
    var sh by mutableFloatStateOf(0f)
    var wob by mutableFloatStateOf(0f)
    fun step(dt: Float, ms: Float, held: Boolean) {
        val k = dt * 60f
        vs *= .9f.pow(k)
        val tl = (-vs / 6f).coerceIn(0f, 1f)
        val tr = (vs / 6f).coerceIn(0f, 1f)
        val f = 1f - .75f.pow(k)
        sl = settle(sl + (tl - sl) * f)
        sr = settle(sr + (tr - sr) * f)
        sh = settle((sh * .92f.pow(k) + vs * .12f * k).coerceIn(-12f, 12f))
        wob = if (held) sin(ms * .008f) * 2.2f else settle(wob * .85f.pow(k))
    }
    fun active() = sl > .01f || sr > .01f || abs(sh) > .05f || abs(wob) > .05f
    private fun settle(v: Float) = if (abs(v) < 5e-4f) 0f else v
}

private class TabGeo(
    val d: Float, val tabW: Float, val tabH: Float,
    val iconSz: Float, val gap: Float, val iconTop: Float, val textBottom: Float,
    val icons: List<Path>, val labels: List<TextLayoutResult>
) { val count get() = TabCount }

private class TabCtx(
    val g: TabGeo, val ox: Float,
    val sl: Float, val sr: Float, val sh: Float, val wob: Float,
    val iconScale: Float, val ghostA: Float, val edgeA: Float,
    val pillBg: Float, val pillAlpha: Float,
    val alphasL: FloatArray, val alphasR: FloatArray,
    val photo: ImageBitmap?
)

// ─────────────────────────── Drawing helpers ───────────────────────────

private fun DrawScope.tabLayer(
    bounds: Rect,
    alpha: Float = 1f,
    blend: BlendMode = BlendMode.SrcOver,
    block: DrawScope.() -> Unit
) {
    drawIntoCanvas { canvas ->
        val paint = Paint().apply { this.alpha = alpha; blendMode = blend }
        canvas.saveLayer(bounds, paint)
        block()
        canvas.restore()
    }
}

private fun DrawScope.drawTabRow(
    g: TabGeo, ox: Float, color: Color, iconScale: Float,
    alphas: FloatArray?, photo: ImageBitmap?
) {
    for (i in 0 until g.count) {
        val a = (alphas?.get(i) ?: 1f) * color.alpha
        if (a <= .003f) continue
        val left = ox + i * g.tabW
        val cx = left + g.tabW / 2f
        val cy = g.iconTop + g.iconSz / 2f

        if (i == g.count - 1) {
            drawTabAvatar(photo, cx, cy, (g.iconSz / 2f) * iconScale, a)
        } else {
            val icon = g.icons[i]
            if (icon != null && !icon.isEmpty) {
                withTransform({
                    translate(left + (g.tabW - g.iconSz) / 2f, g.iconTop)
                    scale(iconScale, iconScale, Offset(g.iconSz / 2f, g.iconSz / 2f))
                    scale(g.iconSz / 24f, g.iconSz / 24f, Offset.Zero)
                }) { drawPath(icon, color.copy(alpha = a)) }
            }
        }

        if (i < g.labels.size) {
            val tl = g.labels[i]
            drawText(
                tl, color = color.copy(alpha = a),
                topLeft = Offset(left + (g.tabW - tl.size.width) / 2f, g.iconTop + g.iconSz + g.gap)
            )
        }
    }
}

private fun DrawScope.drawTabAvatar(
    photo: ImageBitmap?, cx: Float, cy: Float, radius: Float, alpha: Float
) {
    val circle = Path().apply {
        addOval(Rect(Offset(cx - radius, cy - radius), Size(radius * 2, radius * 2)))
    }
    clipPath(circle) {
        if (photo != null) {
            val pw = photo.width.toFloat(); val ph = photo.height.toFloat()
            val side = min(pw, ph)
            val sx = ((pw - side) / 2f).toInt()
            val sy = ((ph - side) / 2f).toInt()
            drawImage(
                image = photo,
                srcOffset = IntOffset(sx, sy),
                srcSize = IntSize(side.toInt(), side.toInt()),
                dstOffset = IntOffset((cx - radius).toInt(), (cy - radius).toInt()),
                dstSize = IntSize((radius * 2).toInt(), (radius * 2).toInt()),
                alpha = alpha,
                filterQuality = FilterQuality.High
            )
        } else {
            drawCircle(Color(0xFF3B3B3E), radius, Offset(cx, cy), alpha = alpha)
        }
    }
    drawCircle(
        Color.White.copy(alpha = .45f * alpha),
        radius, Offset(cx, cy), style = Stroke(1.5f * density)
    )
}

private fun DrawScope.tabEllipseMask(w: Float, h: Float, inner: Float, outer: Float) {
    withTransform({
        translate(w / 2f, h / 2f)
        scale(1f, h / w, Offset.Zero)
    }) {
        drawCircle(
            brush = Brush.radialGradient(
                inner to Color.Transparent, outer to Color.Black,
                center = Offset.Zero, radius = w / 2f
            ),
            radius = w * 2f, center = Offset.Zero, blendMode = BlendMode.DstIn
        )
    }
}

private fun DrawScope.tabMaskRect(r: Rect, brush: Brush) =
    drawRect(brush, r.topLeft, r.size, blendMode = BlendMode.DstIn)

private fun DrawScope.tabEdgeLayer(
    r: Rect, alpha: Float,
    content: DrawScope.() -> Unit,
    mask: DrawScope.() -> Unit
) {
    tabLayer(r, alpha) {
        clipRect(r.left, r.top, r.right, r.bottom) { content() }
        mask()
    }
}

private fun DrawScope.tabScreenRow(
    g: TabGeo, bounds: Rect, ox: Float, color: Color,
    alphas: FloatArray? = null, photo: ImageBitmap?,
    t: DrawTransform.() -> Unit
) {
    tabLayer(bounds, 1f, BlendMode.Screen) {
        withTransform(t) { drawTabRow(g, ox, color.copy(alpha = .95f), 1f, alphas, photo) }
    }
}

private fun DrawScope.drawTabPill(c: TabCtx) {
    val g = c.g
    val w = g.tabW; val h = g.tabH
    val full = Rect(0f, 0f, w, h)
    val pillPath = Path().apply {
        addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(min(30f * g.d, min(w, h) / 2f))))
    }
    clipPath(pillPath) {
        if (c.pillBg * c.pillAlpha > .004f) {
            drawRect(Color.White.copy(alpha = .1f * c.pillBg * c.pillAlpha), size = Size(w, h))
        }
        if (c.ghostA * c.pillAlpha > .004f) {
            val k = max(c.sl, c.sr)
            val gx = (.6f + 1.3f * k) * g.d
            val gy = (.25f + .35f * k) * g.d
            tabLayer(full, c.ghostA * c.pillAlpha) {
                tabLayer(full, 1f, BlendMode.Screen) {
                    translate(-gx, -gy) { drawTabRow(g, c.ox, TabGhostR, c.iconScale, null, c.photo) }
                }
                tabLayer(full, 1f, BlendMode.Screen) {
                    translate(gx, gy) { drawTabRow(g, c.ox, TabGhostB, c.iconScale, null, c.photo) }
                }
                tabEllipseMask(w, h, .58f, .96f)
            }
        }
        // blue active tabs
        drawTabRow(g, c.ox, TabBlue.copy(alpha = c.pillAlpha), c.iconScale, null, c.photo)

        if (c.edgeA * c.pillAlpha > .004f) drawTabEdges(c)
    }
}

private fun DrawScope.drawTabEdges(c: TabCtx) {
    val g = c.g; val d = g.d
    val w = g.tabW; val h = g.tabH
    val ea = c.edgeA * c.pillAlpha
    val dd = (1.6f + 4.5f * max(c.sl, c.sr)) * d
    val ewl = (10f + 14f * c.sl) * d
    val ewr = (10f + 14f * c.sr) * d
    val ext = 7f * d
    val lp = -c.ox + (c.sh + c.wob) * d
    val rp = -c.ox + 2f * w + (c.sh - c.wob) * d
    val it = g.iconTop; val tb = g.textBottom
    val photo = c.photo

    // ── left edge ──
    val rl = Rect(0f, 0f, ewl, h)
    tabEdgeLayer(rl, ea * (.6f + .4f * c.sl), {
        drawRect(TabEdgeLR, size = rl.size)
        tabScreenRow(g, rl, 0f, TabEdgeR, photo = photo) { translate(lp - dd, 0f); scale(-1f, 1f, Offset.Zero) }
        tabScreenRow(g, rl, 0f, TabEdgeB, photo = photo) { translate(lp + dd, 0f); scale(-1f, 1f, Offset.Zero) }
    }) {
        tabMaskRect(rl, Brush.horizontalGradient(
            0f to Color.Black, .15f to Color.Black, 1f to Color.Transparent,
            startX = rl.left, endX = rl.right
        ))
    }

    // ── right edge ──
    val rr = Rect(w - ewr, 0f, w, h)
    tabEdgeLayer(rr, ea * (.6f + .4f * c.sr), {
        drawRect(TabEdgeLR, topLeft = rr.topLeft, size = rr.size)
        tabScreenRow(g, rr, 0f, TabEdgeR, photo = photo) { translate(rp - dd, 0f); scale(-1f, 1f, Offset.Zero) }
        tabScreenRow(g, rr, 0f, TabEdgeB, photo = photo) { translate(rp + dd, 0f); scale(-1f, 1f, Offset.Zero) }
    }) {
        tabMaskRect(rr, Brush.horizontalGradient(
            0f to Color.Transparent, .85f to Color.Black, 1f to Color.Black,
            startX = rr.left, endX = rr.right
        ))
    }

    // ── top edge: reflection of icon top ──
    val rt = Rect(0f, 0f, w, it + ext)
    tabEdgeLayer(rt, ea * .85f, {
        drawRect(TabEdgeTB, size = rt.size)
        tabScreenRow(g, rt, c.ox, TabEdgeR, photo = photo) { translate(0f, 2f * it - dd); scale(1f, -1f, Offset.Zero) }
        tabScreenRow(g, rt, c.ox, TabEdgeB, photo = photo) { translate(0f, 2f * it + dd); scale(1f, -1f, Offset.Zero) }
    }) {
        tabMaskRect(rt, Brush.verticalGradient(
            0f to Color.Black, .45f to Color.Black, 1f to Color.Transparent,
            startY = rt.top, endY = rt.bottom
        ))
    }

    // ── bottom edge: reflection of label bottom ──
    val rb = Rect(0f, max(0f, tb - ext), w, h)
    tabEdgeLayer(rb, ea * .85f, {
        drawRect(TabEdgeTB, topLeft = rb.topLeft, size = rb.size)
        tabScreenRow(g, rb, c.ox, TabEdgeR, photo = photo) { translate(0f, 2f * tb - dd); scale(1f, -1f, Offset.Zero) }
        tabScreenRow(g, rb, c.ox, TabEdgeB, photo = photo) { translate(0f, 2f * tb + dd); scale(1f, -1f, Offset.Zero) }
    }) {
        tabMaskRect(rb, Brush.verticalGradient(
            0f to Color.Transparent, .55f to Color.Black, 1f to Color.Black,
            startY = rb.top, endY = rb.bottom
        ))
    }

    // ── four live corner reflections ──
    val pvL = (10f + 5f * c.sl + c.sh * .5f) * d
    val pvR = w - (10f + 5f * c.sr) * d + c.sh * .5f * d
    val yt = it + 6f * d
    val yb = tb - 6f * d
    val full = Rect(0f, 0f, w, h)

    for (k in 0 until 4) {
        val left = k % 2 == 0
        val top = k < 2
        val cx = if (left) pvL else pvR
        val cy = if (top) yt else yb
        val alphas = if (left) c.alphasL else c.alphasR
        val diag = (left == top)
        val sx = .7f * dd
        val crDx = if (diag) -sx else sx
        val cbDx = -crDx
        val crDy = -sx
        val cbDy = sx

        tabEdgeLayer(full, ea * .85f, {
            tabScreenRow(g, full, c.ox, TabEdgeR, alphas, photo) {
                translate(2f * cx + crDx, 2f * cy + crDy); scale(-1f, -1f, Offset.Zero)
                clipRect(0f, 0f, w, h)
            }
            tabScreenRow(g, full, c.ox, TabEdgeB, alphas, photo) {
                translate(2f * cx + cbDx, 2f * cy + cbDy); scale(-1f, -1f, Offset.Zero)
                clipRect(0f, 0f, w, h)
            }
        }) {
            tabEllipseMask(w, h, .52f, .90f)
            tabMaskRect(full, if (left) Brush.horizontalGradient(
                0f to Color.Black, .06f to Color.Black, .5f to Color.Transparent, 1f to Color.Transparent
            ) else Brush.horizontalGradient(
                0f to Color.Transparent, .5f to Color.Transparent, .94f to Color.Black, 1f to Color.Black
            ))
            tabMaskRect(full, if (top) Brush.verticalGradient(
                0f to Color.Black, .06f to Color.Black, .5f to Color.Transparent, 1f to Color.Transparent
            ) else Brush.verticalGradient(
                0f to Color.Transparent, .5f to Color.Transparent, .94f to Color.Black, 1f to Color.Black
            ))
        }
    }
}

/**
 * Near-black glass pill (used by MiniTabPill and SearchButton): a dark, almost opaque body,
 * a thin light rim and a soft shadow.
 */
internal fun Modifier.iosGlass(shape: Shape, solid: Color? = null): Modifier =
    this
        .shadow(16.dp, shape, ambientColor = Color.Black.copy(alpha = 0.45f), spotColor = Color.Black.copy(alpha = 0.45f))
        .clip(shape)
        .background(
            if (solid != null) Brush.verticalGradient(listOf(solid, solid))
            else Brush.verticalGradient(listOf(Color(0xFF1E1E21).copy(alpha = 0.97f), Color(0xFF0C0C0E).copy(alpha = 0.97f)))
        )
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.18f))),
            shape
        )

val BarHeight = 72.dp
/** Total height of the white mini player card, and how much of its bottom the tab bar covers. */
val MiniCardHeight = 96.dp
val MiniCardHidden = 34.dp
private val BarPad = 6.dp

/** Tapping the selected tab again bumps this; every tab screen listens and scrolls to the top. */
object ScrollTop { var tick by mutableIntStateOf(0) }

@Composable
fun ScrollTopEffect(scroll: suspend () -> Unit) {
    val seen = remember { ScrollTop.tick }
    LaunchedEffect(ScrollTop.tick) { if (ScrollTop.tick != seen) scroll() }
}

/**
 * Small glass pill that replaces the tab bar while you scroll down (like the minimized iOS 26 tab bar).
 * [visible] goes 0..1 with the bar's hide animation. Tap it to bring the full bar back.
 */
@Composable
fun MiniTabPill(
    modifier: Modifier = Modifier,
    visible: Float,
    selected: Int,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    onClick: () -> Unit
) {
    if (visible <= 0.01f) return
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        if (pressed) 0.88f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "miniPillPress"
    )
    val haptic = LocalHapticFeedback.current
    val onClickS by rememberUpdatedState(onClick)
    val glyphs = listOf(Glyph.Note, Glyph.Album, Glyph.Artist)
    Box(
        modifier
            .size(56.dp)
            .graphicsLayer {
                alpha = visible
                val s = (0.6f + 0.4f * visible) * press
                scaleX = s
                scaleY = s
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
            }
            .iosGlass(CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClickS()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (selected == 3) {
            Avatar(
                photo, profileName, p,
                Modifier.size(30.dp).border(1.5.dp, p.accent, CircleShape),
                14.sp
            )
        } else {
            GlyphIcon(glyphs.getOrElse(selected.coerceAtLeast(0)) { Glyph.Note }, p.accent, Modifier.size(24.dp))
        }
    }
}

/** Round glass search button that sits next to the tab bar (like the iOS tab bar). */
@Composable
fun SearchButton(active: Boolean, p: Palette, onClick: () -> Unit, navy: Boolean = false) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.88f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 450f),
        label = "searchScale"
    )
    val tint by animateColorAsState(if (active) p.accent else if (navy) p.onTabBar else Color.White, label = "searchTint")
    val onClickS by rememberUpdatedState(onClick)
    Box(
        Modifier
            .size(if (navy) 56.dp else BarHeight)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .iosGlass(CircleShape, if (navy) p.tabBarColor else null)
            .background(if (active) p.accent.copy(alpha = 0.22f) else Color.Transparent, CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClickS() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(Glyph.Search, tint, Modifier.size(24.dp))
    }
}

fun formatTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}


/**
 * Dynamic Island: pure black pill (like the real iPhone one).
 *  - Tap the pill: it grows with a springy, staggered animation into a control panel.
 *  - The expanded panel shows cover, title, a live progress bar and round, press-reactive buttons.
 *  - Content fades/slides in after the shape has started growing, and fades out before it shrinks.
 */
@Composable
fun TopIsland(
    song: Song,
    p: Palette,
    isPlaying: Boolean,
    isFav: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onFav: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    modifier: Modifier = Modifier,
    islandWidthDp: Int = 250,
    islandHeightDp: Int = 36,
    position: Long = 0L,
    reserveTop: Boolean = true,
    onSeek: (Long) -> Unit = {},
    onOpenPlayer: () -> Unit = {},
    expanded: Boolean = false,
    onExpandedChange: (Boolean) -> Unit = {},
    onLongPress: () -> Unit = {},
    sleepActive: Boolean = false
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val statusH = with(density) { WindowInsets.statusBarsIgnoringVisibility.getTop(density).toDp() }
    val pillH = islandHeightDp.dp
    val top = ((statusH - pillH) / 2).coerceAtLeast(4.dp)
    val pop = remember { Animatable(1f) }
    val longPressS by rememberUpdatedState(onLongPress)

    // 0f = compact pill, 1f = expanded panel. One spring drives size, corner, shadow and content.
    val t by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 300f),
        label = "islandT"
    )
    // when the song changes the compact pill briefly swells, like the real Dynamic Island
    val bump = remember { Animatable(0f) }
    var firstSong by remember { mutableStateOf(true) }
    LaunchedEffect(song.id) {
        if (firstSong) {
            firstSong = false
        } else {
            bump.snapTo(0f)
            bump.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 260f))
            kotlinx.coroutines.delay(900)
            bump.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 220f))
        }
    }
    val bumpNow = (bump.value * (1f - t)).coerceAtLeast(0f)
    val width = androidx.compose.ui.unit.lerp(islandWidthDp.dp, 340.dp, t) + 44.dp * bumpNow
    val height = androidx.compose.ui.unit.lerp(pillH, 168.dp, t) + 8.dp * bumpNow
    val corner = androidx.compose.ui.unit.lerp(pillH / 2, 34.dp, t.coerceIn(0f, 1f))
    val shape = RoundedCornerShape(corner)

    // the content of the panel appears a bit after the shape starts to grow
    val contentAlpha by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = if (expanded) tween(260, delayMillis = 110, easing = FastOutSlowInEasing) else tween(90),
        label = "islandContentAlpha"
    )
    val compactAlpha by animateFloatAsState(
        targetValue = if (expanded) 0f else 1f,
        animationSpec = if (expanded) tween(90) else tween(220, delayMillis = 140),
        label = "islandCompactAlpha"
    )

    LaunchedEffect(song.id) {
        pop.snapTo(1.05f)
        pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 380f))
    }

    val wave = rememberInfiniteTransition(label = "islandWave")
    val wavePhase by wave.animateFloat(
        initialValue = 0.55f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(620, easing = LinearEasing), RepeatMode.Reverse),
        label = "wavePhase"
    )

    // press feedback on the whole pill
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        if (pressed) 0.96f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "islandPress"
    )

    Box(modifier.fillMaxWidth().padding(top = if (reserveTop) top else 0.dp), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier
                .graphicsLayer {
                    val s = pop.value * (if (expanded) 1f else press)
                    scaleX = s; scaleY = s
                    // the big panel drops lower on the screen while it grows
                    translationY = 56.dp.toPx() * t
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                }
                .width(width)
                .height(height)
                .shadow(
                    elevation = 6.dp + 18.dp * t, shape = shape,
                    ambientColor = Color.Black, spotColor = Color.Black
                )
                .clip(shape)
                .background(Color.Black)
                .border(1.dp, Color.White.copy(alpha = 0.08f + 0.05f * t), shape)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onExpandedChange(!expanded)
                        },
                        onLongPress = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            longPressS()
                        }
                    )
                }
        ) {
            // ───────── compact pill ─────────
            if (compactAlpha > 0.01f) {
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .height(pillH)
                        .padding(horizontal = 5.dp)
                        .graphicsLayer { alpha = compactAlpha },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Cover(song, Modifier.size((islandHeightDp - 8).coerceAtLeast(20).dp), 0.dp, p, 200, round = true)
                    Spacer(Modifier.weight(1f))
                    if (sleepActive) {
                        GlyphIcon(Glyph.Moon, Color(0xFF0A84FF), Modifier.size(13.dp))
                        Spacer(Modifier.width(6.dp))
                    }
                    IslandWave(isPlaying, wavePhase, Color.White, 0.85f)
                    Spacer(Modifier.width(6.dp))
                }
            }

            // ───────── expanded panel ─────────
            if (contentAlpha > 0.01f) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                        .graphicsLayer {
                            alpha = contentAlpha
                            translationY = (1f - contentAlpha) * -10.dp.toPx()
                        },
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // header: cover · title/artist · wave
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Cover(song, Modifier.size(46.dp), 12.dp, p, 300)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                song.title, color = Color.White, fontSize = 15.sp,
                                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                song.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        IslandWave(isPlaying, wavePhase, Color.White, 1f)
                        Spacer(Modifier.width(10.dp))
                        Box(
                            Modifier.size(34.dp).clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.16f))
                                .clickable {
                                    onExpandedChange(false)
                                    onOpenPlayer()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            GlyphIcon(Glyph.ChevronDown, Color.White, Modifier.size(20.dp).graphicsLayer { rotationZ = 180f })
                        }
                    }

                    // progress
                    val dur = song.durationMs
                    var dragFrac by remember { mutableStateOf<Float?>(null) }
                    val liveFrac = if (dur > 0) (position.toFloat() / dur).coerceIn(0f, 1f) else 0f
                    val frac = dragFrac ?: liveFrac
                    val shownMs = if (dragFrac != null) (frac * dur).toLong() else position
                    val seekS by rememberUpdatedState(onSeek)
                    Column {
                        Box(
                            Modifier.fillMaxWidth().height(24.dp)
                                .pointerInput(dur) {
                                    detectTapGestures { o ->
                                        if (dur > 0 && size.width > 0) {
                                            seekS((o.x / size.width).coerceIn(0f, 1f).times(dur).toLong())
                                        }
                                    }
                                }
                                .pointerInput(dur) {
                                    detectHorizontalDragGestures(
                                        onDragStart = { o ->
                                            if (size.width > 0) dragFrac = (o.x / size.width).coerceIn(0f, 1f)
                                        },
                                        onHorizontalDrag = { change, _ ->
                                            change.consume()
                                            if (size.width > 0) dragFrac = (change.position.x / size.width).coerceIn(0f, 1f)
                                        },
                                        onDragEnd = {
                                            dragFrac?.let { if (dur > 0) seekS((it * dur).toLong()) }
                                            dragFrac = null
                                        },
                                        onDragCancel = { dragFrac = null }
                                    )
                                },
                            contentAlignment = Alignment.CenterStart
                        ) {
                            val barH by animateDpAsState(if (dragFrac != null) 8.dp else 4.dp, tween(150), label = "islandBarH")
                            Box(
                                Modifier.fillMaxWidth().height(barH)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White.copy(alpha = 0.18f))
                            ) {
                                Box(
                                    Modifier.fillMaxHeight().fillMaxWidth(frac)
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.White)
                                )
                            }
                        }
                        Row(Modifier.fillMaxWidth()) {
                            Text(formatTime(shownMs), color = Color.White.copy(alpha = if (dragFrac != null) 1f else 0.5f), fontSize = 10.sp)
                            Spacer(Modifier.weight(1f))
                            Text("-" + formatTime((dur - shownMs).coerceAtLeast(0L)), color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                        }
                    }

                    // controls
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IslandButton(Glyph.Shuffle, if (shuffle) p.accent else Color.White.copy(alpha = 0.55f), 38.dp, 18.dp, onShuffle)
                        IslandButton(Glyph.Prev, Color.White, 42.dp, 21.dp, onPrev)
                        IslandButton(
                            if (isPlaying) Glyph.Pause else Glyph.Play, Color.Black, 54.dp, 24.dp, onToggle,
                            filled = Color.White
                        )
                        IslandButton(Glyph.Next, Color.White, 42.dp, 21.dp, onNext)
                        IslandButton(
                            Glyph.Repeat,
                            if (repeatMode != Player.REPEAT_MODE_OFF) p.accent else Color.White.copy(alpha = 0.55f),
                            38.dp, 18.dp, onRepeat
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IslandWave(playing: Boolean, phase: Float, color: Color, alpha: Float) {
    val rest by animateFloatAsState(if (playing) 1f else 0f, tween(300), label = "islandWaveRest")
    Row(
        Modifier.height(18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(5) { i ->
            val base = listOf(5, 11, 7, 15, 8)[i].toFloat()
            val h = 3f + (base * phase * (if (i % 2 == 0) 1f else 0.82f) - 3f) * rest
            Box(
                Modifier.width(2.5.dp).height(h.coerceAtLeast(3f).dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color.copy(alpha = alpha * (0.5f + 0.5f * rest)))
            )
        }
    }
}

/** Round island button: shrinks while pressed and springs back, with a soft pressed highlight. */
@Composable
private fun IslandButton(
    glyph: Glyph,
    color: Color,
    size: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    filled: Color? = null
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 600f),
        label = "islandBtnScale"
    )
    val glow by animateFloatAsState(if (pressed) 1f else 0f, tween(120), label = "islandBtnGlow")
    val onClickS by rememberUpdatedState(onClick)
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(filled ?: Color.White.copy(alpha = 0.14f * glow))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClickS() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(glyph, color, Modifier.size(iconSize))
    }
}