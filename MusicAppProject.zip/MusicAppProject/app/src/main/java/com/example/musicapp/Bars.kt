@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.musicapp

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.MarqueeSpacing
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.media3.common.Player
import kotlin.math.abs
import kotlin.math.roundToInt

// ───────────────────────── Glass bars ─────────────────────────

/**
 * iOS style floating tab bar (liquid glass).
 *  - A glass capsule with a bigger profile photo.
 *  - Hold the bar: the selected spot lifts into a glass lens that wraps the icon,
 *    with a bright rim, a soft glow around it, and icons near it grow like a dock.
 *  - Swipe left or right: the lens follows your finger (liquid stretch) and the tab changes live.
 *  - [selected] = -1 means no tab is selected (the search page is open): the lens fades out.
 */
@Composable
fun GlassTabBar(
    modifier: Modifier = Modifier,
    selected: Int,
    onSelect: (Int) -> Unit,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    navy: Boolean = false,
    onReselect: () -> Unit = {}
) {
    // The bar shows Songs, Artist, Albums, Profile, while the app's own tab numbers stay
    // 0 = Songs, 1 = Albums, 2 = Artists, 3 = Profile. This maps between the two.
    val order = listOf(0, 2, 1, 3)
    GlassTabBarImpl(
        modifier = modifier,
        selected = if (selected < 0) -1 else order.indexOf(selected),
        onSelect = { onSelect(order[it]) },
        p = p, photo = photo, profileName = profileName, navy = navy, onReselect = onReselect
    )
}

@Composable
private fun GlassTabBarImpl(
    modifier: Modifier = Modifier,
    selected: Int,
    onSelect: (Int) -> Unit,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    navy: Boolean = false,   // compact icon-only pill in the theme colour
    onReselect: () -> Unit = {}   // tapped the tab that is already selected
) {
    val tabs = listOf(
        "Songs" to Glyph.Note,
        "Artist" to Glyph.Artist,
        "Albums" to Glyph.Album,
        "Profile" to Glyph.Artist
    )
    val count = tabs.size
    val barH = if (navy) 56.dp else BarHeight
    val barShape = RoundedCornerShape(if (navy) 28.dp else 32.dp)
    val lensShape = RoundedCornerShape(if (navy) 24.dp else 28.dp)
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val padPx = with(density) { BarPad.toPx() }

    val currentSelected by rememberUpdatedState(selected)
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnReselect by rememberUpdatedState(onReselect)
    val widthState = remember { mutableIntStateOf(0) }
    var dragging by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var fingerX by remember { mutableFloatStateOf(0f) }

    val innerW = (widthState.intValue - 2 * padPx).coerceAtLeast(0f)
    val itemW = if (innerW > 0f) innerW / count else 0f

    // where the lens wants to be, measured from the inner left edge
    val targetX = if (dragging && itemW > 0f)
        (fingerX - padPx - itemW / 2f).coerceIn(0f, itemW * (count - 1))
    else selected.coerceAtLeast(0) * itemW

    val lensX by animateFloatAsState(
        targetX,
        if (dragging) spring(dampingRatio = 0.8f, stiffness = 900f)
        else spring(dampingRatio = 0.62f, stiffness = 420f),
        label = "lensX"
    )
    val lift by animateFloatAsState(
        if (dragging || pressed) 1f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 360f),
        label = "lift"
    )
    val lensAlpha by animateFloatAsState(
        if (selected >= 0) 1f else 0f,
        spring(dampingRatio = 1f, stiffness = 500f),
        label = "lensAlpha"
    )

    // 0 = lens is between two options, 1 = lens is exactly on an option
    val nearOption = if (itemW > 0f) {
        val f = lensX / itemW
        (1f - abs(f - f.roundToInt()) * 2f).coerceIn(0f, 1f)
    } else 1f
    val rimColor = androidx.compose.ui.graphics.lerp(Color.White, p.accent, nearOption)

    fun indexAt(x: Float): Int {
        if (itemW <= 0f) return 0
        return ((x - padPx) / itemW).toInt().coerceIn(0, count - 1)
    }

    Box(
        modifier
            .height(barH)
            .onSizeChanged { widthState.intValue = it.width }
            .graphicsLayer {
                // the whole bar swells under your finger like a drop of liquid
                scaleX = 1f + 0.06f * lift
                scaleY = 1f + 0.04f * lift
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    // touching the bar grabs the lens: it lifts, grows, and follows the finger
                    pressed = true
                    dragging = true
                    fingerX = down.position.x
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val first = indexAt(down.position.x)
                    val wasSelected = currentSelected
                    var moved = false
                    var released = false
                    if (first != currentSelected) currentOnSelect(first)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) { released = true; break }
                        ch.consume()
                        fingerX = ch.position.x
                        if (abs(ch.position.x - down.position.x) > 24f) moved = true
                        val i = indexAt(ch.position.x)
                        if (i != currentSelected) {
                            currentOnSelect(i)
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                    }
                    // let go: the lens drops back into the bar with a bounce
                    pressed = false
                    dragging = false
                    // a plain tap on the tab that was already selected
                    if (released && !moved && first == wasSelected) currentOnReselect()
                }
            }
    ) {
        // 1) iOS style floating capsule: soft dark glass, light rim, soft shadow.
        Box(Modifier.matchParentSize().iosGlass(barShape, if (navy) p.tabBarColor else null))
        // while held the bar turns lighter and more see-through, like frosted glass catching light
        Box(
            Modifier
                .matchParentSize()
                .clip(barShape)
                .background(Color.White.copy(alpha = 0.07f * lift))
                .drawBehind {
                    if (lift > 0.01f && itemW > 0f) {
                        val c = androidx.compose.ui.geometry.Offset(padPx + lensX + itemW / 2f, size.height / 2f)
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(Color.White.copy(alpha = 0.20f * lift), Color.Transparent),
                                center = c, radius = itemW * 1.25f
                            ),
                            radius = itemW * 1.25f, center = c
                        )
                    }
                }
        )

        // 2) the lens: sits inside the bar, and lifts out of it while held
        if (itemW > 0f) {
            Box(
                Modifier
                    .padding(BarPad)
                    .matchParentSize()
            ) {
                Box(
                    Modifier
                        .offset { IntOffset(lensX.roundToInt(), 0) }
                        .width(with(density) { itemW.toDp() })
                        .fillMaxHeight()
                        .graphicsLayer {
                            alpha = lensAlpha
                            val travel = (abs(targetX - lensX) / itemW).coerceAtMost(1f)
                            // lens grows past the bar edges when held, stretches when travelling
                            scaleX = 1f + 0.60f * lift + 0.10f * travel
                            scaleY = 1f + 0.45f * lift - 0.03f * travel
                            shadowElevation = 8.dp.toPx() * lift
                            shape = lensShape
                            clip = false
                            ambientShadowColor = Color.Black.copy(alpha = 0.45f)
                            spotShadowColor = Color.Black.copy(alpha = 0.45f)
                        }
                        .drawBehind {
                            // soft glow that wraps around the lens while it is held
                            if (lift > 0.01f) {
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        listOf(
                                            p.accent.copy(alpha = 0.04f * lift),
                                            Color.Transparent
                                        ),
                                        center = center,
                                        radius = size.width * 0.95f
                                    ),
                                    radius = size.width * 0.95f,
                                    center = center
                                )
                            }
                        }
                        .clip(lensShape)
                        .background(
                            if (selected >= 0) Color.White.copy(alpha = 0.07f - 0.03f * lift)
                            else Color.Transparent
                        )
                        .border(
                            1.dp,
                            Brush.linearGradient(
                                listOf(
                                    Color.White.copy(alpha = (0.55f + 0.30f * lift) * lensAlpha),
                                    Color.White.copy(alpha = (0.12f + 0.10f * lift) * lensAlpha),
                                    Color.White.copy(alpha = (0.40f + 0.30f * lift) * lensAlpha)
                                )
                            ),
                            lensShape
                        )
                )
            }
        }

        // 3) iOS tab items: icon on top, small label below, selected one tinted.
        Row(Modifier.fillMaxSize().padding(horizontal = 6.dp)) {
            repeat(count) { i ->
                val label = tabs[i].first
                val glyph = tabs.getOrNull(i)?.second ?: Glyph.Note
                val sel = i == selected
                val navyTint by animateColorAsState(if (sel) p.onTabBar else p.onTabBar.copy(alpha = 0.50f), tween(200), label = "tint")
                val underLens = if (itemW > 0f) (1f - abs(i * itemW - lensX) / itemW).coerceIn(0f, 1f) * lensAlpha else if (sel) 1f else 0f
                val tint = if (navy) navyTint else androidx.compose.ui.graphics.lerp(Color.White, p.accent, underLens)
                Column(
                    Modifier.weight(1f).fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier
                            .size(26.dp)
                            .graphicsLayer {
                                // dock-style magnification: the closer to the lens, the bigger
                                val centre = i * itemW
                                val d = if (itemW > 0f) abs(centre - lensX) / itemW else 1f
                                val near = (1f - d).coerceIn(0f, 1f) * lensAlpha
                                val sc = 1f + (0.03f + 0.50f * lift) * near
                                scaleX = sc
                                scaleY = sc
                                translationY = -3.dp.toPx() * near * lift
                            }
                            .drawBehind {
                                // magnifier bubble around the option under the lens
                                val a = lift * underLens
                                if (a > 0.01f) {
                                    val rad = size.minDimension * 0.72f
                                    drawCircle(Color.White.copy(alpha = 0.10f * a), radius = rad)
                                    drawCircle(
                                        Color.White.copy(alpha = 0.38f * a), radius = rad,
                                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx())
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (i == 3) {
                            // Profile tab: the user's own photo
                            Avatar(
                                photo, profileName, p,
                                Modifier
                                    .fillMaxSize()
                                    .then(if (sel) Modifier.border(1.5.dp, p.accent, CircleShape) else Modifier),
                                14.sp
                            )
                        } else {
                            if (!navy) {
                                val ghost = 0.35f * lift * underLens
                                GlyphIcon(glyph, Color(0xFF3CFFB0), Modifier.size(22.dp).graphicsLayer { translationX = 1.6.dp.toPx(); alpha = ghost })
                                GlyphIcon(glyph, Color(0xFFB04BFF), Modifier.size(22.dp).graphicsLayer { translationX = -1.6.dp.toPx(); alpha = ghost })
                            }
                            GlyphIcon(glyph, tint, Modifier.size(if (navy) 24.dp else 22.dp))
                        }
                    }
                    if (!navy) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            label, fontSize = 10.sp,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Medium,
                            color = tint, maxLines = 1,
                            modifier = Modifier.graphicsLayer {
                                val sc = 1f + 0.25f * lift * underLens
                                scaleX = sc
                                scaleY = sc
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Near-black glass pill (like the iOS tab bars in the reference video): a dark, almost opaque body,
 * a thin light rim and a soft shadow. The selected tab sits in a clear glass bubble on top of it.
 */
internal fun Modifier.iosGlass(shape: Shape, solid: Color? = null): Modifier =
    this
        .shadow(16.dp, shape, ambientColor = Color.Black.copy(alpha = 0.45f), spotColor = Color.Black.copy(alpha = 0.45f))
        .clip(shape)
        .background(
            if (solid != null) Brush.verticalGradient(listOf(solid, solid))
            else Brush.verticalGradient(listOf(Color(0xFF1E1E21).copy(alpha = 0.97f), Color(0xFF0C0C0E).copy(alpha = 0.97f)))
        )
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.18f))),
            shape
        )

val BarHeight = 64.dp
/** Total height of the white mini player card, and how much of its bottom the tab bar covers. */
val MiniCardHeight = 96.dp
val MiniCardHidden = 34.dp
private val BarPad = 6.dp

/** Tapping the selected tab again bumps this; every tab screen listens and scrolls to the top. */
object ScrollTop { var tick by mutableIntStateOf(0) }

@Composable
fun ScrollTopEffect(scroll: suspend () -> Unit) {
    val seen = remember { ScrollTop.tick }
    LaunchedEffect(ScrollTop.tick) { if (ScrollTop.tick != seen) scroll() }
}

/**
 * Small glass pill that replaces the tab bar while you scroll down (like the minimized iOS 26 tab bar).
 * [visible] goes 0..1 with the bar's hide animation. Tap it to bring the full bar back.
 */
@Composable
fun MiniTabPill(
    modifier: Modifier = Modifier,
    visible: Float,
    selected: Int,
    p: Palette,
    photo: ImageBitmap?,
    profileName: String,
    onClick: () -> Unit
) {
    if (visible <= 0.01f) return
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        if (pressed) 0.88f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "miniPillPress"
    )
    val haptic = LocalHapticFeedback.current
    val onClickS by rememberUpdatedState(onClick)
    val glyphs = listOf(Glyph.Note, Glyph.Album, Glyph.Artist)
    Box(
        modifier
            .size(56.dp)
            .graphicsLayer {
                alpha = visible
                val s = (0.6f + 0.4f * visible) * press
                scaleX = s
                scaleY = s
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
            }
            .iosGlass(CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClickS()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (selected == 3) {
            Avatar(
                photo, profileName, p,
                Modifier.size(30.dp).border(1.5.dp, p.accent, CircleShape),
                14.sp
            )
        } else {
            GlyphIcon(glyphs.getOrElse(selected.coerceAtLeast(0)) { Glyph.Note }, p.accent, Modifier.size(24.dp))
        }
    }
}

/** Round glass search button that sits next to the tab bar (like the iOS tab bar). */
@Composable
fun SearchButton(active: Boolean, p: Palette, onClick: () -> Unit, navy: Boolean = false) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.88f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 450f),
        label = "searchScale"
    )
    val tint by animateColorAsState(if (active) p.accent else if (navy) p.onTabBar else Color.White, label = "searchTint")
    val onClickS by rememberUpdatedState(onClick)
    Box(
        Modifier
            .size(if (navy) 56.dp else BarHeight)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .iosGlass(CircleShape, if (navy) p.tabBarColor else null)
            .background(if (active) p.accent.copy(alpha = 0.22f) else Color.Transparent, CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClickS() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(Glyph.Search, tint, Modifier.size(24.dp))
    }
}

fun formatTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}


/**
 * Dynamic Island: pure black pill (like the real iPhone one).
 *  - Tap the pill: it grows with a springy, staggered animation into a control panel.
 *  - The expanded panel shows cover, title, a live progress bar and round, press-reactive buttons.
 *  - Content fades/slides in after the shape has started growing, and fades out before it shrinks.
 */
@Composable
fun TopIsland(
    song: Song,
    p: Palette,
    isPlaying: Boolean,
    isFav: Boolean,
    shuffle: Boolean,
    repeatMode: Int,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onFav: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    modifier: Modifier = Modifier,
    islandWidthDp: Int = 250,
    islandHeightDp: Int = 36,
    position: Long = 0L,
    reserveTop: Boolean = true,
    onSeek: (Long) -> Unit = {},
    onOpenPlayer: () -> Unit = {},
    expanded: Boolean = false,
    onExpandedChange: (Boolean) -> Unit = {},
    onLongPress: () -> Unit = {},
    sleepActive: Boolean = false
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val statusH = with(density) { WindowInsets.statusBarsIgnoringVisibility.getTop(density).toDp() }
    val pillH = islandHeightDp.dp
    val top = ((statusH - pillH) / 2).coerceAtLeast(4.dp)
    val pop = remember { Animatable(1f) }
    val longPressS by rememberUpdatedState(onLongPress)

    // 0f = compact pill, 1f = expanded panel. One spring drives size, corner, shadow and content.
    val t by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 300f),
        label = "islandT"
    )
    // when the song changes the compact pill briefly swells, like the real Dynamic Island
    val bump = remember { Animatable(0f) }
    var firstSong by remember { mutableStateOf(true) }
    LaunchedEffect(song.id) {
        if (firstSong) {
            firstSong = false
        } else {
            bump.snapTo(0f)
            bump.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 260f))
            kotlinx.coroutines.delay(900)
            bump.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 220f))
        }
    }
    val bumpNow = (bump.value * (1f - t)).coerceAtLeast(0f)
    val width = androidx.compose.ui.unit.lerp(islandWidthDp.dp, 340.dp, t) + 44.dp * bumpNow
    val height = androidx.compose.ui.unit.lerp(pillH, 168.dp, t) + 8.dp * bumpNow
    val corner = androidx.compose.ui.unit.lerp(pillH / 2, 34.dp, t.coerceIn(0f, 1f))
    val shape = RoundedCornerShape(corner)

    // the content of the panel appears a bit after the shape starts to grow
    val contentAlpha by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = if (expanded) tween(260, delayMillis = 110, easing = FastOutSlowInEasing) else tween(90),
        label = "islandContentAlpha"
    )
    val compactAlpha by animateFloatAsState(
        targetValue = if (expanded) 0f else 1f,
        animationSpec = if (expanded) tween(90) else tween(220, delayMillis = 140),
        label = "islandCompactAlpha"
    )

    LaunchedEffect(song.id) {
        pop.snapTo(1.05f)
        pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 380f))
    }

    val wave = rememberInfiniteTransition(label = "islandWave")
    val wavePhase by wave.animateFloat(
        initialValue = 0.55f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(620, easing = LinearEasing), RepeatMode.Reverse),
        label = "wavePhase"
    )

    // press feedback on the whole pill
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        if (pressed) 0.96f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "islandPress"
    )

    Box(modifier.fillMaxWidth().padding(top = if (reserveTop) top else 0.dp), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier
                .graphicsLayer {
                    val s = pop.value * (if (expanded) 1f else press)
                    scaleX = s; scaleY = s
                    // the big panel drops lower on the screen while it grows
                    translationY = 56.dp.toPx() * t
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                }
                .width(width)
                .height(height)
                .shadow(
                    elevation = 6.dp + 18.dp * t, shape = shape,
                    ambientColor = Color.Black, spotColor = Color.Black
                )
                .clip(shape)
                .background(Color.Black)
                .border(1.dp, Color.White.copy(alpha = 0.08f + 0.05f * t), shape)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onExpandedChange(!expanded)
                        },
                        onLongPress = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            longPressS()
                        }
                    )
                }
        ) {
            // ───────── compact pill ─────────
            if (compactAlpha > 0.01f) {
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .height(pillH)
                        .padding(horizontal = 5.dp)
                        .graphicsLayer { alpha = compactAlpha },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Cover(song, Modifier.size((islandHeightDp - 8).coerceAtLeast(20).dp), 0.dp, p, 200, round = true)
                    // only the cover and the wave: the title shows when the island is expanded
                    Spacer(Modifier.weight(1f))
                    // small blue moon while the sleep timer is running
                    if (sleepActive) {
                        GlyphIcon(Glyph.Moon, Color(0xFF0A84FF), Modifier.size(13.dp))
                        Spacer(Modifier.width(6.dp))
                    }
                    IslandWave(isPlaying, wavePhase, Color.White, 0.85f)
                    Spacer(Modifier.width(6.dp))
                }
            }

            // ───────── expanded panel ─────────
            if (contentAlpha > 0.01f) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                        .graphicsLayer {
                            alpha = contentAlpha
                            translationY = (1f - contentAlpha) * -10.dp.toPx()
                        },
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // header: cover · title/artist · wave
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Cover(song, Modifier.size(46.dp), 12.dp, p, 300)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                song.title, color = Color.White, fontSize = 15.sp,
                                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                song.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        IslandWave(isPlaying, wavePhase, Color.White, 1f)
                        Spacer(Modifier.width(10.dp))
                        // opens the full player
                        Box(
                            Modifier.size(34.dp).clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.16f))
                                .clickable {
                                    onExpandedChange(false)
                                    onOpenPlayer()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            GlyphIcon(Glyph.ChevronDown, Color.White, Modifier.size(20.dp).graphicsLayer { rotationZ = 180f })
                        }
                    }

                    // progress: drag or tap to change the time of the song
                    val dur = song.durationMs
                    var dragFrac by remember { mutableStateOf<Float?>(null) }
                    val liveFrac = if (dur > 0) (position.toFloat() / dur).coerceIn(0f, 1f) else 0f
                    val frac = dragFrac ?: liveFrac
                    val shownMs = if (dragFrac != null) (frac * dur).toLong() else position
                    val seekS by rememberUpdatedState(onSeek)
                    Column {
                        Box(
                            Modifier.fillMaxWidth().height(24.dp)
                                .pointerInput(dur) {
                                    detectTapGestures { o ->
                                        if (dur > 0 && size.width > 0) {
                                            seekS((o.x / size.width).coerceIn(0f, 1f).times(dur).toLong())
                                        }
                                    }
                                }
                                .pointerInput(dur) {
                                    detectHorizontalDragGestures(
                                        onDragStart = { o ->
                                            if (size.width > 0) dragFrac = (o.x / size.width).coerceIn(0f, 1f)
                                        },
                                        onHorizontalDrag = { change, _ ->
                                            change.consume()
                                            if (size.width > 0) dragFrac = (change.position.x / size.width).coerceIn(0f, 1f)
                                        },
                                        onDragEnd = {
                                            dragFrac?.let { if (dur > 0) seekS((it * dur).toLong()) }
                                            dragFrac = null
                                        },
                                        onDragCancel = { dragFrac = null }
                                    )
                                },
                            contentAlignment = Alignment.CenterStart
                        ) {
                            val barH by animateDpAsState(if (dragFrac != null) 8.dp else 4.dp, tween(150), label = "islandBarH")
                            Box(
                                Modifier.fillMaxWidth().height(barH)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White.copy(alpha = 0.18f))
                            ) {
                                Box(
                                    Modifier.fillMaxHeight().fillMaxWidth(frac)
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.White)
                                )
                            }
                        }
                        Row(Modifier.fillMaxWidth()) {
                            Text(formatTime(shownMs), color = Color.White.copy(alpha = if (dragFrac != null) 1f else 0.5f), fontSize = 10.sp)
                            Spacer(Modifier.weight(1f))
                            Text("-" + formatTime((dur - shownMs).coerceAtLeast(0L)), color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                        }
                    }

                    // controls
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IslandButton(Glyph.Shuffle, if (shuffle) p.accent else Color.White.copy(alpha = 0.55f), 38.dp, 18.dp, onShuffle)
                        IslandButton(Glyph.Prev, Color.White, 42.dp, 21.dp, onPrev)
                        IslandButton(
                            if (isPlaying) Glyph.Pause else Glyph.Play, Color.Black, 54.dp, 24.dp, onToggle,
                            filled = Color.White
                        )
                        IslandButton(Glyph.Next, Color.White, 42.dp, 21.dp, onNext)
                        IslandButton(
                            Glyph.Repeat,
                            if (repeatMode != Player.REPEAT_MODE_OFF) p.accent else Color.White.copy(alpha = 0.55f),
                            38.dp, 18.dp, onRepeat
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IslandWave(playing: Boolean, phase: Float, color: Color, alpha: Float) {
    val rest by animateFloatAsState(if (playing) 1f else 0f, tween(300), label = "islandWaveRest")
    Row(
        Modifier.height(18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(5) { i ->
            val base = listOf(5, 11, 7, 15, 8)[i].toFloat()
            val h = 3f + (base * phase * (if (i % 2 == 0) 1f else 0.82f) - 3f) * rest
            Box(
                Modifier.width(2.5.dp).height(h.coerceAtLeast(3f).dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color.copy(alpha = alpha * (0.5f + 0.5f * rest)))
            )
        }
    }
}

/** Round island button: shrinks while pressed and springs back, with a soft pressed highlight. */
@Composable
private fun IslandButton(
    glyph: Glyph,
    color: Color,
    size: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    filled: Color? = null
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 600f),
        label = "islandBtnScale"
    )
    val glow by animateFloatAsState(if (pressed) 1f else 0f, tween(120), label = "islandBtnGlow")
    val onClickS by rememberUpdatedState(onClick)
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(filled ?: Color.White.copy(alpha = 0.14f * glow))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClickS() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        GlyphIcon(glyph, color, Modifier.size(iconSize))
    }
}

